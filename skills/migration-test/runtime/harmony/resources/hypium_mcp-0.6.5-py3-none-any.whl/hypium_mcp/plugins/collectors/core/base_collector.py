import time
import os
from abc import abstractmethod
from pathlib import Path

from hypium_mcp.config.config import Config, get_config
from hypium_mcp.device.device_manager import DeviceManager
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

UTF_8 = "utf-8"

logger = get_logger(LoggerName.Collector)

class BaseCollector:
    def __init__(self):
        self.config: Config = get_config()
        self.driver = DeviceManager.get_instance().get_device(self.config.device_id)
        self.data_dir = Path(self.config.output_dir).absolute()
        os.makedirs(self.data_dir, exist_ok=True)
        logger.info(f"数据文件文件存储在: {self.data_dir}")

        self.case_id = time.strftime('%m%d%H%M', time.localtime())
        self.case_start_time = time.time()
        self.case_stop_time = self.case_start_time

    def case_start(self):
        self.case_start_time = time.time()

    def case_stop(self):
        self.case_stop_time = time.time()

    def action_start(self, action_id: str):
        pass

    def action_stop(self, action_id: str):
        pass

    def name(self):
        pass

    @staticmethod
    def write_data(data_str: str, data_path: str | Path) -> None:
        data_path = Path(data_path)
        data_path.write_text(data_str, encoding=UTF_8)

    def get_dir(self, dir_name: str) -> Path:
        return Path(self.data_dir).joinpath(dir_name)

    def get_action_path(self, action_id: str):
        return Path(self.data_dir).joinpath(action_id)