"""
Device Manager Module

Manages device connections and provides a singleton for accessing device instances.
"""

import subprocess
import threading
from typing import Dict, List, Optional, Tuple
from hypium import UiDriver
from hypium_mcp.config.config import get_config


class DeviceManager:
    """
    Singleton device manager for HarmonyOS devices.

    Provides caching for device instances and utility methods for
    device discovery and management.
    """

    __instance__: Optional["DeviceManager"] = None
    __lock__ = threading.Lock()

    def __init__(self, hdc_server: Optional[Tuple[str, int]] = None) -> None:
        """Initialize the device manager with empty device cache."""
        self._devices: Dict[str, UiDriver] = {}
        self._lock = threading.RLock()
        self.hdc_host = "127.0.0.1"
        self.hdc_port = 8710
        self.current_device_id: Optional[str] = None
        if hdc_server:
            self.hdc_host, self.hdc_port = hdc_server

    @classmethod
    def get_instance(cls) -> "DeviceManager":
        """
        Get the singleton instance of DeviceManager.

        Returns:
            DeviceManager instance
        """
        if cls.__instance__ is None:
            with cls.__lock__:
                if cls.__instance__ is None:
                    config = get_config()
                    cls.__instance__ = DeviceManager((config.hdc_host, config.hdc_port))
        return cls.__instance__

    @classmethod
    def reset_instance(cls) -> None:
        """Reset the singleton instance (useful for testing)."""
        cls.__instance__ = None

    def list_devices(self) -> List[str]:
        """
        Scan and return a list of available device serial numbers.

        Uses the 'hdc list targets' command to discover devices.

        Returns:
            List of device serial numbers
        """
        if self.hdc_host != "127.0.0.1" or self.hdc_port != 8710:
            cmd = ["hdc", "-s", "%s:%s" % (self.hdc_host, self.hdc_port), "list", "targets"]
        else:
            cmd = ["hdc", "list", "targets"]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            shell=False,
        )
        if result.returncode != 0:
            return []

        devices = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        devices = [sn for sn in devices if sn and sn != "[Empty]"]
        return devices

    def list_devices_with_type(self) -> List[Dict[str, str]]:
        """
        获取所有可用设备列表，包含设备SN和设备类型

        Returns:
            设备列表，每个元素包含:
            - sn: 设备序列号
            - type: 设备类型
        """
        device_sns = self.list_devices()

        devices = []
        for sn in device_sns:
            device_type = self._get_device_type(sn)
            devices.append({
                "sn": sn,
                "type": device_type
            })

        return devices

    def _get_device_type(self, device_sn: str) -> str:
        """
        获取设备类型

        Args:
            device_sn: 设备SN

        Returns:
            设备类型字符串，失败返回"unknown"
        """
        try:
            if self.hdc_host != "127.0.0.1" or self.hdc_port != 8710:
                cmd = ["hdc", "-t", device_sn, "-s", f"{self.hdc_host}:{self.hdc_port}", "shell", "param", "get", "const.product.devicetype"]
            else:
                cmd = ["hdc", "-t", device_sn, "shell", "param", "get", "const.product.devicetype"]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                shell=False,
                timeout=5
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return "unknown"

    def switch_device(self, device_sn: str) -> Dict[str, str]:
        """
        切换默认连接的设备

        Args:
            device_sn: 要切换的设备序列号

        Returns:
            切换结果信息
        """
        with self._lock:
            old_device = self.current_device_id

            self.current_device_id = device_sn
            self.remove_device(old_device)

            return {
                "status": "success",
                "current_device": device_sn
            }

    def get_current_device_info(self) -> Dict[str, str]:
        """
        获取当前设备信息

        Returns:
            当前设备信息，包含:
            - sn: 设备序列号
            - type: 设备类型
            - status: 连接状态
        """
        with self._lock:
            current_sn = self.current_device_id

            if not current_sn or current_sn == "default":
                devices = self.list_devices()
                if devices:
                    current_sn = devices[0]
                    self.current_device_id = current_sn
                else:
                    return {
                        "sn": None,
                        "type": None,
                        "status": "disconnected"
                    }

            device_type = self._get_device_type(current_sn)

            return {
                "sn": current_sn,
                "type": device_type,
                "status": "connected"
            }

    def get_device(self, device_id: str = "default") -> UiDriver:
        """
        Get or create a device connection.

        Maintains a cache of connected devices to avoid repeated connections.

        Args:
            device_id: Device serial number, or "default" to use the first available device

        Returns:
            UiDriver instance for the device

        Raises:
            ValueError: If no devices are available when using "default"
        """
        with self._lock:
            if device_id == "default" and self.current_device_id:
                device_id = self.current_device_id

            if device_id == "default" or not device_id:
                device_id = get_config().device_id

            if device_id == "default" or not device_id:
                devices = self.list_devices()
                if not devices:
                    raise ValueError("No devices available")
                device_id = devices[0]

            self.current_device_id = device_id

            if device_id not in self._devices:
                self._devices[device_id] = UiDriver.connect(device_sn=device_id,
                                                            connector_server=(self.hdc_host, self.hdc_port),
                                                            report_path=get_config().output_dir,
                                                            log_level=get_config().log_level)

            return self._devices[device_id]

    def remove_device(self, device_id: str) -> bool:
        """
        Remove a device from the cache.

        Args:
            device_id: Device serial number

        Returns:
            True if device was in cache and removed, False otherwise
        """
        if device_id in self._devices:
            del self._devices[device_id]
            return True
        return False

    def clear_cache(self) -> None:
        """Clear all cached device connections."""
        self._devices.clear()

    def release_device(self, device_id: str) -> Dict[str, str]:
        """
        Release a specific device connection by calling close() and removing from cache.

        Args:
            device_id: 要释放的设备序列号

        Returns:
            释放结果信息，包含:
            - status: 操作状态 (success/not_found)
            - device_id: 被释放的设备ID
        """
        with self._lock:
            device = self._devices.get(device_id)
            if device:
                try:
                    device.close()
                except Exception:
                    pass
                del self._devices[device_id]
                return {
                    "status": "success",
                    "device_id": device_id
                }
            return {
                "status": "not_found",
                "device_id": device_id
            }

    def release_all_devices(self) -> Dict[str, str]:
        """
        Release all cached device connections by calling close() and removing from cache.

        Returns:
            释放结果信息，包含:
            - status: 操作状态
            - released_count: 释放的设备数量
        """
        with self._lock:
            released_count = 0
            for device_id in list(self._devices.keys()):
                try:
                    device = self._devices.get(device_id)
                    if device:
                        device.close()
                    del self._devices[device_id]
                    released_count += 1
                except Exception:
                    pass
            return {
                "status": "success",
                "released_count": released_count
            }

    def get_cached_devices(self) -> List[str]:
        """
        Get a list of cached device IDs.

        Returns:
            List of cached device serial numbers
        """
        return list(self._devices.keys())

    def __repr__(self) -> str:
        """String representation of the device manager."""
        return f"DeviceManager(cached_count={len(self._devices)})"