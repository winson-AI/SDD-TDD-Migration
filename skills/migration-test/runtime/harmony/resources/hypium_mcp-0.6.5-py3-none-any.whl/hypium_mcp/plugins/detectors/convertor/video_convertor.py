import math
import os
import queue
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import av
import cv2
from av import VideoFrame

from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)
JPG_PARAMS = [cv2.IMWRITE_JPEG_QUALITY, 80]


class ThreadPoolExecutorLimiter(ThreadPoolExecutor):

    def __init__(self, maxsize=50, *args, **kwargs):
        super(ThreadPoolExecutorLimiter, self).__init__(*args, **kwargs)
        self._work_queue = queue.Queue(maxsize=maxsize)
        self.wait_times = 0

    def submit(self, fn, /, *args, **kwargs):
        return super().submit(fn, *args, **kwargs)


class TempFrameContent:
    def __init__(self, frame: VideoFrame, frame_time: int):
        self.frame = frame
        self.time = frame_time


class VideoConvertor:

    @classmethod
    def convert_video(cls, video_path: Path):
        image_folder = video_path.parent.joinpath("images")
        with ThreadPoolExecutorLimiter(maxsize=50, max_workers=8) as executor:
            future_list: list[Future] = []
            container = av.open(video_path)
            video_stream = container.streams.video[0]
            video_stream.thread_type = "AUTO"
            last_frame_content: Optional[TempFrameContent] = None
            for frame in container.decode(video_stream):
                frame_time = int(frame.time * 1000)
                frame_content = TempFrameContent(frame, frame_time)
                future_list.append(executor.submit(cls.save_images, last_frame_content, frame_content,
                                                   [(0, math.inf)], image_folder))
                last_frame_content = frame_content
            container.close()
            for future in as_completed(future_list):
                try:
                    future.result()
                except Exception as e:
                    logger.error('操作视频转换失败', exc_info=e)
        return image_folder

    @classmethod
    def save_images(cls, last_frame: TempFrameContent, frame: TempFrameContent,
                    mono_time_list: list[tuple[float, float]],
                    save_folder: Path):
        os.makedirs(save_folder, exist_ok=True)
        for i in range(0, len(mono_time_list)):
            if mono_time_list[i][0] is None or mono_time_list[i][1] is None:
                continue
            if mono_time_list[i][0] <= frame.time <= mono_time_list[i][1]:
                if last_frame is not None and mono_time_list[i][0] > last_frame.time:
                    cls.save_image(save_folder, last_frame.time, last_frame)
                new_time = frame.time
                if not new_time:
                    continue
                cls.save_image(save_folder, new_time, frame)
            elif frame.time > mono_time_list[i][1]:
                continue
            else:
                break

    @classmethod
    def save_image(cls, save_folder: Path, image_time: int, frame):
        image = frame.frame.to_ndarray(format="bgr24")
        cv2.imencode(".jpg", image, JPG_PARAMS)[1].tofile(os.path.join(save_folder, f'{int(image_time)}.png'))
