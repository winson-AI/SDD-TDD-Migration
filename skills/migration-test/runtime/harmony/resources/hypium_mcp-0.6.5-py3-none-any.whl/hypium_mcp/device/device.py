import base64
from hypium_mcp.utils.log import get_logger
import os.path
import time
from io import BytesIO
from typing import List

from PIL import Image
from fastmcp.tools import FunctionTool
from mcp.types import CallToolResult, TextContent

from .device_manager import DeviceManager
from ..config import constant
from ..config.config import get_config
from ..core.tool_adapter import inject_driver
from ..core.tool_loader import loader
from .. import tools
from ..types.screen import Screenshot

logger = get_logger("MCPDevice")

class Device:

    def __init__(self, device_sn: str = "default", ip: str = constant.HDC_DEFAULT_HOST,
                 port: int = constant.HDC_DEFAULT_PORT, screenshot_mode="default"):
        self._device_sn = device_sn
        self._ip = ip
        self._port = port
        self._driver = DeviceManager(hdc_server=(ip, port)).get_device(device_sn)
        self._all_tools = {}
        self._function_tools: List[FunctionTool] = []
        self._register_tools(os.path.dirname(tools.__file__))
        self._screenshot_mode = screenshot_mode

    def _get_current_driver(self):
        return self._driver

    def list_tools(self):
        if self._function_tools:
            return self._function_tools
        self._function_tools = [FunctionTool.from_function(item) for item in self._all_tools.values() if not item.__name__.startswith("mcp_")]
        return self._function_tools

    def call_tool(self, func_name, kwargs):
        logger.info("call tool: %s, args: %s", func_name, kwargs)
        result = self._all_tools[func_name](**kwargs)
        return CallToolResult(content=[TextContent(type="text", text=str(result))])

    def _get_screenshot_by_hap(self, screenshot_path):
        config = {
            "isNotificationNeeded": False
        }

        file_name = self._driver._device.proxy.screenApiHelper.screenshot(
            ScreenshotOptions=config)
        remote = "/storage/media/100/local/files/Docs/Download/{}".format(file_name)
        try:
            self._driver.pull_file(remote, screenshot_path)
        finally:
            self._driver.execute_shell_command("rm %s" % remote)
        return screenshot_path

    def get_screenshot(self, **kwargs) -> Screenshot:
        """
        Capture current screen.
        Returns:
            Screenshot object containing base64 data and dimensions.
        """
        if self._screenshot_mode == "default":
            screenshot_path = self._driver.UiTree.screenshot_to_dir(get_config().output_dir)
        else:
            screenshot_path = os.path.join(get_config().output_dir, "%s.jpeg" % int(time.time() * 1000))
            screenshot_path = self._get_screenshot_by_hap(screenshot_path)

        with Image.open(screenshot_path) as img:
            width, height = img.size
            buffered = BytesIO()
            img.save(buffered, format="jpeg")
            base64_data = base64.b64encode(buffered.getvalue()).decode("utf-8")
            return Screenshot(
                base64_data=base64_data,
                width=width,
                height=height,
            )

    def __getattr__(self, item):
        if item == "_all_tools":
            raise AttributeError(item)
        if item in self._all_tools:
            return self._all_tools[item]
        raise AttributeError(item)

    def _register_tools(self, module_path):
        all_tools = loader.load_builtin_tools(module_path)
        for module, tools in all_tools.items():
            for func_name, func in tools.items():
                if func_name in self._all_tools:
                    raise ValueError(f"Register same tool twice: {func_name}, current module: {module}")
                self._all_tools[func_name] = inject_driver(func, self._get_current_driver)

    def clean_up(self):
        self._driver.close()
