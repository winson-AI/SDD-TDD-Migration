"""
Toast 监听模块

提供 Toast 提示消息监听功能。
"""
from hypium import UiDriver


def start_listen_toast(device: UiDriver) -> None:
    """
    开始监听 Toast 提示消息
    """
    device.start_listen_toast()


def get_toast(device: UiDriver) -> str:
    """
    获取最新的 Toast 提示消息

    Returns:
        Toast 提示消息内容
    """
    return device.get_latest_toast()