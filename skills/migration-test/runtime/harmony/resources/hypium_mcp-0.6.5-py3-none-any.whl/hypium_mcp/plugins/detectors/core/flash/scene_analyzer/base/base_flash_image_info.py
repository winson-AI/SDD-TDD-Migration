import json
from abc import ABC, abstractmethod
from pathlib import Path


class ScreenFlashImageInfo:

    def __init__(self, image_file_path: Path):
        # 图片路径
        self.image_file_path = image_file_path
        # 图片名
        self.image_file_name = image_file_path.name
        # 图片对应的时间
        self.image_time = int(image_file_path.stem)
        # 模板匹配度
        self.template_similarity = 1.0

        self.prev_image_info: ScreenFlashImageInfo | None = None
        self.next_image_info: ScreenFlashImageInfo | None = None

    def __repr__(self):
        return json.dumps({
            "time": self.image_time,
            "template_similarity": self.template_similarity,
        })


class BaseFlashImageInfo(ABC):

    def __init__(self, image_info: ScreenFlashImageInfo):
        self._image_info = image_info

    @property
    def image_info(self):
        return self._image_info

    @property
    def image_time(self):
        return self._image_info.image_time

    @property
    def image_file_path(self):
        return self._image_info.image_file_path

    @property
    def template_similarity(self):
        return self._image_info.template_similarity

    @property
    @abstractmethod
    def value(self):
        pass

    def __repr__(self):
        return json.dumps({
            "image_time": self.image_time,
            "image_file_path": self.image_file_path,
            "value": self.value
        })
