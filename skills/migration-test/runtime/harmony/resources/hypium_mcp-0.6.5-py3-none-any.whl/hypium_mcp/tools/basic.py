"""
基础设备操作

提供基本的设备交互能力，包括点击、滑动、文本输入和其他 UI 操作。
"""

import time
from typing import Literal, Optional, Tuple
from hypium import KeyCode, UiDriver
from hypium_mcp.plugins import mcp_collector_enabled
from hypium_mcp.utils import coordinate
from .helpers import app_manager


def start_app(device: UiDriver, app_name: str, cold_start: bool = False) -> None:
    """
    在设备上启动应用程序

    Args:
        app_name: 应用程序的包名或者应用显示名称
        cold_start: 是否冷启动（先停止应用再启动）
    """
    bundle_name = app_manager.get_bundle_name_by_display_name(app_name) or app_name
    actual_ability = app_manager.get_main_ability_by_bundle_name(bundle_name, device)
    if cold_start:
        device.stop_app(bundle_name)
        device.wait(1)
    device.start_app(bundle_name, actual_ability, cold_start)


def stop_app(device: UiDriver, app_name: str) -> None:
    """
    在设备上停止应用程序

    Args:
        app_name: 应用程序的包名或者应用显示名称
    """
    bundle_name = app_manager.get_bundle_name_by_display_name(app_name) or app_name
    device.stop_app(bundle_name)


@mcp_collector_enabled
def click(device: UiDriver, pos: Tuple[int, int]) -> None:
    """
    在指定坐标执行点击操作

    Args:
        pos: 点击坐标
    """
    pos = coordinate.normalize_coordinate(pos)
    device.click(pos)


@mcp_collector_enabled
def long_click(device: UiDriver, pos: Tuple[int, int], duration: float | int = 2):
    """
    在指定坐标执行长按操作

    Args:
        pos: 点击坐标
        duration: 长按持续时间（秒）
    """
    pos = coordinate.normalize_coordinate(pos)
    device.long_click(pos, duration)


@mcp_collector_enabled
def double_click(device: UiDriver, pos: Tuple[int, int]) -> None:
    """
    在指定坐标执行双击操作

    Args:
        pos: 点击坐标
    """
    pos = coordinate.normalize_coordinate(pos)
    device.double_click(pos)


@mcp_collector_enabled
def input_text(device: UiDriver, text: str) -> None:
    """
    在当前光标位置输入文本

    Args:
        text: 要输入的文本
    """
    device.input_text_on_current_cursor(text)


def clear_text(device: UiDriver, delay: float | int = 0.5) -> None:
    """
    清除当前光标位置的文本

    Args:
        delay: 操作后等待时间，最大不超过 2 秒
    """
    device.press_combination_key(KeyCode.CTRL_LEFT, KeyCode.A)
    time.sleep(0.5)
    device.press_key(KeyCode.DEL)
    time.sleep(min(delay, 2.0))


@mcp_collector_enabled
def swipe(device: UiDriver, start: Tuple[int, int], end: Tuple[int, int], direction: Optional[str] = None) -> None:
    """
    从起点滑动到终点

    Args:
        start: 滑动起点，如 (100, 100)
        end: 滑动终点，如 (200, 200)
        direction: 手指滑动方向附加说明，支持 left, right, up, down
    """
    start = coordinate.normalize_coordinate(start)
    end = coordinate.normalize_coordinate(end)

    # direction 存在且合法时，检查是否需要调换坐标
    if direction:
        dir_lower = direction.lower()
        valid_directions = {"left", "right", "up", "down"}

        if dir_lower in valid_directions:
            x1, y1 = start
            x2, y2 = end

            # left: 从右向左滑动，x1 应该大于 x2
            if dir_lower == "left" and x1 < x2:
                start, end = end, start
            # right: 从左向右滑动，x1 应该小于 x2
            elif dir_lower == "right" and x1 > x2:
                start, end = end, start
            # up: 从下向上滑动，y1 应该大于 y2
            elif dir_lower == "up" and y1 < y2:
                start, end = end, start
            # down: 从上向下滑动，y1 应该小于 y2
            elif dir_lower == "down" and y1 > y2:
                start, end = end, start

    device.slide(start, end, slide_time=0.7)


@mcp_collector_enabled
def drag(device: UiDriver, start: Tuple[int, int], end: Tuple[int, int]) -> None:
    """
    从起点拖拽到终点

    Args:
        start: 拖拽起点，如 (100, 100)
        end: 拖拽终点，如 (200, 200)
    """
    start = coordinate.normalize_coordinate(start)
    end = coordinate.normalize_coordinate(end)
    device.drag(start, end)


@mcp_collector_enabled
def go_back(device: UiDriver, times: int = 1) -> None:
    """
    返回上一级

    Args:
        times: 返回次数, 某些应用需要连续两次才能返回
    """
    for i in range(times):
        device.go_back()


def go_home(device: UiDriver, times: int = 1) -> None:
    """
    返回桌面

    Args:
        times: 返回次数, 某些应用需要连续两次才能回到桌面
    """
    for i in range(times):
        device.go_home()


def wait(device: UiDriver, duration: float | int = 3):
    """
    等待指定时间

    Args:
        duration: 等待时间（秒）
    """
    device.wait(duration)


@mcp_collector_enabled
def press_key(device: UiDriver, key_name: Literal["home", "power", "volume_up", "volume_down"]):
    """
    按下按键

    Args:
        key_name: 按键名称, 当前仅支持"home", "power", "volume_up", "volume_down"
    """
    key_map = {
        "power": KeyCode.POWER,
        "volume_up": KeyCode.VOLUME_UP,
        "volume_down": KeyCode.VOLUME_DOWN,
        "home": KeyCode.HOME,
    }
    key_code = key_map.get(key_name)
    if not key_code:
        raise ValueError('无效的按键名称，仅支持 ["power", "volume_up", "volume_down"]')
    device.press_key(key_code)


def clear_recent_task(device: UiDriver, delay: float = 1):
    """
    清空最近任务(清空后台)

    Args:
        delay: 清理后等待的时间
    """
    from hypium import BY
    device.go_home()
    time.sleep(1)
    device.press_combination_key(2076, 2049)
    component = device.wait_for_component(BY.key("RecentClearAllView_Image_deleteFull"), timeout=1)
    if component:
        device.touch(component)
    else:
        components = device.find_all_components(BY.type("Column"))
        if components:
            device.touch(components[-1])
        device.go_home()
    time.sleep(delay)
    return "后台应用已清理"
