from typing import Tuple
import math
from hypium import UiDriver, KeyCode, Rect, Gesture

from hypium_mcp.utils import coordinate


def _expand_to_bounds(center_point, screen_width, screen_height, expand_px):
    """
    将中心点扩展为一个矩形区域（bounds），向上下左右各扩展 expand_px 像素。

    Args:
        center_point (tuple): 中心点坐标 (x, y)
        screen_width (int): 屏幕宽度
        screen_height (int): 屏幕高度
        expand_px (int): 向四个方向扩展的像素值

    Returns:
        dict: 包含左、上、右、下坐标的 bounds，格式为 {'left': l, 'top': t, 'right': r, 'bottom': b}
              并确保不超出屏幕边界。
    """
    x, y = center_point

    # 计算扩展后的边界
    left = max(0, x - expand_px)
    top = max(0, y - expand_px)
    right = min(screen_width, x + expand_px)
    bottom = min(screen_height, y + expand_px)
    return [left, top, right, bottom]


def pinch_in(device: UiDriver, pos: Tuple[int, int] = None):
    """在指定位置执行双指缩小。

    Args:
        pos: 操作中心点坐标 (x, y)。如果为None，则对整个屏幕执行缩放。
    """
    if pos:
        w, h = device.get_display_size()
        x, y = coordinate.normalize_coordinate(pos)
        pos = w * x, h * y
        left, top, right, bottom = _expand_to_bounds(pos, w, h, 300)
        area = Rect(left=left, right=right, top=top, bottom=bottom)
    else:
        area = None
    device.pinch_in(area, scale=0.2)


def pinch_out(device: UiDriver, pos: Tuple[int, int] = None):
    """在指定位置执行双指放大。

    Args:
        pos: 操作中心点坐标 (x, y)。如果为None，则对整个屏幕执行缩放。
    """
    if pos:
        w, h = device.get_display_size()
        x, y = coordinate.normalize_coordinate(pos)
        pos = w * x, h * y
        left, top, right, bottom = _expand_to_bounds(pos, w, h, 300)
        area = Rect(left=left, right=right, top=top, bottom=bottom)
    else:
        area = None
    device.pinch_out(area, scale=1.6)


def rotate_gesture(
        device: UiDriver,
        pos: Tuple[int, int] = None,
        angle: float = 90,
        clockwise: bool = True,
        radius: float = 300,
):
    """
    执行双指旋转手势，用于图片旋转等场景, 不适用于屏幕旋转场景。

    Args:
        pos: 旋转中心点坐标 (x, y)。如果为None，则使用屏幕中心。
        angle: 旋转角度，默认为90度。
        clockwise: 旋转方向，True表示顺时针，False表示逆时针。
        radius: 两个手指距离中心点的半径（像素），默认为300像素。
    """
    speed = 600
    segments: int = 8
    w, h = device.get_display_size()

    x, y = coordinate.normalize_coordinate(pos)
    pos = w * x, h * y

    # 确定旋转中心点
    if pos is None:
        center_x, center_y = w // 2, h // 2
    else:
        center_x, center_y = pos

    # 将角度转换为弧度
    angle_rad = math.radians(angle)

    # 计算起始位置（两个手指分别在中心点两侧）
    start_angle1 = 0 if clockwise else math.pi
    start_angle2 = math.pi if clockwise else 0

    # 归一化坐标到0-1范围
    def normalize(x, y):
        return (x / w, y / h)

    # 计算手指在圆弧上的各点位置
    def calculate_arc_points(start_angle, total_angle, radius, segments_count):
        points = []
        for i in range(segments_count + 1):
            current_angle = start_angle + total_angle * i / segments_count
            x = center_x + radius * math.cos(current_angle)
            y = center_y + radius * math.sin(current_angle)
            points.append(normalize(x, y))
        return points

    # 计算旋转弧长，用于确定执行时间
    arc_length = abs(angle_rad) * radius
    duration = arc_length / speed if speed > 0 else 1.0
    interval = duration / segments

    # 手指1的圆弧轨迹点
    points1 = calculate_arc_points(start_angle1, angle_rad, radius, segments)

    # 构建手指1的手势
    gesture1 = Gesture().start(points1[0])
    for point in points1[1:]:
        gesture1 = gesture1.move_to(point, interval=interval)

    # 手指2的圆弧轨迹点
    points2 = calculate_arc_points(start_angle2, angle_rad, radius, segments)

    # 构建手指2的手势
    gesture2 = Gesture().start(points2[0])
    for point in points2[1:]:
        gesture2 = gesture2.move_to(point, interval=interval)

    # 注入多指手势操作
    device.inject_multi_finger_gesture([gesture1, gesture2], speed=speed)
    