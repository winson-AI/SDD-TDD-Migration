import os
import sys
import argparse
from fastmcp import FastMCP
from typing import Sequence, final
from fastmcp.server.lifespan import lifespan
from fastmcp.server.transforms import Transform
from fastmcp.tools import Tool
from hypium_mcp import tools
from hypium_mcp.core.tool_loader import loader as tool_loader
from hypium_mcp.config.config import get_config
from hypium_mcp.utils.log import get_logger
from hypium_mcp.version import __version__


DEFAULT_TOOLS_PATH = os.path.dirname(tools.__file__)
DEFAULT_MCP_SERVER_NAME = "HypiumBasicTools"

logger = get_logger("Main")

@lifespan
async def resource_manager(server):
    try:
        yield {"version": __version__}
    finally:
        logger.info("Server shutdown, clean up resources")
        from hypium_mcp.tools.mcp_manager import mcp_clean_up
        mcp_clean_up()


class ServiceMode:
    STDIO = "stdio"
    STREAMABLE_HTTP = "streamable_http"


def list_tools(tools_path=None):
    """列出所有支持的tools列表"""
    from hypium_mcp.core import tool_adapter
    from hypium_mcp.device.device_manager import DeviceManager

    collected_tools = []

    def collect_tool(func):
        """自定义注册函数，只收集工具信息不注册到MCP"""
        doc = func.__doc__ or ''
        desc = doc.split('Args:')[0].split('Returns:')[0].split('使用场景:')[0].split('。')[0]
        desc = ' '.join(desc.split()).strip()
        if len(desc) > 30:
            desc = desc[:30].rstrip('. ') + '...'
        collected_tools.append((func.__name__, desc))
        return func

    driver_injector = tool_adapter.create_driver_injector(DeviceManager.get_instance().get_device)

    tool_loader.register_tools(DEFAULT_TOOLS_PATH, tool_loader.DEFAULT_TOOLS_MODULE, collect_tool, driver_injector)

    if tools_path and os.path.exists(tools_path):
        tool_loader.register_external_tools(tools_path, collect_tool, driver_injector)

    collected_tools.sort(key=lambda x: x[0])

    print("=" * 70)
    print(f"{'Tool Name':<35} Description")
    print("=" * 70)
    for name, desc in collected_tools:
        print(f"{name:<35} {desc}")
    print("=" * 70)
    print(f"\nTotal: {len(collected_tools)} tools")
    return 0


def parse_arguments():
    if len(sys.argv) > 1 and sys.argv[1] == "list":
        sys.argv.pop(1)

        tools_path = None
        for i, arg in enumerate(sys.argv):
            if arg == "--tools-path" and i + 1 < len(sys.argv):
                tools_path = sys.argv[i + 1]
                sys.argv.pop(i)
                sys.argv.pop(i)
                break

        return "list", type('Args', (), {'tools_path': tools_path})()

    config = get_config()
    default_port = config.get_port()

    parser = argparse.ArgumentParser(description="Hypium MCP Server")
    parser.add_argument(
        "--server-name",
        type=str,
        default=config.server_name,
        help=f"指定MCP服务器名称 (默认: {config.server_name})"
    )
    parser.add_argument(
        "--tools-path",
        type=str,
        help="指定MCP工具加载路径，不指定默认加载hypium内置mcp能力"
    )
    parser.add_argument(
        "--service-mode",
        type=str,
        default=config.service_mode,
        choices=["streamable-http", "stdio"],
        help=f"指定MCP服务器运行模式 (默认: {config.service_mode})"
    )
    parser.add_argument(
        "--host",
        type=str,
        default=config.host,
        help=f"指定HTTP服务监听的地址 (默认: {config.host})"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=default_port,
        help=f"指定HTTP服务监听的端口号 (默认: {default_port})"
    )
    return "server", parser.parse_args()


class FilterTestToolsTransform(Transform):
    """过滤掉测试工具"""
    
    async def list_tools(self, tools: Sequence[Tool]) -> Sequence[Tool]:
        # 核心逻辑：过滤并返回新的列表
        filtered_tools = [
            tool for tool in tools 
            if not tool.name.startswith("mcp_")  # 过滤mcp_开头的mcp自身管理工具
        ]
        return filtered_tools

def create_server(cmd_args):
    hypium_mcp_server = FastMCP(cmd_args.server_name, lifespan=resource_manager)
    hypium_mcp_server.add_transform(FilterTestToolsTransform())
    return hypium_mcp_server


def start_builtin_mcp_server(cmd_args):
    from hypium_mcp.core import tool_adapter
    from hypium_mcp.device.device_manager import DeviceManager
    # 初始化FastMCP服务器
    hypium_mcp_server = create_server(cmd_args)
    # 加载工具
    driver_injector = tool_adapter.create_driver_injector(DeviceManager.get_instance().get_device)
    tool_loader.register_tools(DEFAULT_TOOLS_PATH, tool_loader.DEFAULT_TOOLS_MODULE, hypium_mcp_server.tool,
                               driver_injector)
    # 运行MCP服务器
    if cmd_args.service_mode == ServiceMode.STDIO:
        hypium_mcp_server.run(cmd_args.service_mode)
    else:
        hypium_mcp_server.run(cmd_args.service_mode, host=cmd_args.host, port=cmd_args.port)


def start_extend_mcp_server(cmd_args):
    from hypium_mcp.core import tool_adapter
    from hypium_mcp.device.device_manager import DeviceManager
    # 初始化FastMCP服务器
    if not cmd_args.server_name:
        server_name = os.path.splitext(os.path.basename(cmd_args.tools_path))[0]
        cmd_args.server_name = server_name
    hypium_mcp_server = create_server(cmd_args)
    # 加载工具
    driver_injector = tool_adapter.create_driver_injector(DeviceManager.get_instance().get_device)
    tool_loader.register_tools(DEFAULT_TOOLS_PATH, tool_loader.DEFAULT_TOOLS_MODULE, hypium_mcp_server.tool,
                               driver_injector)
    tool_loader.register_external_tools(cmd_args.tools_path, hypium_mcp_server.tool, driver_injector)
    # 运行MCP服务器
    if cmd_args.service_mode == ServiceMode.STDIO:
        hypium_mcp_server.run(cmd_args.service_mode)
    else:
        hypium_mcp_server.run(cmd_args.service_mode, host=cmd_args.host, port=cmd_args.port)


def main():
    logger.info("version: %s", __version__)
    command, args = parse_arguments()
    if command == "list":
        return list_tools(getattr(args, 'tools_path', None))
    if args.service_mode == ServiceMode.STDIO:
        # stdio模式下, 日志不输出到控制台
        setattr(sys, "log_mode", "no_console")
    if args.tools_path:
        if not os.path.exists(args.tools_path):
            raise ValueError("No such path: %s" % args.tools_path)
        start_extend_mcp_server(args)
    else:
        start_builtin_mcp_server(args)


if __name__ == "__main__":
    main()
