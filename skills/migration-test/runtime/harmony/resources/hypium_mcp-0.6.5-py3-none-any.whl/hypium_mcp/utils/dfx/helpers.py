"""
DFX Helper Functions

Provides debugging and diagnostic utilities.
"""

import functools
import time
from typing import Any, Callable, Dict, List, Optional, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def format_device_info(device_sn: str, device_info: Dict[str, Any]) -> str:
    """
    Format device information for display or logging.

    Args:
        device_sn: Device serial number
        device_info: Device information dictionary

    Returns:
        Formatted string with device information
    """
    lines = [
        f"Device: {device_sn}",
        "-" * 40,
    ]

    for key, value in device_info.items():
        if isinstance(value, (list, dict)):
            lines.append(f"  {key}: {len(value)} items")
        else:
            lines.append(f"  {key}: {value}")

    return "\n".join(lines)


def safe_execute(
    func: Callable[..., Any],
    default: Any = None,
    log_exception: bool = True,
    raise_on_error: bool = False,
) -> Callable[..., Any]:
    """
    Decorator to safely execute a function with error handling.

    Args:
        func: Function to wrap
        default: Default return value on error
        log_exception: Whether to log exceptions
        raise_on_error: Whether to re-raise exceptions

    Returns:
        Wrapped function

    Example:
        @safe_execute(default=[], raise_on_error=False)
        def get_devices():
            return DeviceManager.list_devices()
    """
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if log_exception:
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"Error in {func.__name__}: {e}", exc_info=True)

            if raise_on_error:
                raise

            return default

    return wrapper


def measure_time(func: F) -> F:
    """
    Decorator to measure execution time of a function.

    Args:
        func: Function to wrap

    Returns:
        Wrapped function

    Example:
        @measure_time
        def long_running_task():
            time.sleep(1)
    """
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()

        import logging
        logger = logging.getLogger(__name__)
        elapsed = end_time - start_time
        logger.debug(f"{func.__name__} executed in {elapsed:.3f}s")

        return result

    return wrapper  # type: ignore


class ExecutionTimer:
    """Context manager for measuring execution time."""

    def __init__(self, name: str = "operation"):
        """
        Initialize timer.

        Args:
            name: Name of the operation being timed
        """
        self.name = name
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None

    def __enter__(self) -> "ExecutionTimer":
        self.start_time = time.perf_counter()
        return self

    def __exit__(self, *args: Any) -> None:
        self.end_time = time.perf_counter()
        self._log_result()

    @property
    def elapsed(self) -> float:
        """Get elapsed time in seconds."""
        if self.start_time is None:
            return 0.0
        end = self.end_time if self.end_time else time.perf_counter()
        return end - self.start_time

    def _log_result(self) -> None:
        """Log the timing result."""
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"{self.name} completed in {self.elapsed:.3f}s")