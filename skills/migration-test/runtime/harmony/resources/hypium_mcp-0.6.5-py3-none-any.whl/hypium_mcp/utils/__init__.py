# 延迟导入以避免循环依赖

def __getattr__(name):
    if name == "EnvVarManager":
        from hypium_mcp.utils.env import EnvVarManager
        return EnvVarManager
    if name in ("WidgetTree", "Widget", "Bounds"):
        from hypium_mcp.utils.widget_tree import WidgetTree, Widget, Bounds
        return locals()[name]
    raise AttributeError(f"module 'hypium_mcp.utils' has no attribute '{name}'")

__all__ = ["EnvVarManager", "WidgetTree", "Widget", "Bounds"]