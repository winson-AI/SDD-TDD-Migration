"""
重构后的工具模块

需要 device 参数的工具函数，配合 @with_driver 装饰器使用。
"""