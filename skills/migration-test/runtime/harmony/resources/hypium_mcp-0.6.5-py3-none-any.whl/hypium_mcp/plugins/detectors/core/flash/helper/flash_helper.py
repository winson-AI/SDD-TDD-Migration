import json
from functools import lru_cache
from typing import Generic, Iterable, Iterator, Optional, Sequence, Tuple, TypeVar

import cv2
import numpy as np
from numpy.fft import fft2, fftshift, ifft2
from sklearn.linear_model import TheilSenRegressor

from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)

enumerate_type = TypeVar('enumerate_type')


class EnumerateWithPrev(Iterator[Tuple[int, Optional[enumerate_type], enumerate_type]], Generic[enumerate_type]):
    def __init__(self, iterable: Iterable[enumerate_type], start: int = 0):
        self.iterator = iter(iterable)
        self.index = 0
        self.prev_obj = None
        self.cur_obj = None
        try:
            while start > 0:
                next(self)
                start -= 1
        except StopIteration:
            pass

    def __iter__(self):
        return self

    def __next__(self) -> Tuple[int, Optional[enumerate_type], enumerate_type]:
        self.prev_obj = self.cur_obj
        self.cur_obj = next(self.iterator)
        if self.cur_obj is None:
            raise StopIteration

        result = (self.index, self.prev_obj, self.cur_obj)
        self.index += 1
        return result


class Rect:
    """
    矩形区域
    """

    def __init__(self, x1: float, x2: float, y1: float, y2: float, width: float, height: float):
        self.x1 = x1
        self.x2 = x2
        self.y1 = y1
        self.y2 = y2
        self.width = width
        self.height = height

    @staticmethod
    def create_by_point(x1: float, y1: float, x2: float, y2: float) -> Optional['Rect']:
        try:
            x1, y1, x2, y2 = map(float, (x1, y1, x2, y2))
            width = x2 - x1
            height = y2 - y1
            return Rect(x1, x2, y1, y2, width, height)
        except Exception as e:
            logger.error(f"获取焦点窗口失败 {x1, y1, x2, y2}", exc_info=e)
            return None

    @staticmethod
    def create_by_area(x1: float, y1: float, width: float, height: float) -> Optional['Rect']:
        try:
            x1, y1, width, height = map(float, (x1, y1, width, height))
            x2 = x1 + width
            y2 = y1 + height
            return Rect(x1, x2, y1, y2, width, height)
        except Exception as e:
            logger.error(f"获取焦点窗口失败 {x1, y1, width, height}", exc_info=e)
            return None

    @staticmethod
    def create_by_contour(contour) -> Optional['Rect']:
        try:
            x, y, w, h = cv2.boundingRect(contour)
            return Rect.create_by_area(x, y, w, h)
        except Exception as e:
            logger.error(f"获取焦点窗口失败 {contour}", exc_info=e)
            return None

    @staticmethod
    def create_by_seq(points: Sequence[float]) -> Optional['Rect']:
        if points is None or len(points) == 0:
            return None
        if len(points) != 4:
            logger.error(f"矩形应该只有四个点, {points}")
            return None
        x1, y1, x2, y2 = points
        return Rect.create_by_point(x1, y1, x2, y2)

    @staticmethod
    def create_by_dict(area_dict: dict):
        x1: Optional[float] = area_dict.get("x1", None)
        y1: Optional[float] = area_dict.get("y1", None)
        x2: Optional[float] = area_dict.get("x2", None)
        y2: Optional[float] = area_dict.get("y2", None)
        width: Optional[float] = area_dict.get("width", None)
        height: Optional[float] = area_dict.get("height", None)
        if x1 is not None and y1 is not None and x2 is not None and y2 is not None:
            return Rect.create_by_point(x1, y1, x2, y2)
        elif x1 is not None and y1 is not None and width is not None and height is not None:
            return Rect.create_by_area(x1, y1, width, height)
        else:
            logger.error(f"矩形区域创建失败, {area_dict}")
            return None

    def __getitem__(self, slices: Tuple[slice] | slice | int):
        if not isinstance(slices, tuple):
            slices = (slices,)
        x_slice, y_slice = slices[:2] if len(slices) > 1 else (slices[0], None)
        if len(slices) == 1:
            x_slice = slices[0]
        elif len(slices) == 2:
            x_slice = slices[0]
            y_slice = slices[1]
        new_x1, new_x2, new_y1, new_y2 = self.x1, self.x2, self.y1, self.y2
        if isinstance(x_slice, slice):
            if x_slice.start is not None:
                new_x1 = (self.x1 if x_slice.start >= 0 else self.x2) + x_slice.start
            if x_slice.stop is not None:
                new_x2 = (self.x1 if x_slice.stop >= 0 else self.x2) + x_slice.stop
        elif isinstance(x_slice, int):
            new_x1 = new_x2 = (self.x1 if x_slice >= 0 else self.x2) + x_slice
        if isinstance(y_slice, slice):
            if y_slice.start is not None:
                new_y1 = (self.y1 if y_slice.start >= 0 else self.y2) + y_slice.start
            if y_slice.stop is not None:
                new_y2 = (self.y1 if y_slice.stop >= 0 else self.y2) + y_slice.stop
        elif isinstance(y_slice, int):
            new_y1 = new_y2 = (self.y1 if y_slice >= 0 else self.y2) + y_slice
        return Rect.create_by_point(new_x1, new_y1, new_x2, new_y2)

    @property
    def center_x(self) -> float:
        return (self.x1 + self.x2) / 2

    @property
    def center_y(self) -> float:
        return (self.y1 + self.y2) / 2

    @property
    def center(self) -> Tuple[float, float]:
        return self.center_x, self.center_y

    @property
    def area(self) -> float:
        return self.width * self.height

    @property
    def rectangle(self) -> list[int]:
        return [int(self.x1), int(self.y1), int(self.x2), int(self.y2)]

    def cut_frame(self, frame: np.ndarray, default_height: int = 0, default_width: int = 0) -> np.ndarray:
        height, width = frame.shape[:2]
        if default_height == 0:
            default_height = height
        if default_width == 0:
            default_width = width
        if default_height <= self.y1 or default_width <= self.x1:
            return frame
        return frame[int(self.y1 / default_height * height): int(min(self.y2 / default_height * height, height)),
        int(self.x1 / default_width * width): int(min(self.x2 / default_width * width, width))]

    def center_rect(self) -> 'Rect':
        return Rect.create_by_point(
            (self.x1 + self.center_x) / 2, (self.y1 + self.center_y) / 2,
            (self.x2 + self.center_x) / 2, (self.y2 + self.center_y) / 2,
        )

    def iou(self, other: 'Rect') -> float:
        """计算交并比"""
        x1 = max(self.x1, other.x1)
        y1 = max(self.y1, other.y1)
        x2 = min(self.x2, other.x2)
        y2 = min(self.y2, other.y2)

        if x2 < x1 or y2 < y1:
            return 0.0

        intersection = (x2 - x1) * (y2 - y1)
        return max(intersection / self.area, intersection / other.area)

    def max_aspect_ratio(self):
        return max(self.width / self.height, self.height / self.width)

    def __repr__(self):
        return json.dumps(self, default=lambda o: o.__dict__)


class FlashHelper:

    @staticmethod
    def is_stacked_image(prev_image_info: ScreenFlashImageInfo, curr_image_info: ScreenFlashImageInfo):
        prev_image = ImageHelper.read_gray_image(prev_image_info.image_file_path)
        curr_image = ImageHelper.read_gray_image(curr_image_info.image_file_path)
        max_image = cv2.max(prev_image, curr_image)
        diff_image = cv2.absdiff(prev_image, max_image)
        if np.sum(diff_image > 1) / max_image.size < 0.001:
            return True
        return False

    @staticmethod
    def most_common_color_ratio(gray_image: np.ndarray, rect: Rect | None = None, bias=1) -> Tuple[float, int]:
        cv2.dilate(gray_image, (5, 5), dst=gray_image, iterations=1)
        if rect is None:
            height, width = gray_image.shape[:2]
            rect = Rect.create_by_area(0, 0, width, height)
        hist = cv2.calcHist([rect.cut_frame(gray_image)], [0], None, [256], [0.0, 256.0])
        total_val = np.sum(hist)
        if total_val < 1000:
            return 0, 0
        min_hist_val, max_hist_val, min_hist_loc, max_hist_loc = cv2.minMaxLoc(hist)
        sum_val = 0
        avg_color = max_hist_loc[1]
        if -1 < avg_color < 256:
            for i in range(max(0, avg_color - bias), min(256, avg_color + bias + 1)):
                sum_val = sum_val + hist[i][0]
        min_gray_percent = round(sum_val / np.sum(hist), 3)
        return min_gray_percent, avg_color

    @staticmethod
    def match_template_ccoeff(prev_image: np.ndarray, next_image: np.ndarray) -> float:
        match_result = cv2.matchTemplate(prev_image, next_image, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(match_result)
        if max_val == 1:
            return 0
        if max_val < 0:
            return 1 - max_val
        return max_val

    @staticmethod
    def compute_f_image(image1: np.ndarray, image2: np.ndarray, use_lap: bool = False):
        image1 = image1 / 255
        image2 = image2 / 255
        if not use_lap:
            return fft2(image1, norm='backward'), fft2(image2, norm='backward')
        # 计算梯度图像作为权重
        gradient1 = cv2.Laplacian(image1, cv2.CV_64F, delta=5)
        gradient2 = cv2.Laplacian(image2, cv2.CV_64F, delta=5)

        # 取绝对值并归一化
        gradient1 = np.abs(gradient1)
        gradient2 = np.abs(gradient2)
        gradient1 /= np.max(gradient1)
        gradient2 /= np.max(gradient2)
        return fft2(image1) * gradient1, fft2(image2) * gradient2

    @staticmethod
    def compute_correlation(image1: np.ndarray, image2: np.ndarray, compute_max=True) -> np.ndarray:
        f_image1, f_image2 = FlashHelper.compute_f_image(image1, image2, False)
        correlation = f_image1 * np.conj(f_image2)
        correlation = ifft2(correlation)
        correlation = fftshift(correlation)
        if compute_max:
            correlation1 = FlashHelper.compute_correlation(image1, image1, False)
            correlation2 = FlashHelper.compute_correlation(image2, image2, False)
            max_correlation = correlation2 if np.sum(
                correlation2 > correlation1) > correlation1.size / 2 else correlation1
            correlation = np.abs(correlation) / np.max(np.abs(max_correlation))
        return correlation

    @staticmethod
    def cal_lab_uniformity(image: np.ndarray):
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        return 1 - np.mean([np.std(lab[:, :, i]) / 128 for i in range(3)])

    @staticmethod
    def phase_correlate(image1: np.ndarray, image2: np.ndarray, window=None):
        (x, y), correlate_ratio = cv2.phaseCorrelate(image1.astype(np.float32), image2.astype(np.float32), window)
        angle = abs(np.degrees(np.arctan(np.divide(y, x + 1e-5))))
        return angle, correlate_ratio

    @staticmethod
    @lru_cache(maxsize=64)
    def read_image(image_info: ScreenFlashImageInfo):
        return ImageHelper.read_image(image_info.image_file_path)

    @staticmethod
    @lru_cache(maxsize=64)
    def read_gray_image(image_info: ScreenFlashImageInfo):
        return ImageHelper.read_gray_image(image_info.image_file_path)

    LINEAR_MODEL: TheilSenRegressor = TheilSenRegressor()

    @staticmethod
    def compute_slope(value_array: np.ndarray | list, slice_array: np.ndarray | list | None = None):
        if slice_array is None:
            slice_array = np.arange(len(value_array))
        if isinstance(value_array, list):
            value_array = np.asarray(value_array)
        if isinstance(slice_array, list):
            slice_array = np.asarray(slice_array)
        slice_array = slice_array.reshape(-1, 1)
        return FlashHelper.LINEAR_MODEL.fit(slice_array, value_array)

    @staticmethod
    def find_max_change_area(diff_image: np.ndarray, threshold=8) -> Tuple[Optional[Rect], np.ndarray]:
        _, thresh = cv2.threshold(diff_image, threshold, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        mask = np.zeros_like(diff_image)
        if len(contours) == 0:
            return None, mask
        max_contour = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(max_contour)
        rect = Rect.create_by_area(x, y, w, h)
        return rect, cv2.rectangle(mask, (x, y), (x + w, y + h), 255, thickness=cv2.FILLED)

    @staticmethod
    def is_overlay_similar(prev_image: np.ndarray, next_image: np.ndarray):
        max_image = cv2.max(prev_image, next_image)
        prev_diff_image, next_diff_image = cv2.absdiff(prev_image, max_image), cv2.absdiff(next_image, max_image)
        if min(np.count_nonzero(prev_diff_image), np.count_nonzero(next_diff_image)) < 0.0005:
            return True
        return False
