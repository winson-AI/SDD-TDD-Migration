import os
import platform
import stat
import subprocess
from pathlib import Path

from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)

_RESOURCE_DIR = Path(__file__).parent.parent.joinpath("resources")


class TraceConverter:

    @classmethod
    def convert_trace(cls, trace_path: Path):
        trace_path = trace_path.absolute()
        db_path = trace_path.parent.joinpath(f"{trace_path.name}.db")
        cmd_list = [str(cls._trace_streamer_path()), str(trace_path), '-l', 'I', '-e', str(db_path)]
        logger.info(cmd_list)
        res = subprocess.run(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180, text=True)
        if res.returncode != 0:
            logger.error(f"trace转换失败，返回码: {res.returncode}, 错误: {res.stderr}")
            return None
        res_log = cls._filter_trans_log(res.stdout)
        logger.info(f"{trace_path.name} 转换结果: {res_log}")
        logger.debug(f"{trace_path.name} db 文件大小: {db_path.stat().st_size}")
        return db_path

    @classmethod
    def _trace_streamer_path(cls):
        plat = platform.system()
        trace_streamer_path = _RESOURCE_DIR.joinpath("trace_streamer_mac")
        if plat == "Windows":
            trace_streamer_path = _RESOURCE_DIR.joinpath("trace_streamer.exe")
        elif plat == "Linux":
            trace_streamer_path = _RESOURCE_DIR.joinpath("trace_streamer_linux")
        if plat != "Windows":
            os.system(f"chmod +x {trace_streamer_path}")
        return trace_streamer_path

    @classmethod
    def _filter_trans_log(cls, src_log: str) -> str:
        dst_log_list = []
        for split_line in src_log.splitlines():
            if not split_line:
                continue
            if split_line.startswith('LoadingFile'):
                continue
            if '[-I]' in split_line:
                continue
            if '[-W]' in split_line:
                continue
            dst_log_list.append(split_line)
        return ",".join(dst_log_list)