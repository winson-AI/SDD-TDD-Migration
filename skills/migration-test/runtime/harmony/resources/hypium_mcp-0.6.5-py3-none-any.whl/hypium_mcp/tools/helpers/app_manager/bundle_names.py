import os
import json
from pathlib import Path
from typing import Dict, List, Optional, Set
from .main_ability_helper import get_main_ability


_DEFAULT_BUNDLE_NAMES = {
    "百度": "com.baidu.baiduapp",
    "阿里巴巴": "com.alibaba.wireless_hmos",
    "WPS": "cn.wps.mobileoffice.hap",
    "企业微信": "com.tencent.wework.hmos",
    "同程": "com.tongcheng.hmos",
    "同程旅行": "com.tongcheng.hmos",
    "唯品会": "com.vip.hosapp",
    "支付宝": "com.alipay.mobile.client",
    "UC浏览器": "com.uc.mobile",
    "闲鱼": "com.taobao.idlefish4ohos",
    "转转": "com.zhuanzhuan.hmoszz",
    "迅雷": "com.xunlei.thunder",
    "搜狗输入法": "com.sogou.input",
    "扫描全能王": "com.intsig.camscanner.hap",
    "美图秀秀": "com.meitu.meitupic",
    "58同城": "com.wuba.life",
    "得物": "com.dewu.hos",
    "海底捞": "com.haidilao.haros",
    "中国移动": "com.droi.tong",
    "中国联通": "com.sinovatech.unicom.ha",
    "国家税务总局": "cn.gov.chinatax.gt4.hm",
    "建设银行": "com.ccb.mobilebank.hm",
    "快手极速版": "com.kuaishou.hmnebula",
    "央视频": "com.cctv.yangshipin.app.harmonyp",
    "浏览器": "com.huawei.hmos.browser",
    "计算器": "com.huawei.hmos.calculator",
    "日历": "com.huawei.hmos.calendar",
    "相机": "com.huawei.hmos.camera",
    "时钟": "com.huawei.hmos.clock",
    "闹钟": "com.huawei.hmos.clock",
    "云盘": "com.huawei.hmos.clouddrive",
    "云空间": "com.huawei.hmos.clouddrive",
    "邮件": "com.huawei.hmos.email",
    "文件管理器": "com.huawei.hmos.filemanager",
    "文件": "com.huawei.hmos.files",
    "查找设备": "com.huawei.hmos.finddevice",
    "查找手机": "com.huawei.hmos.finddevice",
    "录音机": "com.huawei.hmos.soundrecorder",
    "录音": "com.huawei.hmos.soundrecorder",
    "录屏": "com.huawei.hmos.screenrecorder",
    "截屏": "com.huawei.hmos.screenshot",
    "笔记": "com.huawei.hmos.notepad",
    "备忘录": "com.huawei.hmos.notepad",
    "相册": "com.huawei.hmos.photos",
    "图库": "com.huawei.hmos.photos",
    "联系人": "com.ohos.contacts",
    "通讯录": "com.ohos.contacts",
    "短信": "com.ohos.mms",
    "信息": "com.ohos.mms",
    "电话": "com.ohos.callui",
    "拨号": "com.ohos.callui",
    "设置": "com.huawei.hmos.settings",
    "系统设置": "com.huawei.hmos.settings",
    "健康": "com.huawei.hmos.health",
    "运动健康": "com.huawei.hmos.health",
    "地图": "com.huawei.hmos.maps.app",
    "华为地图": "com.huawei.hmos.maps.app",
    "钱包": "com.huawei.hmos.wallet",
    "华为钱包": "com.huawei.hmos.wallet",
    "智慧生活": "com.huawei.hmos.ailife",
    "智能助手": "com.huawei.hmos.vassistant",
    "小艺": "com.huawei.hmos.vassistant",
    "应用市场": "com.huawei.hmsapp.appgallery",
    "华为应用市场": "com.huawei.hmsapp.appgallery",
    "音乐": "com.huawei.hmsapp.music",
    "华为音乐": "com.huawei.hmsapp.music",
    "主题": "com.huawei.hmsapp.thememanager",
    "主题管理": "com.huawei.hmsapp.thememanager",
    "天气": "com.huawei.hmsapp.totemweather",
    "华为天气": "com.huawei.hmsapp.totemweather",
    "视频": "com.huawei.hmsapp.himovie",
    "华为视频": "com.huawei.hmsapp.himovie",
    "阅读": "com.huawei.hmsapp.books",
    "华为阅读": "com.huawei.hmsapp.books",
    "游戏中心": "com.huawei.hmsapp.gamecenter",
    "华为游戏中心": "com.huawei.hmsapp.gamecenter",
    "搜索": "com.huawei.hmsapp.hisearch",
    "华为搜索": "com.huawei.hmsapp.hisearch",
    "指南针": "com.huawei.hmsapp.compass",
    "会员中心": "com.huawei.hmos.myhuawei",
    "我的华为": "com.huawei.hmos.myhuawei",
    "华为会员": "com.huawei.hmos.myhuawei",
}

_TOP_225_APP = {
    "360AI办公": "com.qihoo.aiwork.hms",
    "360浏览器": "com.qihoo.hms.browser",
    "58同城": "com.wuba.life",
    "BOSS直聘": "com.bzl.bosszhipin",
    "CAD快速看图": "com.yuntu.cadreader",
    "CAD看图王": "com.gstarcad.hmos.mobile",
    "Keep": "com.gotokeep.hm.keep",
    "Kimi": "com.hos.moonshot.kimichat",
    "QQ": "com.tencent.mqq",
    "QQ浏览器": "com.tencent.mtthm",
    "QQ邮箱": "com.tencent.qqmail.hmos",
    "QQ阅读": "com.yuewen.qqreaderhm",
    "QQ音乐": "com.tencent.hm.qqmusic",
    "T3出行": "hos.com.t3go.passenger",
    "UC浏览器": "com.uc.mobile",
    "WPS移动版": "cn.wps.mobileoffice.hap",
    "YY": "com.yy.mobile",
    "e充电": "com.sgcc.evs.charge",
    "七猫免费小说": "com.qimao.novel",
    "下厨房": "com.xiachufang",
    "东方航空": "com.ceair.hos",
    "东方财富": "com.eastmoney.hmn.berlin",
    "中信银行": "cn.citicbank.wap",
    "中国农业银行": "com.bankabc.openharmonyapp.release",
    "中国工商银行": "com.icbc.harmonyclient",
    "中国建设银行": "com.ccb.mobilebank.hm",
    "中国电信": "com.example.ctclient",
    "中国移动": "com.chinamobile.cmcc",
    "中国移动云盘": "com.chinamobile.hosmcloud",
    "中国联通": "com.sinovatech.unicom.ha",
    "中国银河证券": "cn.com.chinastock.stock",
    "中国银行": "com.boc.bocsoft.mbs.personal",
    "中油好客e站": "com.sunboxsoft.charge.institute",
    "书旗小说": "com.shuqi.hmos",
    "买单吧": "com.bankcomm.app.maidanba",
    "云闪付": "com.unionpay.hmos.wallet",
    "交通银行": "com.bankcomm.mobshos",
    "京东": "com.jd.hm.mall",
    "京东金融": "com.jd.jrapp.hongmeng",
    "亲宝宝": "com.dw.btimeharmony",
    "人民日报": "com.peopledailychina.hosactivity",
    "今日头条": "com.ss.hm.article.news",
    "今日水印相机": "com.jinrishuiyinxiangji.camera",
    "企查查": "com.qcc.hm",
    "优酷视频": "com.youku.next",
    "作业帮": "com.zuoyebang.homework",
    "儿歌多多": "com.duoduo.hm.erge",
    "光大银行": "com.cebbank.mobile.cembhmwork",
    "全民K歌": "com.tencent.karaokehm",
    "兴业证券优理宝": "com.xyzq.harmonynext.ulbclient",
    "兴业银行": "com.cib.cibmbhmos.proddev",
    "凤凰新闻": "com.ifeng.news.hmos",
    "凯叔讲故事": "com.ks.ukstorynext",
    "剪映": "com.lemon.hm.lv",
    "动卡空间": "com.citiccard.ohap.dkkj",
    "华夏银行": "com.hxb.mobile.hm",
    "南方航空": "com.csair.mbphm",
    "去哪儿旅行": "com.qunar.hos",
    "同程旅行": "com.tongcheng.hmos",
    "同花顺": "com.hexin.hmn.sjcg",
    "咪咕视频": "com.cmcc.cmvideohm",
    "哈啰": "com.hellobike.app",
    "哔哩哔哩": "yylx.danmaku.bili",
    "唯品会": "com.vip.hosapp",
    "喜马拉雅": "com.ximalaya.ting.xmharmony",
    "嘀嗒出行": "com.didapinche.passenger",
    "四川航空": "cn.com.scal.sichuanair",
    "回森": "com.hisense.app",
    "国泰君安君弘": "com.gtja.junhong.hm.next",
    "墨迹天气": "com.moji.hmweather",
    "大众点评": "com.sankuai.dianping",
    "大学搜题酱": "com.daxuesoutijiang.hm",
    "大智慧": "com.gw.ohphone",
    "大麦": "cn.damai.hongmeng",
    "天猫": "com.tmall.tmall4hmos",
    "天眼查": "com.tianyancha.skyeye.hm",
    "央广网": "cn.cnr.cnrnetohos",
    "央视影音": "com.cctv.cbox",
    "央视新闻": "cn.cctvnews.hm",
    "央视频": "com.cctv.yangshipin.app.harmonyp",
    "夸克有爱": "com.quark.ohosbrowser.lover",
    "好看视频": "com.baidu.haokanapp",
    "学习通": "com.xuexitong.study",
    "安居客": "com.anjuke.home",
    "宝宝巴士": "com.sinyee.babybus.recommendapp.hos",
    "宝宝巴士世界": "com.sinyee.babybus.world.hos",
    "小猿AI": "com.kanyun.hos.leo",
    "小猿搜题": "com.kanyun.hos.solar",
    "小红书": "com.xingin.xhs_hos",
    "小鹅通学员版": "com.xiaoe.client.huawei",
    "帆书": "com.fanshu.book",
    "平安口袋银行": "com.pingan.bank.pocket",
    "平安好车主": "com.pingan.oharm.carowner",
    "平安金管家": "com.pingan.palifeapp",
    "得物": "com.dewu.hos",
    "微信": "com.tencent.wechat",
    "微信读书": "com.tencent.weread.hmos",
    "微博": "com.sina.weibo.stage",
    "快对": "com.kuaiduizuoye.hm",
    "快影": "com.kwai.videoeditor.hmapp",
    "懂车帝": "com.ss.dcar.auto",
    "懒人听书": "bubei.tingshu.hos",
    "扫描全能王": "com.intsig.camscanner.hap",
    "抖音": "com.ss.hm.ugc.aweme",
    "招商银行": "com.cmbchina.harmony",
    "拼多多": "com.xunmeng.pinduoduo.hos",
    "掌上华医": "com.huayi.zshy",
    "掌上生活": "com.cmbchina.ccc.cmblife",
    "搜狐新闻": "com.sohu.harmonynews",
    "搜狗输入法": "com.tencent.sogou.input",
    "携程旅行": "com.ctrip.harmonynext",
    "支付宝": "com.alipay.mobile.client",
    "政务微信": "com.tencent.weworklocal.hmos",
    "新华社": "net.xinhuamm.xhshos",
    "新浪新闻": "com.sina.news.hm.next",
    "易车": "com.yiche.autoeasyh",
    "晋江小说阅读": "com.jjwxc.jjharmony.reader",
    "智行火车票": "com.suanya.harmonynext",
    "朴朴超市": "com.pupu.app",
    "民生银行": "cn.com.cmbc.ohmbank",
    "汽水音乐": "com.luna.hm.music",
    "汽车之家": "com.autohome.main",
    "洪恩识字": "com.ihuman.words",
    "浙里办": "com.szzj.zlb",
    "浦发银行": "cn.com.spdb.mobilebank.hos.per",
    "海南航空": "com.hnair.app",
    "涨乐财富通": "com.htsc.zlcft.org",
    "淘宝": "com.taobao.taobao4hmos",
    "淘宝特价版": "com.taobao.litetao4harmony",
    "深圳航空": "com.sz.air.hmOS",
    "滴滴出行": "com.sdu.didi.hmos.psnger",
    "点淘": "com.taobao.taobaolive4hmos",
    "爱奇艺": "com.qiyi.video.hmy",
    "瑞幸咖啡": "com.lucky.luckincoffee",
    "瓜子二手车": "com.ganji.android.haoche_c",
    "番茄免费小说": "com.dragon.read.next",
    "番茄畅听": "com.xs.fm.next",
    "百度": "com.baidu.baiduapp",
    "百度地图": "com.baidu.hmmap",
    "百度文库": "com.baidu.hmwenku",
    "百度网盘": "com.baidu.netdisk.hmos",
    "百度贴吧": "com.baidu.tiebaapp",
    "百度输入法": "com.baidu.input_harmony",
    "百词斩": "com.baicizhan.bcz.hm",
    "盒马": "com.wudaokou.hippo_hmos",
    "直播吧": "com.zhibo8.hmclient",
    "知乎": "com.zhihu.hmos",
    "移动爱家": "com.cmcc.DigitalHome",
    "粉笔": "com.fenbi.gwy",
    "糖豆": "com.xttangdou.dances",
    "纳米AI搜索": "com.qihoo.namiso.h",
    "网上国网": "com.wsgw.harmony1",
    "网易有道词典": "com.hm.youdao",
    "美团": "com.sankuai.hmeituan",
    "美团外卖": "com.meituan.takeaway",
    "美图秀秀": "com.meitu.meitupic",
    "美颜相机": "com.meitu.beautycam",
    "腾讯会议": "com.tencent.meeting.app",
    "腾讯体育": "com.tencent.qqsports.hm",
    "腾讯新闻": "com.tencent.hm.news",
    "腾讯视频": "com.tencent.videohm",
    "航旅纵横": "com.umetrip.hm.app",
    "航班管家": "com.openet.hbgj",
    "芒果TV": "com.mgtv.phone",
    "菜鸟": "com.cainiao.cainiao4hmos",
    "萤石云视频": "com.ezviz.videogo",
    "蜻蜓FM": "fm.qtradio.hm",
    "西瓜视频": "com.ss.hm.article.video",
    "讯飞听见": "com.iflyrec.hmtjapp",
    "讯飞输入法": "com.iflytek.inputmethod.iFlytekInputIME",
    "豆包": "com.larus.nova.hm",
    "豆瓣": "com.douban.frodo.hap",
    "贝壳找房": "com.beike.hongmeng",
    "货拉拉": "com.lalamove.huolala.clienthar",
    "起点读书": "com.qidian.reader",
    "车来了": "com.ygkj.chelaile.standard.har",
    "转转": "com.zhuanzhuan.hmoszz",
    "迅雷": "com.xunlei.thunder",
    "途虎养车": "com.tuhu.tuhuharmony",
    "邮储银行": "com.psbc.mbank.hm",
    "酷我音乐": "com.hmkuwo.cn",
    "酷狗音乐": "com.kugou.hmmusic",
    "醒图": "com.app.xt.retouch",
    "钉钉": "com.dingtalk.hmos",
    "铁路12306": "com.chinarailway.ticketingHM",
    "链家": "com.lianjia.hongmeng",
    "闲鱼": "com.taobao.idlefish4ohos",
    "阿里巴巴": "com.alibaba.wireless_hmos",
    "顺丰速运": "com.sfexpress.mainlandapp",
    "领导留言板": "cn.people.messageboard",
    "飞书": "com.ss.feishu",
    "飞常准": "com.feeyo.variflight",
    "飞猪": "com.fliggy.harmony",
    "饿了么": "me.ele.eleme",
    "驾校一点通": "com.jiaxiao.driveharmony",
    "驾考宝典": "cn.mucang.hm.jiakao",
    "高德地图": "com.amap.hmapp",
    "高铁管家": "com.openet.gtgj",
}


class BundleNameManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        self._display_to_bundle: Dict[str, str] = {}
        self._bundle_to_displays: Dict[str, List[str]] = {}
        self._bundle_to_main_ability: Dict[str, str] = {}

        self._load_default_data()
        self._load_from_config_files()

    def _load_default_data(self):
        default_data = {}
        default_data.update(_DEFAULT_BUNDLE_NAMES)
        default_data.update(_TOP_225_APP)

        for display_name, bundle_name in default_data.items():
            self._display_to_bundle[display_name] = bundle_name
            if bundle_name not in self._bundle_to_displays:
                self._bundle_to_displays[bundle_name] = []
            self._bundle_to_displays[bundle_name].append(display_name)

    def _load_from_config_files(self):
        config_paths = [
            Path.home() / ".hypium_mcp" / "app_config.json",
            Path.cwd() / "app_config.json",
        ]

        for config_path in config_paths:
            if config_path.exists():
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    self._merge_config(config)
                except Exception:
                    pass

    def _merge_config(self, config: dict):
        if "bundle_names" in config:
            for display_name, bundle_name in config["bundle_names"].items():
                self._display_to_bundle[display_name] = bundle_name
                if bundle_name not in self._bundle_to_displays:
                    self._bundle_to_displays[bundle_name] = []
                if display_name not in self._bundle_to_displays[bundle_name]:
                    self._bundle_to_displays[bundle_name].append(display_name)

        if "main_abilities" in config:
            for bundle_name, ability_name in config["main_abilities"].items():
                self._bundle_to_main_ability[bundle_name] = ability_name

    def load_config(self, config_path: str):
        path = Path(config_path)
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                config = json.load(f)
            self._merge_config(config)

    def get_bundle_name_by_display_name(self, display_name: str) -> Optional[str]:
        return self._display_to_bundle.get(display_name)

    def get_display_name_by_bundle_name(self, bundle_name: str) -> List[str]:
        return self._bundle_to_displays.get(bundle_name, [])

    def get_main_ability_by_bundle_name(self, bundle_name: str) -> Optional[str]:
        return self._bundle_to_main_ability.get(bundle_name)

    def register_app(self, display_name: str, bundle_name: str, main_ability: Optional[str] = None):
        self._display_to_bundle[display_name] = bundle_name
        if bundle_name not in self._bundle_to_displays:
            self._bundle_to_displays[bundle_name] = []
        if display_name not in self._bundle_to_displays[bundle_name]:
            self._bundle_to_displays[bundle_name].append(display_name)
        if main_ability:
            self._bundle_to_main_ability[bundle_name] = main_ability

    def all_bundle_names(self) -> Set[str]:
        return set(self._display_to_bundle.values())

    def all_display_names(self) -> Set[str]:
        return set(self._display_to_bundle.keys())


_manager = BundleNameManager()


def get_bundle_name_by_display_name(display_name: str) -> Optional[str]:
    return _manager.get_bundle_name_by_display_name(display_name)


def get_display_name_by_bundle_name(bundle_name: str) -> List[str]:
    return _manager.get_display_name_by_bundle_name(bundle_name)


def get_main_ability_by_bundle_name(bundle_name: str, driver=None) -> Optional[str]:
    """
    获取应用的主能力

    Args:
        bundle_name: 应用的包名
        driver: 用于获取应用信息的设备驱动

    Returns:
        应用的主能力名称，或 None 如果未找到
    """
    result = _manager.get_main_ability_by_bundle_name(bundle_name)
    if result:
        return result
    if driver:
        result = get_main_ability(driver, bundle_name)
        if result:
            return result.get("name", "EntryAbility")
    return None


def load_config(config_path: str):
    _manager.load_config(config_path)


def register_app(display_name: str, bundle_name: str, main_ability: Optional[str] = None):
    _manager.register_app(display_name, bundle_name, main_ability)


def get_manager() -> BundleNameManager:
    return _manager
