import json
import os.path
from pathlib import Path

from hypium_mcp.config.config import get_config
from hypium_mcp.plugins.collectors.core.base_collector import BaseCollector
from hypium_mcp.plugins.collectors.core.stability_collector import StabilityCollector
from hypium_mcp.plugins.collectors.core.trace_collector import TraceCollector
from hypium_mcp.plugins.collectors.core.video_collector import VideoCollector
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Collector)


class CollectorManager:
    """
    数据采集管理
    为对齐概念，将每次的 mcp 调用视为特殊用例，但是一个用例只有一步
    """

    collector_types: list[type[BaseCollector]] = [StabilityCollector, VideoCollector, TraceCollector]
    collectors: list[BaseCollector] = []

    config = get_config()

    __init_finish: bool = False

    _action_idx = 1

    @classmethod
    def init(cls):
        if cls.__init_finish:
            return
        if os.getenv("HYPIUM_MCP_VIDEO_ENABLE") == "False":
            cls.collector_types.remove(VideoCollector)
        cls.collectors = [c() for c in cls.collector_types]
        logger.info(f"初始化 {len(cls.collectors)} 个采集器")

    @classmethod
    def case_start(cls):
        if not cls.__init_finish:
            CollectorManager.init()
            cls.__init_finish = True
        for collector in cls.collectors:
            try:
                collector.case_start()
            except Exception as e:
                logger.error(f"{collector.name()}采集器执行异常 case_start: {e}", exc_info=e)

    @classmethod
    def case_stop(cls):
        for collector in cls.collectors:
            try:
                collector.case_stop()
            except Exception as e:
                logger.error(f"{collector.name()}采集器执行异常 case_stop: {e}", exc_info=e)

    @classmethod
    def action_start(cls):
        os.makedirs(cls.get_action_path(), exist_ok=True)
        for collector in cls.collectors:
            try:
                collector.action_start(cls.get_action_id())
            except Exception as e:
                logger.error(f"{collector.name()}采集器执行异常 action_start: {e}", exc_info=e)

    @classmethod
    def action_stop(cls):
        for collector in cls.collectors:
            try:
                collector.action_stop(cls.get_action_id())
            except Exception as e:
                logger.error(f"{collector.name()}采集器执行异常 action_stop: {e}", exc_info=e)
        cls._action_idx += 1

    @classmethod
    def get_action_id(cls)-> str:
        return str(cls._action_idx)

    @classmethod
    def get_action_path(cls) -> str:
        return os.path.join(cls.config.output_dir, cls.get_action_id())

    @classmethod
    def dump_context(cls, param_dict: dict) -> Path:
        param_dict["id"] = cls.get_action_id()
        json_path = Path(cls.get_action_path()).joinpath("context.json")
        json_path.write_text(json.dumps(param_dict), encoding="utf-8")
        return json_path
