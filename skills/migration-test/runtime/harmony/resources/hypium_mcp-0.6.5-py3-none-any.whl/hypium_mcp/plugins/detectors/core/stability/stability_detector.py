import json
import os.path
from enum import Enum
from pathlib import Path
from typing import Any

from hypium_mcp.plugins.detectors.core.base_detector import BaseDetector
from hypium_mcp.plugins.detectors.core.detection_result import DetectionResult
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)


class StabilityType(Enum):
    ADDR_SANITIZER = "ADDR_SANITIZER"
    JS_ERROR = "JS_ERROR"
    CPP_CRASH = "CPP_CRASH"
    FD_LEAK = "FD_LEAK"
    APP_FREEZE = "APP_FREEZE"
    MEMORY_LEAK = "MEMORY_LEAK"
    THREAD_LEAK = "THREAD_LEAK"


class StabilityDetector(BaseDetector):

    @classmethod
    def detect(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        """
        Args:
            arg_dict: json_path: 采集到的系统数据 json 存放位置
        """
        json_path = arg_dict.get("json_path", None)
        if json_path is None or not os.path.exists(json_path):
            return DetectionResult.error(f"缺失数据结果 {json_path}，无法检测稳定性问题")

        error_dict: dict[str, int] = {}
        all_infos: list[dict[str, Any]] = json.loads(Path(json_path).read_text(encoding="utf-8"))
        for json_info in all_infos:
            for stability_type in StabilityType:
                if stability_type.value in json_info:
                    error_dict[stability_type.value] = json_info.get(stability_type.value, 0) or 0
        logger.info(f"稳定性---数据分析汇总: {error_dict}")
        total_count = sum(error_dict.values())
        if total_count > 0:
            return DetectionResult.success(f"检测到稳定性问题: {error_dict}", error_dict)
        return DetectionResult.success("应用无稳定性问题", error_dict)
