import logging
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from typing import List

import cv2
import numpy as np
from hypium_mcp.plugins.detectors.core.action_type import ActionType
from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import EnumerateWithPrev, FlashHelper, Rect
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import BaseFlashImageInfo, \
    ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.stable.base_stable_analyzer import BaseStableAnalyzer
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper


class PureStableImageInfo(BaseFlashImageInfo):

    def __init__(self, image_info: ScreenFlashImageInfo):
        super().__init__(image_info)
        self.prev_image_info: PureStableImageInfo | None = None
        self.next_image_info: PureStableImageInfo | None = None
        self.rect_list = []

    @property
    def value(self):
        return self.template_similarity

    def max_rect_area(self) -> int:
        if len(self.rect_list) == 0:
            return 0
        return max([rect.area for rect in self.rect_list])

    def sum_rect_area(self) -> int:
        if len(self.rect_list) == 0:
            return 0
        return sum([rect.area for rect in self.rect_list])

    def is_same_image(self, image_size: int) -> bool:
        if self.template_similarity < FlashParams.STABLE_RATIO:
            return False
        return self.max_rect_area() / image_size < 0.01


class CheckImageInfo:
    def __init__(self, curr_image_info: PureStableImageInfo, prev_image_info: PureStableImageInfo | None = None):
        self.prev_image_info = prev_image_info
        self.curr_image_info = curr_image_info
        self.rect_template_similarity = 1.0
        self.rect_diff_ratio = 0.0
        self.rect_pure_pixel = 255
        self.rect_pure_ratio = 0.0
        self.rect_brightness = 0.0
        self.rect_contrast_ratio = 0.0
        if self.prev_image_info is None:
            self.prev_image_info = curr_image_info

    @property
    def image_time(self):
        return self.curr_image_info.image_time

    @property
    def start_time(self):
        return self.prev_image_info.image_time

    @property
    def image_file_path(self):
        return self.curr_image_info.image_file_path

    @property
    def template_similarity(self):
        return self.curr_image_info.template_similarity

    @property
    def sum_rect_area(self) -> int:
        return self.prev_image_info.sum_rect_area()


class PureStableAnalyzer(BaseStableAnalyzer):

    def __init__(self, flash_params: FlashParams):
        super().__init__(flash_params)
        self.executor = ThreadPoolExecutor(max_workers=8)
        self.error_rect_info: ErrorRectInfo | None = None

    def compare_image_info(self, prev_image_info: ScreenFlashImageInfo,
                           curr_image_info: ScreenFlashImageInfo) -> PureStableImageInfo:
        stable_image_info = PureStableImageInfo(curr_image_info)
        if prev_image_info is None:
            prev_image_info = curr_image_info.prev_image_info
            if prev_image_info is None:
                return stable_image_info
        diff_image = cv2.absdiff(ImageHelper.read_gray_image(prev_image_info.image_file_path),
                                 ImageHelper.read_gray_image(curr_image_info.image_file_path))
        _, threshold_image = cv2.threshold(diff_image, 5, 255, cv2.THRESH_BINARY)
        # 形态学去噪
        threshold_image = cv2.morphologyEx(threshold_image, cv2.MORPH_CLOSE,
                                           cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)))
        threshold_image = cv2.morphologyEx(threshold_image, cv2.MORPH_OPEN,
                                           cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
        # 连通区域分析
        contours, _ = cv2.findContours(threshold_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours is None:
            contours = []
        # 标记异常区域
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            rect = Rect.create_by_area(x, y, w, h)
            if FlashParams.filter_rect_app_factory(rect, diff_image.shape[0], diff_image.shape[1]):
                continue
            stable_image_info.rect_list.append(Rect.create_by_area(x, y, w, h))
        return stable_image_info

    def analyze_image_info_list(self, image_info_list: List[PureStableImageInfo]):
        for index, prev_image_info, next_image_info in EnumerateWithPrev(image_info_list, start=1):
            prev_image_info.next_image_info = next_image_info
            next_image_info.prev_image_info = prev_image_info
        flash_info_list = []
        # 异常记录信息存储
        self.error_rect_info = ErrorRectInfo()
        prev_image_info = image_info_list[0]
        image_height, image_width = ImageHelper.read_gray_image(prev_image_info.image_file_path).shape[:2]
        self.error_rect_info.first_error_time = prev_image_info.image_time
        for curr_image_info in image_info_list:
            # 由于图像一致, 因此更新最后一张图的信息
            if curr_image_info.is_same_image(image_height * image_width):
                self.error_rect_info.update_last_image_info(curr_image_info)
                continue
            kpi_flash_info = self.check_flash_rect_list(curr_image_info)
            if kpi_flash_info:
                flash_info_list.append(kpi_flash_info)
                self.error_rect_info.clean_history_record(curr_image_info.image_time)
            if len(curr_image_info.rect_list) > 0:
                self.error_rect_info.add_error_rects(curr_image_info, curr_image_info.rect_list, prev_image_info \
                    if prev_image_info.image_time == image_info_list[0].image_time else None)
                # 更新前一帧
                prev_image_info = curr_image_info
        for image_info in image_info_list:
            image_info.prev_image_info = None
            image_info.next_image_info = None
        return flash_info_list

    def check_flash_rect_list(self, curr_image_info: PureStableImageInfo) -> KpiFlashInfo | None:
        # 计算当前时间窗口内, 异常区域的变化情况
        future_list: List[Future] = []
        for curr_rect in curr_image_info.rect_list:
            future_list.append(self.executor.submit(self.check_flash_rect, curr_image_info, curr_rect))
        for future in as_completed(future_list):
            kpi_flash_info = future.result()
            if kpi_flash_info:
                return kpi_flash_info
        return None

    def check_flash_rect(self, curr_image_info: PureStableImageInfo, curr_rect: Rect) -> KpiFlashInfo | None:
        check_image_list = self.build_check_image_list(curr_image_info, curr_rect)
        if len(check_image_list) < 3:
            return None
        for index, prev_image_info, next_image_info in EnumerateWithPrev(check_image_list, start=1):
            prev_image = curr_rect.cut_frame(
                ImageHelper.read_gray_image(prev_image_info.curr_image_info.image_file_path))
            next_image = curr_rect.cut_frame(
                ImageHelper.read_gray_image(next_image_info.curr_image_info.image_file_path))
            prev_image_info.rect_template_similarity = FlashHelper.match_template_ccoeff(prev_image, next_image)
            next_image_info.rect_diff_ratio = np.sum(cv2.absdiff(prev_image, next_image) > 3) / curr_rect.area
        for index, image_info in enumerate(check_image_list):
            gray_image = curr_rect.cut_frame(ImageHelper.read_gray_image(image_info.curr_image_info.image_file_path))
            image_info.rect_pure_ratio, image_info.rect_pure_pixel = FlashHelper.most_common_color_ratio(gray_image)
            image_info.rect_brightness = gray_image.mean()
            image_info.rect_contrast_ratio = image_info.rect_brightness * 100 / 255
        change_start_index = -1
        for index, stable_image_info in enumerate(check_image_list[1:-1], start=1):
            if 1 >= stable_image_info.rect_template_similarity >= 0.9 > stable_image_info.rect_diff_ratio:
                continue
            change_start_index = index
            break
        if change_start_index == -1:
            return None
        prev_image_info, curr_image_info, next_image_info = \
            check_image_list[change_start_index + 1], check_image_list[change_start_index], check_image_list[0]
        if not self.check_flash_image(prev_image_info, curr_image_info, next_image_info, curr_rect):
            return None
        flash_info = KpiFlashInfo.build(prev_image_info.curr_image_info.image_info,
                                        next_image_info.curr_image_info.image_info)
        logging.debug(flash_info)
        return flash_info

    class StableFlashCheck:

        def __init__(self, prev_image_info: CheckImageInfo, curr_image_info: CheckImageInfo,
                     next_image_info: CheckImageInfo, curr_rect: Rect, flash_params: FlashParams):
            self.prev_image_info = prev_image_info
            self.curr_image_info = curr_image_info
            self.next_image_info = next_image_info
            self.flash_time = self.next_image_info.image_time - self.curr_image_info.start_time
            self.curr_rect = curr_rect
            self.flash_params = flash_params

            prev_gray = self.read_image_info(self.prev_image_info, read_rect=False)
            curr_gray = self.read_image_info(self.curr_image_info, read_rect=False)
            next_gray = self.read_image_info(self.next_image_info, read_rect=False)
            self.prev_global_pure_ratio, _ = FlashHelper.most_common_color_ratio(prev_gray)
            prev_rect_gray = self.curr_rect.cut_frame(prev_gray)
            curr_rect_gray = self.curr_rect.cut_frame(curr_gray)
            next_rect_gray = self.curr_rect.cut_frame(next_gray)

            # 当前矩形的占比
            self.rect_ratio = round(curr_rect.area / prev_gray.size, 3)
            # 本次所有变化区域占比的总和
            self.sum_change_ratio = self.curr_image_info.sum_rect_area / curr_gray.size
            # 上一张图和当前图的相关性
            _, self.curr_rect_correlate = FlashHelper.phase_correlate(prev_rect_gray, curr_rect_gray)
            # 当前图和下一张图的相关性
            _, self.next_rect_correlate = FlashHelper.phase_correlate(curr_rect_gray, next_rect_gray)
            # 三张图之间相关性的最大值
            self.max_rect_correlate = max(self.curr_rect_correlate, self.next_rect_correlate)

            self.exist_in_next = max(
                FlashHelper.match_template_ccoeff(curr_rect_gray, next_gray),
                FlashHelper.match_template_ccoeff(curr_rect_gray, prev_gray),
                FlashHelper.match_template_ccoeff(next_rect_gray, curr_gray),
                FlashHelper.match_template_ccoeff(prev_rect_gray, curr_gray),
            ) > 0.5

            # 首尾局部区域的相似度
            self.edge_rect_similarity = FlashHelper.match_template_ccoeff(prev_rect_gray, next_rect_gray)
            # 首尾全局的相似度
            self.edge_similarity = FlashHelper.match_template_ccoeff(prev_gray, next_gray)

        def check(self):
            count = 0
            self._log(f"检查时间段, 矩形比例: {self.rect_ratio}")
            image_info = self.next_image_info.curr_image_info
            while image_info is not None and image_info.image_time != self.curr_image_info.start_time:
                image_info = image_info.prev_image_info
                count += 1
            if count > 10:
                self._log(f"刷帧数 {count}, 跳过检测")
                return False
            return self.check_scene_change() or self.check_white_trans() or self.check_content_flash()

        def check_scene_change(self):
            """
            检查连续的场景切换
            :return:
            """
            # 变化区域大, 对比度跳变大, 算闪
            if self.rect_ratio > 0.05 and np.all(np.abs(np.diff(self.rect_contrast_ratio_list)) > 50) \
                    and (self.rect_ratio > 0.5 or self.prev_global_pure_ratio < 0.8):
                return True
            # 两边相似度高, 中间相似度低, 算闪
            if self.edge_similarity > 0.9 and max(self.template_similarity_list) < 0.6:
                return True
            # 后两张纯色, 或变化区域小, 跳过
            if max(self.rect_pure_ratio_list[1:]) > 0.8 or self.rect_ratio < 0.05:
                return False
            # 第一张变化区域纯色, 或者全局纯色且后两张相似度高, 跳过
            if self.prev_rect_pure_ratio > 0.9 and (
                    self.next_rect_correlate > 0.5 or self.prev_global_pure_ratio > 0.8):
                return False
            # 当前模板相似度高, 且纯色区域相差不大, 跳过
            for i in range(1, 3):
                if (1 >= self.template_similarity_list[i] > 0.5) and (
                        self.rect_pure_ratio_list[i - 1] - self.rect_pure_ratio_list[i]) <= 0.4:
                    return False
            # 最高相关性 > 0.5, 跳过
            if self.max_rect_correlate > 0.5:
                return False
            if self.rect_ratio < 0.4 and self.exist_in_next:
                return False
            if self.rect_ratio > 0.5 and np.all(np.abs(np.diff(self.rect_brightness_list)) < 10):
                return False
            if self.prev_rect_pure_ratio > 0.85:
                if max(self.curr_rect_pure_ratio, self.next_rect_pure_ratio) < 0.7:
                    return False
                return self.flash_time < 100
            if self.is_monotonic(self.rect_contrast_ratio_list) and self.is_monotonic(self.rect_brightness_list):
                return False
            return self.flash_time < 200

        def check_white_trans(self):
            """
            检查中间帧是纯色屏的场景
            :return:
            """
            # 面积大于屏幕的 1%
            if self.rect_ratio < 0.01:
                return False
            if self.flash_params.action_type in ActionType.CLICK and self.rect_ratio < 0.1 and \
                    self.edge_similarity < 0.8:
                return False
            # 1. 三帧相似度不能太高（第一帧无对比对象，剔除）
            if 1 >= min(self.rect_template_similarity_list[1:]) > 0.9 or \
                    (min(self.template_similarity_list) > 0.95 and np.std(self.template_similarity_list) < 0.01):
                return False
            # 中间帧必须是白屏, 或者与首尾两帧差异极大
            if self.curr_rect_pure_ratio < 0.7 and max(self.curr_rect_pure_ratio - self.prev_rect_pure_ratio,
                                                       self.curr_rect_pure_ratio - self.next_rect_pure_ratio) < 0.25:
                return False
            if ((self.rect_ratio < 0.5 or self.curr_rect_pure_ratio < 0.85) and self.curr_rect_pure_ratio < 0.9) and \
                    ((self.curr_rect_pure_ratio - self.prev_rect_pure_ratio) < 0.4 and not abs(
                        self.curr_rect_pure_pixel - self.prev_rect_pure_pixel > 50) or
                     (self.curr_rect_pure_ratio - self.next_rect_pure_ratio) < 0.4 and not abs(
                                self.curr_rect_pure_pixel - self.next_rect_pure_pixel > 50)):
                return False
            # 如果一三帧相同，中间白屏，无条件返回单色闪确认场景
            if 0.95 < self.edge_rect_similarity <= 1:
                return True
            # 三帧都接近纯色的情况, 针对淡入单出动效
            if min(self.rect_pure_ratio_list) > 0.8:
                diff_list = np.diff(self.rect_pure_pixel_list)
                scope = diff_list[0] * diff_list[1] > 0
                if scope:
                    if min(np.abs(diff_list)) < 40:
                        return False
                else:
                    if min(np.abs(diff_list)) < 20:
                        return False
            if self.curr_image_info.sum_rect_area == 0 or \
                    (self.sum_change_ratio > 0.1 and
                     self.next_image_info.sum_rect_area / self.curr_image_info.sum_rect_area < 0.4 and
                     (self.curr_rect_pure_pixel > 200 or
                      (abs(self.curr_rect_pure_pixel - self.next_rect_pure_pixel) < 25))):
                self._log(f"大变化之后的小变化场景, 忽略")
                return False
            # 白屏 1 - 白屏 2 - 场景 2
            if abs(self.curr_rect_pure_ratio - self.prev_rect_pure_ratio) < 0.1:
                if self.is_fade_before():
                    self._log("渐变过程, 忽略黑白花闪")
                    return False
                # 如果中间帧是占位符, 非问题
                if self.prev_rect_pure_pixel < 50 and self.curr_rect_pure_pixel >= self.prev_rect_pure_pixel \
                        or (self.prev_rect_pure_pixel > 200 and
                            self.prev_rect_pure_pixel >= self.curr_rect_pure_pixel) or \
                        self.prev_rect_pure_pixel == 1:
                    self._log(f"白屏-占位符-内容场景, 非问题")
                    return False
                if self.rect_ratio < 0.1 and abs(
                        self.prev_rect_pure_pixel < 50 and self.curr_rect_pure_pixel >= self.prev_rect_pure_pixel) < 50 \
                        or (self.prev_rect_pure_pixel > 200 and
                            abs(self.prev_rect_pure_pixel >= self.curr_rect_pure_pixel) < 50) or \
                        self.prev_rect_pure_pixel == 1:
                    self._log(f"白屏-占位符-内容场景, 非问题")
                    return False
                if self.flash_params.action_type in ActionType.CLICK:
                    # 如果白屏 1 是一个全屏的白屏转场, 非问题
                    if self.prev_global_pure_ratio > 0.8:
                        self._log(f"起始点为白屏转场, 非问题")
                        return False
                    if np.abs(self.prev_rect_pure_ratio - self.curr_rect_pure_ratio) < 5 and (
                            self.prev_rect_pure_ratio + 0.01 > self.curr_rect_pure_ratio):
                        self._log(f"白屏内容场景, 非问题")
                        return False
                return True
            # 场景 1 - 白屏 1 - 白屏 2
            if abs(self.curr_rect_pure_ratio - self.next_rect_pure_ratio) < 0.1:
                # 白屏 1 - 白屏 2 的像素差异不大
                # 如果中间帧是占位符, 非问题
                if abs(self.next_rect_pure_pixel - self.curr_rect_pure_pixel) < 20:
                    self._log(f"白屏过渡场景, 非问题")
                    return False
                return True
            if min(abs(np.diff(self.rect_brightness_list))) < 15:
                self._log("色差相对较小，不上报")
                return False
            if self.curr_image_info.sum_rect_area == 0 or \
                    (self.next_image_info.sum_rect_area / self.curr_image_info.sum_rect_area < 0.5 and
                     abs(self.curr_rect_pure_pixel - self.next_rect_pure_pixel) < 10) or \
                    (self.next_image_info.sum_rect_area / self.curr_image_info.sum_rect_area < 0.2 and
                     abs(self.curr_rect_pure_pixel - self.next_rect_pure_pixel) < 25):
                self._log(f"大变化之后的小变化场景, 忽略")
                return False
            if self.prev_global_pure_ratio > 0.8 and abs(self.curr_rect_brightness - self.prev_rect_brightness) < 10:
                self._log(f"加载场景, 忽略")
                return False
            if abs(self.curr_image_info.rect_contrast_ratio - self.prev_rect_contrast_ratio) < 10 and self.is_fade_before():
                self._log(f"屏幕渐变场景, 忽略")
                return False
            if self.curr_template_similarity < 0 and self.rect_ratio < 0.3:
                self._log(f"忽略页面转场后白屏加载")
                return False
            # 小面积变化且内容相似度高
            if self.rect_ratio < 0.05 and self.next_template_similarity > 0.98:
                self._log(f"白屏全局占比 {self.rect_ratio}, 与下帧相似度 {self.template_similarity_list[-1]} 忽略")
                return False
            if self.is_fade_in() or self.is_fade_out():
                self._log("渐变过程, 忽略黑白花闪")
                return False
            if abs(self.curr_rect_pure_pixel - self.next_rect_pure_pixel) < 5 and \
                    ((self.next_rect_brightness - self.curr_rect_brightness) < 20 or
                     self.next_image_info.template_similarity > 0.97) and self.exist_in_next:
                self._log(f"下一帧存在匹配图片, 跳过")
                return False
            # 不相似, 场景 1 - 白屏 - 场景 2
            self._log(f"白屏全局占比 {self.rect_ratio}, 间隔时长 {self.flash_time}")
            # 大面积转场限制阈值 200ms
            if self.rect_ratio > 0.5:
                return self.flash_time < 200
            # 小面积转场白屏时长小于 300ms 认为对人因有体验影响
            return self.flash_time < 300

        def check_content_flash(self):
            """
            检查内容突然出现后消失的场景
            :return:
            """
            if self.prev_rect_pure_ratio > 0.9 and self.next_rect_pure_ratio > 0.9 and \
                    self.curr_rect_pure_ratio < 0.7:
                if self.exist_in_next:
                    return False
                return min(self.template_similarity_list) < 0.9
            return False

        @staticmethod
        def is_monotonic(num_list: list[float | int]) -> bool:
            return num_list == sorted(num_list) or num_list == sorted(num_list, reverse=True)

        def is_fade_before(self):
            try:
                brightness_list: List[PureStableImageInfo] = []
                curr_image_info: PureStableImageInfo = self.curr_image_info.prev_image_info
                while curr_image_info is not None and len(brightness_list) < 5:
                    brightness_list.append(self.read_image_info(curr_image_info.image_info, read_rect=False).mean())
                    curr_image_info = curr_image_info.prev_image_info
                brightness_diff_list = np.diff(np.asarray(brightness_list))
                if len(brightness_diff_list) < 4:
                    return False
                brightness_diff_list = brightness_diff_list[brightness_diff_list != 0]
                std_value = np.std(brightness_diff_list)
                if 1 < np.abs(np.max(brightness_diff_list)) < 2:
                    return std_value < 1
                return np.min(brightness_diff_list) * np.max(brightness_diff_list) > 0 and std_value < 20
            except Exception:
                return False

        def is_fade_in(self):
            """
            判断过程中是否存在渐变现象
            :return:
            """
            try:
                if min(self.template_similarity_list[1:]) > 0.98:
                    return True
                time_list: List[int] = []
                brightness_list: List[PureStableImageInfo] = []
                curr_image_info: PureStableImageInfo = self.curr_image_info.curr_image_info.prev_image_info
                while curr_image_info is not None and (curr_image_info.image_time > self.prev_image_info.image_time
                                                       or len(brightness_list) < 5):
                    time_list.append(curr_image_info.image_time)
                    brightness_list.append(self.read_image_info(curr_image_info.image_info).mean())
                    curr_image_info = curr_image_info.prev_image_info
                brightness_diff_list = np.diff(np.asarray(brightness_list))
                if len(brightness_diff_list) < 4:
                    return False
                brightness_diff_list = brightness_diff_list[brightness_diff_list != 0]
                std_value = np.std(brightness_diff_list)
                return max(np.abs(brightness_diff_list)) > 2 and std_value < 20 and \
                    np.min(brightness_diff_list) * np.max(brightness_diff_list) > 0
            except Exception:
                return False

        def is_fade_out(self):
            """
            判断过程中是否存在渐变现象
            :return:
            """
            try:
                if min(self.template_similarity_list[1:]) > 0.98:
                    return True
                time_list: List[int] = []
                brightness_list: List[PureStableImageInfo] = []
                curr_image_info: PureStableImageInfo = self.curr_image_info.curr_image_info
                while curr_image_info is not None and len(brightness_list) < 5:
                    time_list.append(curr_image_info.image_time)
                    brightness_list.append(self.read_image_info(curr_image_info.image_info).mean())
                    curr_image_info = curr_image_info.next_image_info
                brightness_diff_list = np.diff(np.asarray(brightness_list))
                if len(brightness_diff_list) < 4:
                    return False
                brightness_diff_list = brightness_diff_list[brightness_diff_list != 0]
                std_value = np.std(brightness_diff_list)
                if np.max(np.abs(brightness_diff_list[0] - np.mean(brightness_diff_list[1:]))) > 10:
                    return False
                return max(np.abs(brightness_diff_list)) > 2 and std_value < 20 and \
                    np.min(brightness_diff_list) * np.max(brightness_diff_list) > 0
            except Exception:
                return False

        def read_image_info(self, image_info: CheckImageInfo, mode: int = cv2.IMREAD_GRAYSCALE, read_rect: bool = True):
            image = ImageHelper.read_image(image_info.image_file_path, mode)
            if read_rect:
                image = self.curr_rect.cut_frame(image)
            return image

        def _log(self, msg, level=logging.DEBUG):
            logging.log(level, f"{self.prev_image_info.image_time} - {self.next_image_info.image_time} {msg}")

        @property
        def check_image_info_list(self):
            return [self.prev_image_info, self.curr_image_info, self.next_image_info]

        @property
        def prev_template_similarity(self) -> float:
            return self.prev_image_info.prev_image_info.template_similarity

        @property
        def prev_rect_template_similarity(self) -> float:
            return self.prev_image_info.rect_template_similarity

        @property
        def prev_rect_pure_pixel(self) -> float:
            return self.prev_image_info.rect_pure_pixel

        @property
        def prev_rect_pure_ratio(self) -> float:
            return self.prev_image_info.rect_pure_ratio

        @property
        def prev_rect_brightness(self) -> float:
            return self.prev_image_info.rect_brightness

        @property
        def prev_rect_contrast_ratio(self) -> float:
            return self.prev_image_info.rect_contrast_ratio

        @property
        def curr_template_similarity(self) -> float:
            return self.curr_image_info.prev_image_info.template_similarity

        @property
        def curr_rect_template_similarity(self) -> float:
            return self.curr_image_info.rect_template_similarity

        @property
        def curr_rect_pure_pixel(self) -> float:
            return self.curr_image_info.rect_pure_pixel

        @property
        def curr_rect_pure_ratio(self) -> float:
            return self.curr_image_info.rect_pure_ratio

        @property
        def curr_rect_brightness(self) -> float:
            return self.curr_image_info.rect_brightness

        @property
        def curr_rect_contrast_ratio(self) -> float:
            return self.curr_image_info.rect_contrast_ratio

        @property
        def next_template_similarity(self) -> float:
            return self.next_image_info.prev_image_info.template_similarity

        @property
        def next_rect_template_similarity(self) -> float:
            return self.next_image_info.rect_template_similarity

        @property
        def next_rect_pure_pixel(self) -> float:
            return self.next_image_info.rect_pure_pixel

        @property
        def next_rect_pure_ratio(self) -> float:
            return self.next_image_info.rect_pure_ratio

        @property
        def next_rect_brightness(self) -> float:
            return self.next_image_info.rect_brightness

        @property
        def next_rect_contrast_ratio(self) -> float:
            return self.next_image_info.rect_contrast_ratio

        @property
        def template_similarity_list(self) -> List[float]:
            return [self.prev_template_similarity, self.curr_template_similarity, self.next_template_similarity]

        @property
        def rect_template_similarity_list(self) -> List[float]:
            return [self.prev_rect_template_similarity, self.curr_rect_template_similarity,
                    self.next_rect_template_similarity]

        @property
        def rect_pure_pixel_list(self) -> List[float]:
            return [self.prev_rect_pure_pixel, self.curr_rect_pure_pixel, self.next_rect_pure_pixel]

        @property
        def rect_pure_ratio_list(self) -> List[float]:
            return [self.prev_rect_pure_ratio, self.curr_rect_pure_ratio, self.next_rect_pure_ratio]

        @property
        def rect_brightness_list(self) -> List[float]:
            return [self.prev_rect_brightness, self.curr_rect_brightness, self.next_rect_brightness]

        @property
        def rect_contrast_ratio_list(self) -> List[float]:
            return [self.prev_rect_contrast_ratio, self.curr_rect_contrast_ratio, self.next_rect_contrast_ratio]

        @property
        def all_rect_pure_ratio_list(self) -> List[float]:
            return [self.prev_rect_pure_ratio, self.curr_rect_pure_ratio, self.next_rect_pure_ratio]

    def check_flash_image(self, prev_image_info: CheckImageInfo, curr_image_info: CheckImageInfo,
                          next_image_info: CheckImageInfo, curr_rect: Rect) -> bool:
        flash_check = PureStableAnalyzer.StableFlashCheck(prev_image_info, curr_image_info, next_image_info, curr_rect,
                                                          self.flash_params)
        return flash_check.check()

    def build_check_image_list(self, image_info: PureStableImageInfo, curr_rect: Rect) -> List[CheckImageInfo]:
        # 提取当前时间窗口的图像列表
        records = self.error_rect_info.find_prev_records(image_info, curr_rect)
        check_image_list: List[CheckImageInfo] = [CheckImageInfo(image_info)]
        check_image_list += list(reversed([CheckImageInfo(record.image_info, record.first_image_info)
                                           for record in records]))
        last_checked_image_info = check_image_list[-1].prev_image_info
        if last_checked_image_info is None:
            return check_image_list
        end_image_info = last_checked_image_info.prev_image_info
        if end_image_info is None:
            return check_image_list
        start_image_info = end_image_info
        while start_image_info is not None and start_image_info.template_similarity > FlashParams.STABLE_RATIO \
                and start_image_info.image_time != self.error_rect_info.first_error_time:
            start_image_info = start_image_info.prev_image_info
        if start_image_info is not None:
            check_image_list.append(CheckImageInfo(end_image_info, start_image_info))
        return check_image_list


class ErrorRectInfo:
    class Record:
        def __init__(self, image_info: PureStableImageInfo, rect_list: List[Rect] = None,
                     first_image_info: PureStableImageInfo = None):
            self.first_image_info = first_image_info
            self.image_info = image_info
            self.rect_list = rect_list
            if self.first_image_info is None:
                self.first_image_info = image_info
            if self.rect_list is None:
                self.rect_list = []

    def __init__(self, ttl: int = 500):
        self._ttl = ttl
        self._records: List[ErrorRectInfo.Record] = []
        self.first_error_time = 0

    def add_error_rects(self, image_info: PureStableImageInfo, rects: List[Rect],
                        prev_image_info: PureStableImageInfo | None = None) -> None:
        # 添加异常记录
        self._records.append(ErrorRectInfo.Record(image_info, rects))

    def update_last_image_info(self, image_info: PureStableImageInfo) -> None:
        if len(self._records) == 0:
            return
        last_record = self._records.pop()
        self._records.append(ErrorRectInfo.Record(image_info, last_record.rect_list, last_record.first_image_info))

    def clean_history_record(self, expire_threshold: int) -> None:
        # 分割有效记录与过期记录
        valid_records: List[ErrorRectInfo.Record] = []
        expired_records: List[ErrorRectInfo.Record] = []

        for index, _record in enumerate(self._records):
            if index == len(self._records) - 1:
                if _record.first_image_info.image_time >= expire_threshold:
                    valid_records.append(_record)
                else:
                    expired_records.append(_record)
                continue
            if _record.image_info.image_time >= expire_threshold:
                valid_records.append(_record)
            else:
                expired_records.append(_record)
        # 批量移除过期记录（减少列表操作次数）
        if expired_records:
            self._records = valid_records

    def find_prev_records(self, image_info: PureStableImageInfo, curr_rect: Rect, iou_ratio: float = 0.5) \
            -> List[Record]:
        """
        获取当前时间有效的历史记录，并执行过期清理
        """
        # 计算过期时间阈值
        expire_threshold = image_info.image_time - self._ttl
        self.clean_history_record(expire_threshold)
        valid_record_list = []
        check_records = self._records[-10:]
        for index, record in enumerate(check_records):
            if record.first_image_info.image_time != 0 and not any(
                    [curr_rect.iou(rect) > iou_ratio for rect in record.rect_list]):
                continue
            if index > 0:
                prev_record = check_records[index - 1]
                if prev_record not in valid_record_list:
                    valid_record_list.append(prev_record)
            if record not in valid_record_list:
                valid_record_list.append(record)
        return valid_record_list
