from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
import shlex
from hypium import UiDriver


@dataclass
class AAStartOption:
    ability_name: Optional[str] = None
    bundle_name: Optional[str] = None
    module_name: Optional[str] = None
    uri: Optional[str] = None
    action: Optional[str] = None
    entity: Optional[str] = None
    mime_type: Optional[str] = None
    device_id: Optional[str] = None
    debug: bool = False
    window_mode: Optional[int] = None
    params: Dict[str, Any] = field(default_factory=dict)
    extra_args: List[str] = field(default_factory=list)


class AATools:
    def __init__(self, driver: UiDriver):
        self._driver = driver

    def _execute_shell(self, command: str) -> str:
        return self._driver.shell(command)

    def _escape_shell(self, value: str) -> str:
        return shlex.quote(str(value))

    def _build_param_args(self, params: Dict[str, Any]) -> List[str]:
        args = []
        for key, value in params.items():
            if isinstance(value, bool):
                args.append(f"--pb {key} {str(value).lower()}")
            elif isinstance(value, int):
                args.append(f"--pi {key} {value}")
            elif isinstance(value, str):
                escaped = self._escape_shell(value)
                args.append(f"--ps {key} {escaped}")
            else:
                escaped = self._escape_shell(str(value))
                args.append(f"--ps {key} {escaped}")
        return args

    def _build_start_command(self, option: AAStartOption) -> str:
        cmd_parts = ["aa start"]

        if option.device_id:
            cmd_parts.append(f"-d {option.device_id}")
        if option.ability_name:
            cmd_parts.append(f"-a {option.ability_name}")
        if option.bundle_name:
            cmd_parts.append(f"-b {option.bundle_name}")
        if option.module_name:
            cmd_parts.append(f"-m {option.module_name}")
        if option.debug:
            cmd_parts.append("-D")
        if option.window_mode is not None:
            cmd_parts.append(f"-s {option.window_mode}")
        if option.action:
            cmd_parts.append(f"-A {option.action}")
        if option.uri:
            cmd_parts.append(f"-U {option.uri}")
        if option.entity:
            cmd_parts.append(f"-e {option.entity}")
        if option.mime_type:
            cmd_parts.append(f"-t {option.mime_type}")

        cmd_parts.extend(self._build_param_args(option.params))

        if option.extra_args:
            cmd_parts.extend(option.extra_args)

        return " ".join(cmd_parts)

    def start(self, option: AAStartOption) -> str:
        command = self._build_start_command(option)
        return self._execute_shell(command)

    def start_ability(
        self,
        bundle_name: str,
        ability_name: str,
        module_name: Optional[str] = None,
        uri: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> str:
        option = AAStartOption(
            ability_name=ability_name,
            bundle_name=bundle_name,
            module_name=module_name,
            uri=uri,
            params=params or {},
            **kwargs,
        )
        return self.start(option)

    def implicit_start(
        self,
        uri: str,
        bundle_name: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> str:
        option = AAStartOption(
            uri=uri,
            bundle_name=bundle_name,
            params=params or {},
            **kwargs,
        )
        return self.start(option)

    def force_stop(self, bundle_name: str) -> str:
        command = f"aa force-stop {bundle_name}"
        return self._execute_shell(command)

    def stop_service(
        self,
        ability_name: str,
        bundle_name: str,
        module_name: Optional[str] = None,
        device_id: Optional[str] = None,
    ) -> str:
        cmd_parts = ["aa stop-service"]

        if device_id:
            cmd_parts.append(f"-d {device_id}")
        if ability_name:
            cmd_parts.append(f"-a {ability_name}")
        if bundle_name:
            cmd_parts.append(f"-b {bundle_name}")
        if module_name:
            cmd_parts.append(f"-m {module_name}")

        command = " ".join(cmd_parts)
        return self._execute_shell(command)
