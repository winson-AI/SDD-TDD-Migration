"""
Layout Parser Module

Provides parsing and filtering of UI layout hierarchies.
"""

import json
from typing import Any, Dict, List, Optional


class UIControlParser:
    """
    UI Control Parser for HarmonyOS UI layout dumps.

    Parses JSON layout dumps, filters out irrelevant nodes,
    and provides query methods for finding specific controls.
    """

    # Valid attributes to preserve in filtered output
    VALID_ATTRIBUTES = ['text', 'id', 'hint', 'description', 'clickable']

    def __init__(self, json_file_path: str):
        """
        Initialize the parser.

        Args:
            json_file_path: Path to the JSON layout dump file
        """
        self.json_file_path = json_file_path
        self._data: Optional[Dict[str, Any]] = None
        self._filtered_list: Optional[List[Dict[str, Any]]] = None

    def load(self) -> Dict[str, Any]:
        """
        Load the JSON layout file.

        Returns:
            Loaded JSON data
        """
        with open(self.json_file_path, 'r', encoding='utf-8') as f:
            self._data = json.load(f)
        return self._data

    def _should_keep_node(self, attributes: Dict[str, Any]) -> bool:
        """
        Determine if a node should be kept in the filtered output.

        A node is kept if it has:
        - Non-empty text, id, hint, or description
        - clickable attribute set to 'true'

        Args:
            attributes: Node attributes dictionary

        Returns:
            True if the node should be kept
        """
        # Check text, id, hint, description for non-empty values
        for attr in ['text', 'id', 'hint', 'description']:
            value = attributes.get(attr, '')
            if value:
                return True

        # Check if clickable is true
        clickable = attributes.get('clickable', '')
        if clickable == 'true':
            return True

        return False

    def _collect_valid_nodes(self, node: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Recursively collect valid nodes from the layout tree.

        Args:
            node: Current node being processed

        Returns:
            List of valid nodes found in this subtree
        """
        attributes = node.get('attributes', {})
        children = node.get('children', [])

        result = []

        # Process children first (depth-first traversal)
        for child in children:
            result.extend(self._collect_valid_nodes(child))

        # Check current node
        if self._should_keep_node(attributes):
            # Filter to only include valid attributes
            filtered_attrs: Dict[str, Any] = {}
            for attr in self.VALID_ATTRIBUTES:
                if attr in attributes:
                    filtered_attrs[attr] = attributes[attr]
            result.append(filtered_attrs)

        return result

    def filter(self) -> List[Dict[str, Any]]:
        """
        Filter the UI layout and return a flat list of controls.

        Returns:
            Flattened list of control information
        """
        if self._data is None:
            self.load()

        self._filtered_list = self._collect_valid_nodes(self._data)
        return self._filtered_list

    def save_filtered(self, output_path: str) -> None:
        """
        Save the filtered controls to a JSON file.

        Args:
            output_path: Path where the filtered data will be saved
        """
        if self._filtered_list is None:
            self.filter()

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self._filtered_list, f, ensure_ascii=False, indent=2)

    def get_controls(self) -> List[Dict[str, Any]]:
        """
        Get all filtered controls.

        Returns:
            List of control information dictionaries
        """
        if self._filtered_list is None:
            self.filter()
        return self._filtered_list

    def find_controls_by_text(self, text: str, exact: bool = True) -> List[Dict[str, Any]]:
        """
        Find controls by their text attribute.

        Args:
            text: Text to search for
            exact: Whether to require exact match (False for substring)

        Returns:
            List of matching controls
        """
        controls = self.get_controls()
        if exact:
            return [c for c in controls if c.get('text') == text]
        return [c for c in controls if text.lower() in c.get('text', '').lower()]

    def find_controls_by_id(self, id_value: str) -> List[Dict[str, Any]]:
        """
        Find controls by their id attribute.

        Args:
            id_value: ID value to search for

        Returns:
            List of matching controls
        """
        controls = self.get_controls()
        return [c for c in controls if c.get('id') == id_value]

    def get_clickable_controls(self) -> List[Dict[str, Any]]:
        """
        Get all controls that are clickable.

        Returns:
            List of clickable control information
        """
        controls = self.get_controls()
        return [c for c in controls if c.get('clickable') == 'true']

    @property
    def data(self) -> Optional[Dict[str, Any]]:
        """Get the loaded raw data."""
        return self._data

    @property
    def filtered_list(self) -> Optional[List[Dict[str, Any]]]:
        """Get the filtered control list."""
        return self._filtered_list