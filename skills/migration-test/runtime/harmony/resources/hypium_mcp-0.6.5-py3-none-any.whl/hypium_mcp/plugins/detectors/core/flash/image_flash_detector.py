import json
import os
import uuid
from pathlib import Path
from typing import Any

from hypium_mcp.plugins.detectors.core.detection_result import DetectionResult
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.image_flash_analyzer import ImageFlashAnalyzer
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)


class ImageFlashDetector:

    @classmethod
    def detect(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        """
        检测滑动卡顿问题

        Args:
            arg_dict: {
                image_folder: 采集到的录屏图片存放位置
            }

        Returns:
            DetectionResult: 检测结果，包含成功状态和相关信息
        """
        # 验证和解析上下文
        context_validation = cls._validate_context(arg_dict)

        if not context_validation.success:
            return context_validation

        context_dict = context_validation.data
        image_folder = Path(context_dict["image_folder"])
        flash_params = FlashParams()
        flash_params.action_type = context_dict.get("func_name", "click")
        analyzer = ImageFlashAnalyzer(flash_params)
        flash_info_list: list[KpiFlashInfo] = analyzer.start_analyze(image_folder)
        if len(flash_info_list) == 0:
            return DetectionResult.success("没有检测到黑白花闪问题", [])
        uid = context_dict.get("id", uuid.uuid4())
        message = f"{uid} 检测到黑白花闪问题区间: "
        flash_msg_list = []
        for flash_info in flash_info_list:
            logger.info(f"{flash_info.start_time}-{flash_info.end_time}出现黑白花闪")
            flash_msg_list.append(f"{flash_info.start_time}ms-{flash_info.end_time}ms")
        message += ",".join(flash_msg_list)
        return DetectionResult.success(message, [flash_info.to_dict() for flash_info in flash_info_list])

    @classmethod
    def _validate_context(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        """
        验证输入参数
        """
        try:
            context_path = arg_dict.get("json_path")
            if context_path is None or not os.path.exists(context_path):
                return DetectionResult(False, "缺少上下文文件")

            context_dict = json.loads(Path(context_path).read_text(encoding="utf-8"))

            required_fields = ["image_folder"]
            for field in required_fields:
                if field not in context_dict:
                    return DetectionResult(False, f"缺少必要参数: {field}")

            if not context_dict["image_folder"] or not os.path.exists(context_dict["image_folder"]):
                return DetectionResult(False, f"图片文件夹不存在: {context_dict['image_folder']}")
            return DetectionResult(True, "验证通过", context_dict)

        except Exception as e:
            return DetectionResult(False, f"上下文验证失败: {str(e)}")
