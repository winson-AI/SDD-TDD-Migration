import json
from abc import abstractmethod
from typing import Generic, List, TypeVar

from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import Rect
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import BaseFlashImageInfo, \
    ScreenFlashImageInfo


class StableImageInfo(BaseFlashImageInfo):

    def __init__(self, curr_image_info: ScreenFlashImageInfo, prev_image_info: ScreenFlashImageInfo | None = None):
        super().__init__(curr_image_info)
        self.prev_image_info: ScreenFlashImageInfo = prev_image_info if prev_image_info else curr_image_info
        self.curr_image_info: ScreenFlashImageInfo = curr_image_info

        self.rect_template_similarity: float = 0.0
        self.rect_pure_ratio: float = 0.0

        self.rect_list: List[Rect] = []

    @property
    def start_time(self):
        return self.prev_image_info.image_time

    def __repr__(self):
        return json.dumps({
            "image_time": self.image_time,
            "rect_template_similarity": self.rect_template_similarity,
            "rect_pure_ratio": self.rect_pure_ratio,
        })


BaseStableInfo = TypeVar('BaseStableInfo', StableImageInfo, None)


class BaseStableAnalyzer(Generic[BaseStableInfo]):

    def __init__(self, flash_params: FlashParams):
        self.flash_params = flash_params

    @abstractmethod
    def compare_image_info(self, prev_image_info: ScreenFlashImageInfo,
                           curr_image_info: ScreenFlashImageInfo) -> BaseStableInfo:
        pass

    @abstractmethod
    def analyze_image_info_list(self, image_info_list: List[BaseStableInfo]):
        pass
