"""
Data models for the CLI framework.
"""

import inspect
from typing import Any, Callable, Dict, List, Optional, Type

from hypium_mcp.core.cli_framework.types import ParamKind, TypeHint


class ParamInfo:
    """Parameter information with type conversion support."""

    def __init__(self, name: str, type_hint: TypeHint, param: inspect.Parameter):
        self.name = name
        self._type_hint = type_hint
        self.default = param.default
        self.param_kind = ParamKind.from_inspect(param)
        self._annotation = param.annotation

    @property
    def type_hint(self) -> TypeHint:
        """Get the effective type hint (excluding None for Optional types)."""
        if self._annotation == inspect.Parameter.empty:
            return None

        # Handle Optional[Type] and Union[Type, None]
        if hasattr(self._annotation, "__origin__"):
            origin = self._annotation.__origin__
            if origin is Union:
                args = self._annotation.__args__
                for arg_type in args:
                    if arg_type is not type(None):
                        return arg_type

        return self._annotation

    @property
    def is_optional(self) -> bool:
        """Whether this parameter is optional (has default or contains None)."""
        if self.default != inspect.Parameter.empty:
            return True

        # Check if Optional[Type] or Union[Type, None]
        if hasattr(self._annotation, "__origin__"):
            origin = self._annotation.__origin__
            if origin is Union:
                return type(None) in self._annotation.__args__

        return self.param_kind.is_var

    @property
    def is_var(self) -> bool:
        """Whether this is a variable parameter (*args or **kwargs)."""
        return self.param_kind.is_var

    @property
    def type_name(self) -> str:
        """Get a readable type name."""
        if self.type_hint is None:
            return "Any"

        # Handle Optional types
        if hasattr(self._annotation, "__origin__"):
            origin = self._annotation.__origin__
            if origin is Union:
                args = self._annotation.__args__
                names = [
                    getattr(a, "__name__", str(a))
                    for a in args
                    if a is not type(None)
                ]
                return " | ".join(names)

        # Handle generic types like List[Type]
        type_str = getattr(self.type_hint, "__name__", str(self.type_hint))
        if hasattr(self.type_hint, "__origin__") and hasattr(self.type_hint, "__args__"):
            origin_name = getattr(self.type_hint.__origin__, "__name__", "")
            args = self.type_hint.__args__
            if args:
                arg_names = [
                    getattr(a, "__name__", str(a))
                    for a in args
                    if a is not type(None)
                ]
                if arg_names:
                    type_str = f"{origin_name}[{', '.join(arg_names)}]"

        return type_str

    def convert(self, value: str) -> Any:
        """Convert string value to the parameter's type."""
        if self.type_hint is None or self.type_hint == str:
            return value
        if self.type_hint == int:
            return int(value)
        if self.type_hint == float:
            return float(value)
        if self.type_hint == bool:
            return value.lower() in ("true", "1", "yes", "y", "t")
        if self.type_hint == list:
            return [v.strip() for v in value.split(",")]
        return value


class CommandInfo:
    """Command information with parameter scanning."""

    def __init__(self, name: str, func: Callable, description: str = ""):
        self.name = name
        self.func = func
        self.description = description or func.__doc__ or ""
        self.params: Dict[str, ParamInfo] = self._scan_params()

    def _scan_params(self) -> Dict[str, ParamInfo]:
        """Scan function parameters and create ParamInfo objects."""
        params = {}
        sig = inspect.signature(self.func)
        for param_name, param in sig.parameters.items():
            params[param_name] = ParamInfo(param_name, param.annotation, param)
        return params

    @property
    def required_params(self) -> List[ParamInfo]:
        """Get all required (non-optional) parameters."""
        return [p for p in self.params.values() if not p.is_optional]

    @property
    def optional_params(self) -> List[ParamInfo]:
        """Get all optional parameters."""
        return [p for p in self.params.values() if p.is_optional]

    def get_param(self, name: str) -> Optional[ParamInfo]:
        """Get parameter info by name."""
        return self.params.get(name)

    def has_param(self, name: str) -> bool:
        """Check if parameter exists."""
        return name in self.params


# Import Union at module level
from typing import Union  # noqa: E402