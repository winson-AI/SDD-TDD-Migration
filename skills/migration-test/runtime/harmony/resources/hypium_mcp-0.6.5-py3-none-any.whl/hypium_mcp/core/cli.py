#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Hypium CLI Main Module

Provides command-line interface for Hypium device operations.
"""

import os
import sys

from hypium_mcp.core import tool_adapter
from hypium_mcp.core.cli_framework import CLIApp
from hypium_mcp.core.tool_loader import loader as tool_loader
from hypium_mcp import tools
from hypium_mcp.device.device_manager import DeviceManager


def create_app() -> CLIApp:
    """
    Create and configure the CLI application.

    Returns:
        Configured CLIApp instance
    """
    app = CLIApp(
        name="hypium-cli",
        description="Hypium Command-Line Interface for HarmonyOS Device Automation"
    )

    # Load tools dynamically from capabilities directory
    tools_path = os.path.join(os.path.dirname(tools.__file__))
    tools_module = tool_loader.DEFAULT_TOOLS_MODULE

    if os.path.exists(tools_path):
        tool_loader.register_tools(tools_path, tools_module, app.command(),
                                   tool_adapter.create_driver_injector(DeviceManager.get_instance().get_device))

    return app


def main() -> int:
    """
    Main entry point for the CLI.

    Returns:
        Exit code
    """
    app = create_app()
    return app.run(sys.argv[1:])


if __name__ == "__main__":
    sys.exit(main())
