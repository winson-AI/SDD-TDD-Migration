import os
from enum import Enum

import cv2

from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper


class SwipeDirection(Enum):
    Horizontal = "horizontal"
    Vertical = "vertical"

    @classmethod
    def get_direction(cls, arg_dict):
        swipe_direction = arg_dict.get("swipe_direction")
        if swipe_direction is None:
            return None
        return  SwipeDirection.Horizontal if swipe_direction == 'horizontal' else SwipeDirection.Vertical


class ClipBias:
    def __init__(self, image_height: int, image_width: int,
                 top: float = 0, bottom: float = 0, left: float = 0, right: float = 0, is_abs: bool = False):
        self.image_height = image_height
        self.image_width = image_width
        self.top = top
        self.bottom = bottom
        self.left = left
        self.right = right
        self.is_abs = is_abs

    @property
    def top_bias(self) -> int:
        return int(self.top * self.image_height)

    @property
    def bottom_bias(self) -> int:
        if self.is_abs:
            return self.image_height - int(self.bottom * self.image_height)
        return int(self.bottom * self.image_height)

    @property
    def left_bias(self) -> int:
        return int(self.left * self.image_width)

    @property
    def right_bias(self) -> int:
        if self.is_abs:
            return self.image_width - int(self.right * self.image_width)
        return int(self.right * self.image_width)

    @classmethod
    def get_clip_bias(cls, height: int, width: int, package_name: str, swipe_direction: SwipeDirection):
        if swipe_direction == SwipeDirection.Horizontal:
            return HorizontalClipBias.get_clip_bias(height, width, package_name)
        return VerticalClipBias.get_clip_bias(height, width, package_name)

DEFAULT_HEIGHT = 2720


# 剪裁偏移常量
DEFAULT_TOP_CLIP = 400 / DEFAULT_HEIGHT
DEFAULT_BOTTOM_CLIP = 300 / DEFAULT_HEIGHT
DEFAULT_LEFT_CLIP = 50 / DEFAULT_HEIGHT
DEFAULT_RIGHT_CLIP = 50 / DEFAULT_HEIGHT


class BaseClipBias:
    @classmethod
    def get_top_rate(cls, package_name: str):
        return DEFAULT_TOP_CLIP

    @classmethod
    def get_bottom_rate(cls, package_name: str):
        return DEFAULT_BOTTOM_CLIP

    @classmethod
    def get_left_rate(cls, package_name: str):
        return DEFAULT_LEFT_CLIP

    @classmethod
    def get_right_rate(cls, package_name: str):
        return DEFAULT_RIGHT_CLIP

    @classmethod
    def get_clip_bias(cls, height: int, width: int, package_name: str):
        return ClipBias(height, width, cls.get_top_rate(package_name), cls.get_bottom_rate(package_name),
                        cls.get_left_rate(package_name), cls.get_right_rate(package_name))


class HorizontalClipBias(BaseClipBias):
    @classmethod
    def get_bottom_rate(cls, package_name: str):
        return 400 / DEFAULT_HEIGHT


class VerticalClipBias(BaseClipBias):

    @classmethod
    def get_top_rate(cls, package_name: str):
        if package_name in ["com.ss.hm.article.video", "com.ss.hm.ugc.aweme", "com.kuaishou.hmapp",
                            "com.taobao.taobao4hmos", "com.ss.hm.article.news", "com.xingin.xhs_hos"]:
            return 100 / DEFAULT_HEIGHT
        return super().get_top_rate(package_name)

    @classmethod
    def get_bottom_rate(cls, package_name: str):
        if package_name in ["com.huawei.hmos.photos", "com.ss.hm.ugc.aweme", "com.huawei.hmos.meetime"]:
            return 200 / DEFAULT_HEIGHT
        return super().get_bottom_rate(package_name)

    @classmethod
    def get_left_rate(cls, package_name: str):
        return 0

    @classmethod
    def get_right_rate(cls, package_name: str):
        return 0



class AnimatorPos:
    """动画位置信息类，用于存储图像位移计算结果"""
    def __init__(self, x: float, y: float, valid: bool):
        self.x = x
        self.y = y
        self.valid = valid

    @staticmethod
    def create(x: float, y: float, valid: bool):
        return AnimatorPos(x, y, valid)

    def correct_value(self, swipe_direction: SwipeDirection):
        """获取正确的轴数值"""
        if swipe_direction == SwipeDirection.Horizontal:
            return self.x
        return self.y

    def error_value(self, swipe_direction: SwipeDirection):
        """获取错误轴数值（垂直于滑动方向的轴）"""
        if swipe_direction == SwipeDirection.Horizontal:
            return self.y
        return self.x


class SwipeAnimatorImageInfo:

    def __init__(self, image_file_path):
        self.image_file_path = image_file_path
        self.image_time = int(os.path.basename(image_file_path).split(".")[0])
        self.shift = 0.0
        self.pos = 0.0
        self.image_width = 0
        self.image_height = 0

    @property
    def value(self):
        return self.pos

    def read_image(self, mode: int = cv2.IMREAD_GRAYSCALE):
        return ImageHelper.read_image(self.image_file_path, mode)

    def image_size(self) -> tuple[int, int]:
        image_height, image_width = self.read_image().shape[:2]
        return image_height, image_width
