import os
from concurrent.futures.thread import ThreadPoolExecutor
from pathlib import Path
from typing import List

import cv2
import numpy as np

from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import FlashHelper
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo, \
    VideoSceneType
from hypium_mcp.plugins.detectors.core.flash.helper.video_scene_parser import VideoSceneParser
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional_scene_analyzer_factory import \
    MotionalSceneAnalyzerFactory
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.stable_scene_analyzer_factory import StableSceneAnalyzer
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)


class ImageFlashAnalyzer:
    """
    黑白花闪图像分析器主类

    对接图片检测流水线，负责协调整个分析流程。

    Attributes:
        flash_params (FlashParams): 黑白花闪检测参数配置
        video_scene_parser (VideoSceneParser): 视频场景解析器
        motional_scene_analyzer (MotionalSceneAnalyzerFactory): 动态场景分析器工厂
    """

    def __init__(self, flash_params: FlashParams):
        """
        初始化图像分析器

        Args:
            flash_params: 闪烁检测参数配置对象
        """
        self.flash_params = flash_params
        self.video_scene_parser = VideoSceneParser(flash_params)
        self.motional_scene_analyzer = MotionalSceneAnalyzerFactory(flash_params)
        self.stable_scene_analyzer = StableSceneAnalyzer(flash_params)

    def start_analyze(self, image_folder_path: str | Path) -> list[KpiFlashInfo]:
        """
        开始分析黑白花闪问题的主入口方法

        执行完整的分析流程，包括：
        1. 加载并排序图片文件
        2. 构建图片信息链表结构
        3. 并行计算相邻图片相似度
        4. 解析视频场景类型
        5. 根据场景类型调用对应的黑白花闪分析器
        6. 合并相邻的黑白花闪时间段

        Args:
            image_folder_path: 图片文件夹路径

        Returns:
            list[KpiFlashInfo]: 黑白花闪信息列表，包含每个时间段的信息
        """
        # 1. 加载并排序图片文件
        image_file_paths = ImageHelper.sort_image_files(image_folder_path)
        image_file_infos = list(map(lambda image_file_path: ScreenFlashImageInfo(image_file_path), image_file_paths))
        logger.info(f"黑花闪图片集对比分析, 共 {len(image_file_infos)} 张图片")
        with ThreadPoolExecutor(max_workers=os.cpu_count() // 2) as executor:
            prev_image_info = None
            for curr_image_info in image_file_infos:
                if prev_image_info is None:
                    prev_image_info = curr_image_info
                    continue
                executor.submit(self.compare_image, prev_image_info, curr_image_info)
                # 构建双向链表关系
                prev_image_info.next_image_info = curr_image_info
                curr_image_info.prev_image_info = prev_image_info
                prev_image_info = curr_image_info

        # 3. 解析视频场景类型并分割时间段
        video_scene_info_list = self.video_scene_parser.parser(image_file_infos)
        flash_info_list = []

        # 4. 根据场景类型调用对应的闪烁分析器
        for video_scene_info in video_scene_info_list:
            try:
                # 根据场景时间段提取待分析的图片子集
                analyze_image_info_list = image_file_infos[video_scene_info.start_index:video_scene_info.end_index]

                # 根据场景类型选择合适的分析器
                if video_scene_info.video_scene_type == VideoSceneType.STABLE:
                    flash_info_list.extend(self.stable_scene_analyzer.analyzer_images(analyze_image_info_list))
                elif video_scene_info.video_scene_type == VideoSceneType.ANIMATOR:
                    flash_info_list.extend(self.motional_scene_analyzer.analyzer_images(analyze_image_info_list))

                # 清理链表关系，避免内存泄漏
                for analyze_image_info in analyze_image_info_list:
                    analyze_image_info.prev_image_info = None
                    analyze_image_info.next_image_info = None

            except Exception as e:
                logger.error(f"场景分析失败: {e}", exc_info=e)

        # 5. 合并相邻或重叠的黑白花闪时间段
        flash_info_list = self.merge_flash_info_list(flash_info_list)

        # 6. 更新时间戳并构建最终结果
        final_flash_info_list: list[KpiFlashInfo] = []
        for flash_info in flash_info_list:
            flash_info.update_timestamp(self.flash_params.video_start_timestamp)
            final_flash_info_list.append(flash_info)

        # 清理全局链表关系
        for image_file_info in image_file_infos:
            image_file_info.prev_image_info = None
            image_file_info.next_image_info = None

        return final_flash_info_list

    @staticmethod
    def compare_image(prev_image_info: ScreenFlashImageInfo, next_image_info: ScreenFlashImageInfo):
        """
        比较相邻两张图片的相似度特征

        计算模板匹配相似度和对比度，用于后续的场景判断

        Args:
            prev_image_info: 前一张图片信息
            next_image_info: 后一张图片信息
        """
        # 读取灰度图像
        prev_image, next_image = FlashHelper.read_gray_image(prev_image_info), \
            FlashHelper.read_gray_image(next_image_info)

        # 计算模板匹配相似度（使用归一化相关系数）
        match_result = cv2.matchTemplate(prev_image, next_image, cv2.TM_CCOEFF_NORMED)
        next_image_info.template_similarity = round(np.max(match_result), 3)

        # 计算图片平均对比度（转换为百分比）
        next_image_info.contrast_ratio = next_image.mean() * 100 / 255

    def merge_flash_info_list(self, flash_info_list: List[KpiFlashInfo]):
        """
        合并相邻或重叠的黑白花闪时间段

        执行时间段的边界合并逻辑：
        1. 按开始时间排序
        2. 合并相邻或重叠的时间段

        Args:
            flash_info_list: 原始黑白花闪信息列表

        Returns:
            List[KpiFlashInfo]: 合并后的黑白花闪信息列表
        """
        # 1. 按开始时间排序
        flash_info_list.sort(key=lambda x: x.start_time)

        # 2. 用于存储合并后的时间段
        merged_flash_info_list: List[KpiFlashInfo] = []

        # 3. 遍历每个时间段，执行合并和过滤
        for flash_info in flash_info_list:
            # 合并逻辑：
            # - 结果列表为空时直接添加
            # - 当前时间段与最后一个时间段无重叠时直接添加
            # - 有重叠时扩展最后一个时间段的结束时间
            if not merged_flash_info_list or merged_flash_info_list[-1].end_time < flash_info.start_time:
                merged_flash_info_list.append(flash_info)
            else:
                # 合并重叠的时间段
                merged_flash_info_list[-1].update_end_time(flash_info)

        return merged_flash_info_list
