import bisect

import cv2


def get_encoder_surface_call_id_set(sql_instance):
    coder_list = sql_instance \
        .query_all(f"select * from callstack where name like '%HEncoderSurface%'")
    id_set = set()
    for coder in coder_list:
        id_set.add(coder.callid)
    return id_set


def get_codec_multi_time_list_by_key(touch_start_time, sql_instance, is_seek, key):
    render_list = sql_instance \
        .query_all(f"select * from callstack where name like '%{key}%'")
    encoder_surface_call_id_set = set()
    if key == 'OnReleaseOutputBuffer':
        encoder_surface_call_id_set = get_encoder_surface_call_id_set(sql_instance)
    # 通过call_id进行分类
    has_render = len(render_list) > 0
    call_id_dict = {}
    for item in render_list:
        call_id = item.callid
        if call_id not in call_id_dict:
            call_id_dict[call_id] = []
        if item.dur is not None:
            call_id_dict[call_id].append(item.ts // 1000000)
    # dict转换成数组
    multi_time_list = []
    for call_id in call_id_dict:
        if call_id in encoder_surface_call_id_set:
            continue

        time_list = call_id_dict[call_id]
        # 非seek场景的话，在点击之前的就不要了
        if len(time_list) < 2:
            continue
        if time_list[0] - touch_start_time > -20 or is_seek:
            multi_time_list.append(time_list)
    return multi_time_list, has_render


def get_codec_surface_match_dis(codec_time_list, surface_time_list, surface_name):
    # 个数不能差太多，前后不能差太多
    # 前面的从第二个开始，避免起始时偏差较大
    if abs(codec_time_list[1] - surface_time_list[1]) > 500 or abs(codec_time_list[-1] - surface_time_list[-1]) > 300:
        return -1

    len_dis = abs(len(codec_time_list) - len(surface_time_list))
    len_dis_ratio = min(len(codec_time_list) / len(surface_time_list), len(surface_time_list) / len(codec_time_list))
    # 数字化的Surface更可信
    if surface_name.replace('Surface', '').isdigit():
        if len_dis_ratio < 0.7:
            return -1
    else:
        if len_dis_ratio < 0.9 and len_dis > 15:
            return -1

    total_diff = 0
    for a in codec_time_list:
        # 找到插入位置
        pos = bisect.bisect_left(surface_time_list, a)

        # 取左边或右边最近的点
        candidates = []
        if pos > 0:
            candidates.append(abs(a - surface_time_list[pos - 1]))
        if pos < len(surface_time_list):
            candidates.append(abs(a - surface_time_list[pos]))

        total_diff += min(candidates)

    # 计算差值的平均值
    return total_diff / len(codec_time_list)


class VideoCommonMethod:
    @staticmethod
    def get_app_package_name(sql_instance):
        command_list = sql_instance.query_all("select callstack.callid,thread.name from callstack join thread "
                                              "on callstack.callid = thread.id where callstack.name = 'H:SendCommands'")
        thread_name_dict = {}
        for item in command_list:
            thread_name = item.name
            count = 0
            try:
                count = thread_name_dict[thread_name]
            except Exception:
                pass
            thread_name_dict[thread_name] = count + 1
        sorted_keys = sorted(thread_name_dict, key=thread_name_dict.get, reverse=True)
        filter_names = ['ohos.sceneboard', 'render_service']
        for key in sorted_keys:
            if key not in filter_names:
                return key
        return ''

    @staticmethod
    def get_touch_start_time(sql_instance):
        sql_str = "select * from callstack " \
                  "where name in ('H:PointerEventDispatch', 'H:touchEventDispatch', 'deliverInputEvent')"
        res_list = sql_instance.query_all(sql_str)
        if len(res_list) == 0:
            return 0
        return res_list[0].ts

    @staticmethod
    def get_codec_multi_time_list(touch_start_time, sql_instance, is_seek):
        render_multi_time_list, has_render = get_codec_multi_time_list_by_key(touch_start_time, sql_instance, is_seek,
                                                                              'OnRenderOutputBuffer')
        if not has_render:
            # 没有OnRenderOutputBuffer, 转向OnReleaseOutputBuffer
            render_multi_time_list, _ = get_codec_multi_time_list_by_key(touch_start_time, sql_instance, is_seek,
                                                                         'OnReleaseOutputBuffer')
        return render_multi_time_list

    @staticmethod
    def get_surface_multi_time_list(sql_instance, name_key='%Surface', sql_start_time=None, sql_end_time=None):
        filter_surface_name_list = \
            ['ChronosSurface', 'Live_ChronosSurface', 'nwebPreloadSurface', 'oh_flutter_',
             'Surface', 'HEncoderSurface', 'nodeId_-1Surface']
        sql_str = f"select * from callstack where name like 'H:ReleaseBuffer name: {name_key} queueId: %'"
        if sql_start_time is not None:
            sql_str += f' and ts > {sql_start_time}'
        if sql_end_time is not None:
            sql_str += f' and ts < {sql_end_time}'
        flush_buffer_list = sql_instance.query_all(sql_str)
        surface_dict = {}
        for item in flush_buffer_list:
            name = item.name
            form_name = name[22: name.index(' seq:')]
            should_filter = False
            for filter_name in filter_surface_name_list:
                if form_name.startswith(filter_name) and not form_name.startswith('SurfaceImage'):
                    should_filter = True
                    break
            if should_filter:
                continue

            if form_name not in surface_dict:
                surface_dict[form_name] = []
            if item.dur is not None:
                surface_dict[form_name].append(item.ts // 1000000)
        release_buffer_list = []
        surface_name_list = []
        for key in surface_dict:
            time_list = surface_dict[key]
            if len(time_list) > 2:
                release_buffer_list.append(time_list)
                surface_name_list.append(key[: key.index(' queueId:')])
        return release_buffer_list, surface_name_list

    @staticmethod
    def match_codec_surface_time_list(codec_time_list, sql_instance):
        sql_start_time = codec_time_list[0] * 1000000
        # 末尾添加一点
        sql_end_time = (codec_time_list[-1] + 150) * 1000000
        surface_multi_time_list, surface_name_list = VideoCommonMethod.get_surface_multi_time_list(sql_instance,
                                                                                                   sql_start_time=sql_start_time,
                                                                                                   sql_end_time=sql_end_time)
        has_match = False
        result_time_list = codec_time_list
        if len(surface_multi_time_list) > 0:
            min_dis = -1
            min_time_list = None
            for surface_time_list, surface_name in zip(surface_multi_time_list, surface_name_list):
                if len(surface_time_list) < 2:
                    continue
                dis = get_codec_surface_match_dis(codec_time_list, surface_time_list, surface_name)
                if dis < 0:
                    continue
                if min_dis == -1 or dis < min_dis:
                    min_time_list = surface_time_list
                    min_dis = dis
            if min_time_list is not None:
                has_match = True
                result_time_list = min_time_list
        return has_match, result_time_list

    @staticmethod
    def get_donghu_surface_multi_time_list(sql_instance):
        name_key = 'anco#SurfaceView%'
        multi_time_list, _ = VideoCommonMethod.get_surface_multi_time_list(sql_instance, name_key)
        return multi_time_list

    @staticmethod
    def get_weixin_surface_multi_time_list(sql_instance):
        name_key = 'SurfaceImage-%'
        multi_time_list, _ = VideoCommonMethod.get_surface_multi_time_list(sql_instance, name_key)
        return multi_time_list

    @staticmethod
    def get_pixel_diff(compare_image, finish_image, threshold=10, blur=3):
        height, width = finish_image.shape[:2]
        form_height = int(height * 0.65)
        start_height = int(height * 0.1)
        diff = cv2.absdiff(compare_image[start_height:start_height + form_height, :],
                           finish_image[start_height:start_height + form_height, :])
        _, thresh = cv2.threshold(diff, threshold, 255, cv2.THRESH_BINARY)
        thresh = cv2.medianBlur(thresh, blur)
        non_zero_pixels = cv2.countNonZero(thresh)
        pixel_diff = non_zero_pixels / (form_height * width)
        return pixel_diff

    @staticmethod
    def get_audio_multi_time_list(sql_instance):
        all_measure_filter_list = sql_instance.query_all(
            "select * from process_measure_filter where name like '%RendererInServer'")
        filter_ids = []
        for measure_filter in all_measure_filter_list:
            name = measure_filter.name
            if name.startswith('H:'):
                filter_ids.append(measure_filter.id)
        multi_time_list = []
        for ip_id in filter_ids:
            sql_result_list = sql_instance.query_all(f"select * from process_measure where filter_id = {ip_id}")
            time_list = []
            for item in sql_result_list:
                if item.dur is not None and item.value > 0:
                    time_list.append(item.ts // 1000000)
            multi_time_list.append(time_list)
        return multi_time_list
