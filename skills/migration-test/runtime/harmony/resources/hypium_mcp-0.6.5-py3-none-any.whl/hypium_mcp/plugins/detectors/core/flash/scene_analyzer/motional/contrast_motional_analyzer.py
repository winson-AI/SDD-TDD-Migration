import math
from typing import List

import numpy as np

from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import FlashHelper
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional.base_motional_analyzer import BaseMotionalAnalyzer, \
    MotionalImageInfo
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper


class ContrastMotionalImageInfo(MotionalImageInfo):

    def __init__(self, image_info: ScreenFlashImageInfo):
        super().__init__(image_info)

    @property
    def contrast_ratio(self) -> float:
        return self.image_info.contrast_ratio

    @property
    def value(self) -> float:
        return self.image_info.contrast_ratio

    def __repr__(self):
        return super().__repr__()


class ContrastMotionalAnalyzer(BaseMotionalAnalyzer):

    def analyze_image_info_list(self, image_info_list: List[ContrastMotionalImageInfo]) -> List[KpiFlashInfo]:
        """
        :param image_info_list:
        :return:
        """
        kpi_flash_info_list = []
        prev_index = 0
        while prev_index < len(image_info_list) - 2:
            curr_index = prev_index + 1
            while curr_index < len(image_info_list) - 2:
                if image_info_list[curr_index].template_similarity < 0.98:
                    break
                curr_index += 1
            next_index = curr_index + 1
            while next_index < len(image_info_list) - 1:
                if image_info_list[next_index].template_similarity < 0.98:
                    break
                next_index += 1
            prev_image_info, curr_image_info, next_image_info = \
                image_info_list[prev_index], image_info_list[curr_index], image_info_list[next_index]
            if self.check_image_flash(prev_image_info, curr_image_info, next_image_info):
                kpi_flash_info_list.append(KpiFlashInfo.build(prev_image_info.image_info, next_image_info.image_info,
                                                              self.flash_params.video_start_timestamp))
            prev_index = curr_index
        return kpi_flash_info_list

    def compare_image_info(self, prev_image_info: ScreenFlashImageInfo,
                           curr_image_info: ScreenFlashImageInfo) -> ContrastMotionalImageInfo:
        return ContrastMotionalImageInfo(curr_image_info)

    def check_image_flash(self, prev_image_info: ContrastMotionalImageInfo, curr_image_info: ContrastMotionalImageInfo,
                          next_image_info: ContrastMotionalImageInfo):
        if next_image_info.image_time - prev_image_info.image_time > 200:
            return False
        prev_contrast_ratio, curr_contrast_ratio, next_contrast_ratio = \
            prev_image_info.contrast_ratio, curr_image_info.contrast_ratio, next_image_info.contrast_ratio
        contrast_ratio_diff_list = np.abs(np.diff([prev_contrast_ratio, curr_contrast_ratio, next_contrast_ratio]))
        if np.min(contrast_ratio_diff_list) > 40:
            return True
        if math.isclose(prev_contrast_ratio, next_contrast_ratio, abs_tol=0.005) and np.min(
                contrast_ratio_diff_list) > 10:
            match_ratio = FlashHelper.match_template_ccoeff(
                ImageHelper.read_gray_image(prev_image_info.image_file_path),
                ImageHelper.read_gray_image(next_image_info.image_file_path))
            return match_ratio > 0.98
        return False
