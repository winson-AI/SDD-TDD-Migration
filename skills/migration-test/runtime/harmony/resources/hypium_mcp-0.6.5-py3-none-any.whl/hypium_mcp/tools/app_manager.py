"""
应用管理器

提供应用管理功能，包括安装、启动、停止和查询应用信息。
"""
from typing import Optional

from hypium import UiDriver


def install_app(device: UiDriver, file_path: str) -> None:
    """
    在设备上安装应用程序

    Args:
        file_path: 应用程序包文件的路径
    """
    device.install_app(file_path)


def uninstall_app(device: UiDriver, bundle_name: str) -> None:
    """
    从设备上卸载应用程序

    Args:
        bundle_name: 应用程序的包名
    """
    device.uninstall_app(bundle_name)


def has_app(device: UiDriver, bundle_name: str) -> bool:
    """
    检查设备上是否已安装应用程序

    Args:
        bundle_name: 应用程序的包名

    Returns:
        如果应用已安装返回 True，否则返回 False
    """
    return device.has_app(bundle_name)


def get_current_app(device: UiDriver) -> Optional[str]:
    """
    获取当前运行的应用程序的包名

    Returns:
        当前应用的包名，如果不可用则返回 None
    """
    return device.current_app()[0]


def stop_all_app(device: UiDriver):
    """
    停止所有应用程序
    """
    from .basic import clear_recent_task
    return clear_recent_task(device, 1)


def clear_app_data(device: UiDriver, bundle_name: str):
    """
    清除应用程序的数据

    Args:
        bundle_name: 应用程序的包名
    """
    return device.clear_app_data(bundle_name)
