import os
from concurrent.futures import Future, ThreadPoolExecutor
from typing import List, Type

from hypium_mcp.plugins.detectors.core.action_type import ActionType
from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import EnumerateWithPrev
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional.base_motional_analyzer import BaseMotionalAnalyzer
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional.contrast_motional_analyzer import \
    ContrastMotionalAnalyzer
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional.swipe_motional_analyzer import \
    SwipeMotionalAnalyzer
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

WINDOW_SIZE = 3
logger = get_logger(LoggerName.Detector)


class MotionalImageInfo:
    """动态图片信息包装类"""

    def __init__(self, image_info: ScreenFlashImageInfo):
        self.image_info = image_info
        self.avg_magnitude = 0
        self.avg_move_ratio = 0
        self.avg_angle = 0
        self.angle_std = 0
        self.diff_ratio = 0
        self.correlation = 0
        self.angle_available = True

    @property
    def image_time(self):
        return self.image_info.image_time


class MotionalSceneAnalyzerFactory:
    """
    动态场景分析
    """

    def __init__(self, flash_params: FlashParams):
        self.executor = ThreadPoolExecutor(max_workers=os.cpu_count() // 2)
        self.flash_params = flash_params

        self.sub_analyzer_list: List[BaseMotionalAnalyzer] = []
        sub_analyzer_class_list: List[Type[BaseMotionalAnalyzer]] = [ContrastMotionalAnalyzer]

        # 根据动作类型添加特定的分析器
        if self.flash_params.action_type == ActionType.SWIPE:
            sub_analyzer_class_list.append(SwipeMotionalAnalyzer)

        # 创建分析器实例
        for sub_analyzer_class in sub_analyzer_class_list:
            self.sub_analyzer_list.append(sub_analyzer_class(flash_params))

    def analyzer_images(self, image_info_list: List[ScreenFlashImageInfo]) -> List[KpiFlashInfo]:
        """
        主要依据对比变化区域的相似性来判断
        :param image_info_list:
        :return:
        """
        logger.debug(f"动态黑花闪分析区间 {image_info_list[0].image_time}-{image_info_list[-1].image_time}, "
                     f"图片数 {len(image_info_list)}")
        flash_info_list: List[KpiFlashInfo] = []
        for analyzer in self.sub_analyzer_list:
            future_list: List[Future] = []
            for index, prev_image_info, curr_image_info in EnumerateWithPrev(image_info_list):
                future_list.append(self.executor.submit(analyzer.compare_image_info, prev_image_info, curr_image_info))
            sub_analyzer_image_info_list = []
            for future in future_list:
                sub_analyzer_image_info_list.append(future.result())
            flash_info_list.extend(analyzer.analyze_image_info_list(sub_analyzer_image_info_list))
        return flash_info_list
