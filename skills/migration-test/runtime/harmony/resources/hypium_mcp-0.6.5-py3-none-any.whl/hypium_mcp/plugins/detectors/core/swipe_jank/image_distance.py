import numpy as np
from numpy.fft import fft2, fftshift, ifft2

from hypium_mcp.plugins.detectors.core.swipe_jank.swipe_jank_config import AnimatorPos, ClipBias, \
    SwipeAnimatorImageInfo, SwipeDirection

# 正常位移大于 10px
AVAILABLE_POS = 10
# 非同向位移不能大于 1
UNAVAILABLE_POS = 1
# 严格位移时限制不能大于 5
STRICT_POS = 5


class ImageDistance:

    @classmethod
    def _format_image(cls, image: np.ndarray) -> np.ndarray:
        height, width = image.shape[:2]
        return image[height % 2:, width % 2:]

    @classmethod
    def _compensate_color(cls, image: np.ndarray):
        # 反色阈值 40
        image[image < 40] = 255 - image[image < 40]
        return image

    @classmethod
    def _compute_image_distance(cls, image1: np.ndarray, image2: np.ndarray,
                                swipe_direction: SwipeDirection, strict: bool):
        image1, image2 = cls._compensate_color(image1), cls._compensate_color(image2)
        image1, image2 = cls._format_image(image1), cls._format_image(image2)
        f_image1, f_image2 = fft2(image1, norm='backward'), fft2(image2, norm='backward')
        correlation = f_image1 * np.conj(f_image2)
        correlation = ifft2(correlation)
        correlation = fftshift(correlation)
        correlation = np.abs(correlation) / np.max(np.abs(correlation))
        # 纯色图
        if np.allclose(correlation, 1):
            return AnimatorPos.create(0, 0, True)
        mean_arr = np.mean(correlation, axis=0 if swipe_direction == SwipeDirection.Horizontal else 1)
        mean_arr[np.isnan(mean_arr)] = 0
        offset_arr = np.unravel_index(np.argmax(correlation), correlation.shape)
        y, x = np.subtract(offset_arr, np.divide(correlation.shape, 2))
        if strict:
            if swipe_direction == SwipeDirection.Horizontal and abs(np.argmax(mean_arr) - offset_arr[1]) > 1:
                return AnimatorPos(x, y, False)
            elif swipe_direction == SwipeDirection.Vertical and abs(np.argmax(mean_arr) - offset_arr[0]) > 1:
                return AnimatorPos(x, y, False)
        # 不出现较大位移, 不进行二次检查
        if abs(x) < 100 and abs(y) < 100:
            return AnimatorPos.create(x, y, True)
        # 全部匹配到 99% 以上认为数据不可信
        if all(mean_arr > 0.99) or 0 in offset_arr:
            return AnimatorPos.create(x, y, False)
        # 所有点相关性一致也认为数据不可信
        if np.max(mean_arr) - np.min(mean_arr) < 0.002:
            return AnimatorPos.create(x, y, False)
        return AnimatorPos.create(x, y, True)

    @classmethod
    def compute_distance_twice(cls, image_info1: SwipeAnimatorImageInfo, image_info2: SwipeAnimatorImageInfo,
                               clip_bias: ClipBias, swipe_direction: SwipeDirection,
                               strict: bool = True) -> AnimatorPos:
        """
        通用的两次距离计算，适用于 X 和 Y 轴
        """
        clip_height = image_info1.image_height // 3
        clip_width = image_info1.image_width // 2
        image1, image2 = image_info1.read_image(), image_info2.read_image()
        # 第一次距离计算
        if swipe_direction == SwipeDirection.Vertical:  # Y 轴方向
            cropped_image1 = image1[clip_height: image_info1.image_height - clip_bias.bottom_bias,
            clip_bias.left_bias:image_info1.image_width - clip_bias.right_bias]
            cropped_image2 = image2[clip_height: image_info1.image_height - clip_bias.bottom_bias,
            clip_bias.left_bias:image_info1.image_width - clip_bias.right_bias]
        else:  # X 轴方向
            cropped_image1 = image1[
                clip_bias.top_bias:image_info1.image_height - clip_bias.bottom_bias, clip_bias.left_bias: clip_width]
            cropped_image2 = image2[
                clip_bias.top_bias:image_info1.image_height - clip_bias.bottom_bias, clip_bias.left_bias: clip_width]

        animator_pos = cls._compute_image_distance(cropped_image1, cropped_image2, swipe_direction, strict)
        # 信任首次运算, 1. 合法 2. 位移距离正常
        if animator_pos.valid:
            if abs(animator_pos.correct_value(swipe_direction)) >= AVAILABLE_POS and \
                    UNAVAILABLE_POS > abs(animator_pos.error_value(swipe_direction)):
                return animator_pos
        # 二次运算
        if swipe_direction == SwipeDirection.Horizontal:  # X 轴方向
            cropped_image1 = image1[clip_bias.top_bias: image_info1.image_height - clip_bias.bottom_bias,
            clip_width: image_info1.image_width - clip_bias.right_bias]
            cropped_image2 = image2[clip_bias.top_bias: image_info1.image_height - clip_bias.bottom_bias,
            clip_width: image_info1.image_width - clip_bias.right_bias]
        else:  # Y 轴方向
            cropped_image1 = image1[
                clip_bias.top_bias: clip_height, clip_bias.left_bias:image_info1.image_width - clip_bias.right_bias]
            cropped_image2 = image2[
                clip_bias.top_bias: clip_height, clip_bias.left_bias:image_info1.image_width - clip_bias.right_bias]
        second_animator_pos = cls._compute_image_distance(cropped_image1, cropped_image2, swipe_direction, strict)
        if animator_pos.valid and not second_animator_pos.valid:
            return animator_pos
        if abs(animator_pos.error_value(swipe_direction)) >= STRICT_POS and \
                abs(second_animator_pos.error_value(swipe_direction)) >= STRICT_POS:
            if strict:
                return AnimatorPos(0, 0, True)
            animator_pos.valid = False
            return animator_pos
        if abs(second_animator_pos.correct_value(swipe_direction)) < UNAVAILABLE_POS <= abs(
                animator_pos.correct_value(swipe_direction)):
            animator_pos.valid = True
            return animator_pos
        if abs(animator_pos.correct_value(swipe_direction)) < UNAVAILABLE_POS <= abs(
                second_animator_pos.correct_value(swipe_direction)):
            second_animator_pos.valid = True
            return second_animator_pos
        if abs(animator_pos.correct_value(swipe_direction) - second_animator_pos.correct_value(
                swipe_direction)) < AVAILABLE_POS:
            animator_pos.valid = True
            return animator_pos
        return second_animator_pos
