import os
from pathlib import Path

import cv2
import numpy as np

JPG_PARAMS = [cv2.IMWRITE_JPEG_QUALITY, 80]


class ImageHelper:
    JPG_EXT = ".jpg"
    PNG_EXT = ".png"
    MP4_EXT = ".mp4"

    @staticmethod
    def read_image(image_path: str | Path, mode: int = cv2.IMREAD_COLOR) -> np.ndarray:
        return cv2.imdecode(np.fromfile(image_path, dtype=np.uint8), mode)

    @staticmethod
    def read_gray_image(image_path: str | Path) -> np.ndarray:
        return ImageHelper.read_image(image_path, cv2.IMREAD_GRAYSCALE)

    @staticmethod
    def write_image(img: np.ndarray, save_path: str | Path, image_ext=None, is_rotate=False) -> None:
        save_path = Path(save_path)
        dir_path = os.path.split(save_path)[0]
        if not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        if image_ext is None:
            image_ext = save_path.suffix
        if is_rotate:
            img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        if image_ext == ImageHelper.JPG_EXT:
            cv2.imencode(image_ext, img, JPG_PARAMS)[1].tofile(save_path)
        else:
            cv2.imencode(image_ext, img)[1].tofile(save_path)

    @staticmethod
    def sort_image_files(image_folder_path) -> list[Path]:
        image_folder_path = Path(image_folder_path)
        file_list = []
        for file_path in image_folder_path.iterdir():
            file_path: Path
            if not file_path.stem.isdigit():
                continue
            if file_path.suffix not in [ImageHelper.JPG_EXT, ImageHelper.PNG_EXT]:
                continue
            if file_path.is_file():
                file_list.append(file_path)
        file_list.sort(key=ImageHelper.str2int)
        return file_list

    @staticmethod
    def str2int(intput_path: Path) -> int:
        num_list = []
        for char in intput_path.stem:
            if char.isdigit():
                num_list.append(char)
            elif num_list:
                break
        return int(''.join(num_list)) if num_list else 0