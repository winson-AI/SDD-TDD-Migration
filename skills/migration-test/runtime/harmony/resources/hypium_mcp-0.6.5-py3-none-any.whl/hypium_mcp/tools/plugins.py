"""
拓展操作

"""
import os

from hypium import UiDriver

from hypium_mcp.plugins.collectors.collector_manager import CollectorManager
from hypium_mcp.plugins.detectors.detector_manager import DetectorManager
from hypium_mcp.utils.log import get_logger

logger = get_logger("MCPPlugins")

def start_data_collect(device: UiDriver):
    """
    开始数据采集
    """
    if os.getenv("HYPIUM_MCP_COLLECT_ENABLE") != "True":
        return
    
    # Kill perfmonitor processes before starting data collection
    logger.info("Checking for perfmonitor processes...")
    
    # Execute ps -ef command to find uitest processes
    result = device.shell("ps -ef | grep uitest")
    logger.debug("ps -ef | grep uitest output: %s", result)
    
    # Parse the output to find processes with perfmonitor
    processes = result.strip().split('\n')
    killed_count = 0
    
    for process in processes:
        if 'perfmonitor' in process:
            # Extract PID from the process line
            # Format: user pid ppid ... command
            parts = process.split()
            if len(parts) >= 2:
                try:
                    pid = parts[1]
                    logger.info("Killing perfmonitor process with PID: %s", pid)
                    # Kill the process
                    kill_result = device.shell(f"kill -9 {pid}")
                    logger.debug("kill -9 %s result: %s", pid, kill_result)
                    killed_count += 1
                except Exception as e:
                    logger.error("Error killing process: %s", e)
    
    if killed_count > 0:
        logger.info("Killed %d perfmonitor processes", killed_count)
    else:
        logger.info("No perfmonitor processes found")
    
    CollectorManager.case_start()


def stop_data_collect(device: UiDriver):
    """
    结束数据采集
    """
    if os.getenv("HYPIUM_MCP_COLLECT_ENABLE") != "True":
        return
    CollectorManager.case_stop()


def generate_report(device: UiDriver,
                    stability_enable: bool = True,
                    swipe_jank_enable: bool = True,
                    video_jank_enable: bool = True,
                    image_flash_enable: bool = True):
    """
    生成测试报告

    Args:
        stability_enable: 是否启用稳定性检测，默认True
        swipe_jank_enable: 是否启用滑动卡顿检测，默认True
        video_jank_enable: 是否启用视频卡顿检测，默认True
        image_flash_enable: 是否启用黑白花闪检测，默认True
    """
    DetectorManager.generate_report(stability_enable, swipe_jank_enable, video_jank_enable, image_flash_enable)
