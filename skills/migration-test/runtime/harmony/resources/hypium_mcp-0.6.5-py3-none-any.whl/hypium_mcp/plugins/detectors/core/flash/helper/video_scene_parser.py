import math
from collections import deque
from typing import List

import cv2
import numpy as np
import scipy
from sklearn.linear_model import TheilSenRegressor

from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import ScreenFlashImageInfo, VideoSceneInfo, \
    VideoSceneType
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)

WINDOW_SIZE = 10


class VideoSceneParser:

    def __init__(self, flash_params: FlashParams):
        self.flash_params = flash_params
        self.linear_model: TheilSenRegressor = TheilSenRegressor()

    def check_animator_window(self, similarity_window_info_deque: deque[ScreenFlashImageInfo], cur_index: int) -> int:
        """
        连续多帧低相似度, 或者相似度出现不断下降的趋势
        :param similarity_window_info_deque: 相似度窗口
        :param cur_index: 当前索引
        :return: 开始运动的索引
        """
        if len(similarity_window_info_deque) < 8:
            return -1
        time_window_array = np.asarray([similarity_window_info.image_time / 1000
                                        for similarity_window_info in similarity_window_info_deque])
        time_diff_array = np.diff([similarity_window_info.image_time
                                   for similarity_window_info in similarity_window_info_deque])
        if np.min(time_diff_array) > 17:
            return -1
        similarity_window_array = np.asarray([similarity_window_info.template_similarity
                                              for similarity_window_info in similarity_window_info_deque])
        similarity_diff_array = np.diff(similarity_window_array)
        index = np.argmin(similarity_diff_array)
        if similarity_diff_array[index] < -0.5:
            if index == len(similarity_window_array) - 1:
                return -1
            (x, y), correlate_ratio = cv2.phaseCorrelate(
                ImageHelper.read_gray_image(similarity_window_info_deque[index].image_file_path)[120:].astype(
                    np.float32),
                ImageHelper.read_gray_image(similarity_window_info_deque[index + 1].image_file_path)[120:].astype(
                    np.float32))
            angle = math.degrees(math.atan2(y, x)) % 90
            if correlate_ratio < 0.6 and min(abs(angle), abs(90 - angle)) > 2:
                return -1
        # 动态阈值计算（基于历史数据）使用前5帧作为基准
        baseline = np.median(similarity_window_array[:5])
        dynamic_threshold = min(max(0.7, baseline.mean() - 0.02), 0.95)  # 保证不低于0.7, 不高于0.95
        # 异常值处理（中值滤波）
        filtered_window = scipy.signal.medfilt(similarity_window_array, kernel_size=3)
        slope = self.linear_model.fit(time_window_array.reshape(-1, 1), filtered_window).coef_[0]
        # 70%以上帧低于阈值
        condition1 = np.mean(filtered_window < dynamic_threshold) >= 0.7 or np.mean(filtered_window < 0.8) >= 0.9
        condition2 = slope < -0.5  # 显著下降趋势
        # 30%以下的稳定帧或
        condition3 = (np.mean(filtered_window > 0.95) <= 0.3 and np.std(filtered_window) > 0.001)
        condition4 = similarity_window_array[0] == 1 and similarity_window_array[1] < 0.9 and slope > 0.5
        condition5 = np.mean(np.diff(time_window_array)) < 0.017 and slope > 1
        if (condition1 or condition2 or condition4 or condition5) and condition3:
            # 逆向搜索起始点
            for i in range(len(similarity_window_array)):
                if similarity_window_array[i] < 0.99:
                    return cur_index + i  # 返回绝对索引
            # 次优选择：窗口内最低点
            return cur_index + np.argmin(filtered_window)
        return -1

    def check_stable_window(self, similarity_window_info_deque: deque[ScreenFlashImageInfo], cur_index: int) -> int:
        """
        单帧静止不算进入稳定阶段, 要求连续 5 帧恢复静止, 再回头确认稳定开始点
        :param similarity_window_info_deque:
        :param cur_index:
        :return:
        """
        time_window_array = np.asarray([similarity_window_info.image_time
                                        for similarity_window_info in similarity_window_info_deque])
        similarity_window_array = np.asarray([similarity_window_info.template_similarity
                                              for similarity_window_info in similarity_window_info_deque])
        index = self.check_long_stable(time_window_array, similarity_window_array)
        if index != -1:
            return cur_index
        # 动态阈值计算（基于历史数据）使用前5帧作为基准
        baseline = np.median(similarity_window_array[:5])
        dynamic_threshold = min(max(0.9, baseline + 0.005), 0.95)  # 保证不低于0.9
        # 异常值处理（中值滤波）
        filtered_window = scipy.signal.medfilt(similarity_window_array, kernel_size=3)
        condition1 = np.mean(filtered_window > dynamic_threshold) >= 0.8  # 80%以上帧高于阈值
        slope = abs(self.linear_model.fit(time_window_array.reshape(-1, 1), filtered_window).coef_[0])
        condition2 = slope < 0.01  # 稳定趋势
        condition3 = np.mean(filtered_window > dynamic_threshold) >= 0.8 and np.std(filtered_window) < 0.02
        if condition1 and (condition2 or condition3):
            # 搜索起始点
            for i in range(len(filtered_window)):
                if filtered_window[i] > 0.98:
                    return cur_index + i  # 返回绝对索引
            # 次优选择：窗口内最高点
            return cur_index + np.argmax(filtered_window)
        return -1

    @staticmethod
    def check_long_stable(time_window_array: np.ndarray, similarity_window_array: np.ndarray):
        indices = np.where(similarity_window_array > FlashParams.STABLE_RATIO)[0]
        if len(indices) == 0:
            return -1
        end_index = -1
        for index, similarity in enumerate(similarity_window_array[1:], start=1):
            end_index = index
            if similarity < FlashParams.STABLE_RATIO:
                break
        if end_index < 0:
            return -1
        if np.min(np.diff(time_window_array)) > 30:
            return 0
        if time_window_array[end_index] - time_window_array[0] > FlashParams.MAX_STABLE_TIME:
            return end_index
        return -1

    def parser(self, image_info_list: List[ScreenFlashImageInfo]) -> List[VideoSceneInfo]:
        return self.__inner_parse(image_info_list)

    def __parse_lock_special_scene(self, image_info_list: List[ScreenFlashImageInfo]) -> List[VideoSceneInfo]:
        change_index = -1
        for index, image_info in enumerate(image_info_list):
            if image_info.template_similarity < 0.2:
                change_index = index
                break
        if change_index == -1:
            return self.__inner_parse(image_info_list)
        return self.__inner_parse(image_info_list[:change_index]) + \
            self.__inner_parse(image_info_list[change_index:], change_index)

    def __inner_parse(self, image_info_list: List[ScreenFlashImageInfo], image_index: int = 0) -> List[VideoSceneInfo]:
        logger.debug(f"解析时间段 {image_info_list[0].image_time}-{image_info_list[-1].image_time}")
        image_data_size = len(image_info_list)
        cur_video_scene_type = VideoSceneType.STABLE
        similarity_window_info_deque: deque[ScreenFlashImageInfo] = deque(maxlen=10)
        similarity_window_info_deque.extend(image_info_list[:WINDOW_SIZE])
        prev_index, start_index = 0, 0
        video_scene_info_list: List[VideoSceneInfo] = []
        while start_index < image_data_size:
            if len(similarity_window_info_deque) <= 1:
                break
            check_index = -1
            if cur_video_scene_type == VideoSceneType.STABLE:
                check_index = self.check_animator_window(similarity_window_info_deque, start_index)
                if check_index != -1:
                    video_scene_info_list.append(VideoSceneInfo(prev_index, check_index, cur_video_scene_type))
                    cur_video_scene_type = VideoSceneType.ANIMATOR
            elif cur_video_scene_type == VideoSceneType.ANIMATOR:
                check_index = self.check_stable_window(similarity_window_info_deque, start_index)
                if check_index != -1:
                    video_scene_info_list.append(VideoSceneInfo(prev_index, check_index, cur_video_scene_type))
                    cur_video_scene_type = VideoSceneType.STABLE
            if check_index != -1:
                prev_index = check_index
                start_index = prev_index
                similarity_window_info_deque.clear()
                similarity_window_info_deque.extend(image_info_list[start_index:start_index + WINDOW_SIZE])
            start_index += 1
            if start_index + WINDOW_SIZE < image_data_size:
                similarity_window_info_deque.append(image_info_list[start_index + WINDOW_SIZE])
            else:
                similarity_window_info_deque.popleft()
        video_scene_info_list.append(VideoSceneInfo(prev_index, image_data_size, cur_video_scene_type))
        final_video_scene_list: List[VideoSceneInfo] = []
        index = 0
        while index < len(video_scene_info_list):
            video_scene_info = video_scene_info_list[index]
            if len(final_video_scene_list) > 0:
                if video_scene_info.video_scene_type == VideoSceneType.ANIMATOR:
                    if video_scene_info.end_index - video_scene_info.start_index < 5:
                        merge_end_index = min(len(video_scene_info_list), index + 1)
                        final_video_scene_list[-1].update_end_index(video_scene_info_list[merge_end_index].end_index)
                        index += 2
                        continue
                if video_scene_info.video_scene_type == VideoSceneType.STABLE:
                    if video_scene_info.end_index - video_scene_info.start_index < 2:
                        merge_end_index = min(len(video_scene_info_list), index + 1)
                        final_video_scene_list[-1].update_end_index(video_scene_info_list[merge_end_index].end_index)
                        index += 2
                        continue
            final_video_scene_list.append(video_scene_info)
            index += 1
        for video_scene in final_video_scene_list:
            video_scene.start_index += image_index
            video_scene.end_index += image_index
        return final_video_scene_list
