import json
from pathlib import Path

from hypium_mcp.plugins.detectors.convertor.trace_convertor import TraceConverter
from hypium_mcp.plugins.detectors.convertor.video_convertor import VideoConvertor
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)



class ResourceConverter:

    @classmethod
    def convert_data(cls, data_dir):
        for action_path in Path(data_dir).iterdir():
            cls.convert_action_data(action_path)

    @classmethod
    def convert_action_data(cls, action_path: str | Path):
        action_path = Path(action_path)
        context_path = action_path.joinpath("context.json")
        if not context_path.exists():
            return
        json_dict = json.loads(context_path.read_text(encoding="utf-8"))
        for action_data_path in action_path.iterdir():
            if action_data_path.suffix == ".sys":
                logger.info(f"预处理文件: {action_data_path}")
                json_dict["db_path"] = str(TraceConverter.convert_trace(action_data_path))
                json_dict["start_time"] = 0
            if action_data_path.suffix == ".mp4":
                logger.info(f"预处理文件: {action_data_path}")
                json_dict["image_folder"] = str(VideoConvertor.convert_video(action_data_path))
        context_path.write_text(json.dumps(json_dict), encoding="utf-8")

