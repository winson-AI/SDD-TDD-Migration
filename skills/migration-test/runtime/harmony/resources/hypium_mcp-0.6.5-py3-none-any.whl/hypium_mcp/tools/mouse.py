"""
鼠标操作工具

提供鼠标相关的操作能力，包括点击、双击、长按、移动、拖拽、滚动等。
"""

from typing import Literal, Optional, Tuple
from hypium import UiDriver
from hypium.model.basic_data_type import MouseButton
from hypium_mcp.plugins import mcp_collector_enabled
from hypium_mcp.utils import coordinate


BUTTON_MAP = {
    "left": MouseButton.MOUSE_BUTTON_LEFT,
    "right": MouseButton.MOUSE_BUTTON_RIGHT,
    "middle": MouseButton.MOUSE_BUTTON_MIDDLE,
}


@mcp_collector_enabled
def mouse_click(
    device: UiDriver,
    pos: Tuple[int, int],
    button: Literal["left", "right", "middle"] = "left",
) -> None:
    """
    在指定坐标执行鼠标点击操作

    Args:
        pos: 点击坐标
        button: 鼠标按键，可选值：left（左键）、right（右键）、middle（中键）
    """
    pos = coordinate.normalize_coordinate(pos)
    button_id = BUTTON_MAP.get(button, MouseButton.MOUSE_BUTTON_LEFT)
    device.mouse_click(pos, button_id=button_id)


@mcp_collector_enabled
def mouse_double_click(
    device: UiDriver,
    pos: Tuple[int, int],
    button: Literal["left", "right", "middle"] = "left",
) -> None:
    """
    在指定坐标执行鼠标双击操作

    Args:
        pos: 点击坐标
        button: 鼠标按键，可选值：left（左键）、right（右键）、middle（中键）
    """
    pos = coordinate.normalize_coordinate(pos)
    button_id = BUTTON_MAP.get(button, MouseButton.MOUSE_BUTTON_LEFT)
    device.mouse_double_click(pos, button_id=button_id)


@mcp_collector_enabled
def mouse_long_click(
    device: UiDriver,
    pos: Tuple[int, int],
    button: Literal["left", "right", "middle"] = "left",
    press_time: float = 1.5,
) -> None:
    """
    在指定坐标执行鼠标长按操作

    Args:
        pos: 点击坐标
        button: 鼠标按键，可选值：left（左键）、right（右键）、middle（中键）
        press_time: 长按持续时间（秒）
    """
    pos = coordinate.normalize_coordinate(pos)
    button_id = BUTTON_MAP.get(button, MouseButton.MOUSE_BUTTON_LEFT)
    device.mouse_long_click(pos, button_id=button_id, press_time=press_time)


@mcp_collector_enabled
def mouse_move_to(
    device: UiDriver,
    pos: Tuple[int, int],
) -> None:
    """
    鼠标指针移动到指定位置

    Args:
        pos: 目标坐标
    """
    pos = coordinate.normalize_coordinate(pos)
    device.mouse_move_to(pos)


@mcp_collector_enabled
def mouse_move(
    device: UiDriver,
    start: Tuple[int, int],
    end: Tuple[int, int],
    speed: int = 3000,
) -> None:
    """
    鼠标指针从起始位置移动到结束位置，模拟移动轨迹和速度

    Args:
        start: 起始坐标
        end: 结束坐标
        speed: 移动速度，值越大速度越快
    """
    start = coordinate.normalize_coordinate(start)
    end = coordinate.normalize_coordinate(end)
    device.mouse_move(start, end, speed=speed)


@mcp_collector_enabled
def mouse_drag(
    device: UiDriver,
    start: Tuple[int, int],
    end: Tuple[int, int],
    speed: int = 3000,
) -> None:
    """
    使用鼠标进行拖拽操作（按住鼠标左键移动鼠标）

    Args:
        start: 起始坐标
        end: 结束坐标
        speed: 拖拽速度，值越大速度越快
    """
    start = coordinate.normalize_coordinate(start)
    end = coordinate.normalize_coordinate(end)
    device.mouse_drag(start, end, speed=speed)


@mcp_collector_enabled
def mouse_scroll(
    device: UiDriver,
    pos: Tuple[int, int],
    scroll_direction: Literal["up", "down", "left", "right"] = "down",
    scroll_steps: int = 1,
) -> None:
    """
    在指定位置执行鼠标滚动操作

    Args:
        pos: 滚动位置的坐标
        scroll_direction: 滚动方向，可选值：up（上）、down（下）、left（左）、right（右）
        scroll_steps: 滚动步数
    """
    pos = coordinate.normalize_coordinate(pos)
    device.mouse_scroll(pos, scroll_direction=scroll_direction, scroll_steps=scroll_steps)
