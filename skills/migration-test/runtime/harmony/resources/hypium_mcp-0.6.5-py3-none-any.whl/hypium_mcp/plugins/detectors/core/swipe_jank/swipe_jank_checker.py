from hypium_mcp.plugins.detectors.core.swipe_jank.swipe_jank_config import SwipeAnimatorImageInfo
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)

# 产生滑动的最短距离
SWIPE_DISTANCE_THRESHOLD = 50
# 正常过滤比例
FILTER_RATIO = 0.02
# 回弹过滤比例
REBOUND_FILTER_RATIO = 0.1


class SwipeJankChecker:

    @classmethod
    def check(cls, image_infos: list[SwipeAnimatorImageInfo]) -> \
            list[tuple[SwipeAnimatorImageInfo, SwipeAnimatorImageInfo]]:
        jank_info_list: list[tuple[SwipeAnimatorImageInfo, SwipeAnimatorImageInfo]] = []
        pos_list = [image_info.pos for image_info in image_infos]
        max_pos, min_pos = max(pos_list), min(pos_list)
        if max_pos - min_pos < SWIPE_DISTANCE_THRESHOLD:
            logger.info("滑动距离过短 / 未产生滑动，不进行动效卡顿检测")
            return jank_info_list
        prev_image_info = None
        for curr_image_info in image_infos:
            if prev_image_info is None:
                prev_image_info = curr_image_info
                continue
            if curr_image_info.image_time - prev_image_info.image_time > 16.6 * 1.5:
                jank_info_list.append((prev_image_info, curr_image_info))
            prev_image_info = curr_image_info
        return jank_info_list
