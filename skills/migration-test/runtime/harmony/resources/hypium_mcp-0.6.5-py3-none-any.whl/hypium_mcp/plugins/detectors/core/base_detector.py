import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from hypium_mcp.plugins.detectors.core.detection_result import DetectionResult


class BaseDetector(ABC):

    @classmethod
    @abstractmethod
    def detect(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        pass

    @classmethod
    def _validate_context(cls, arg_dict: dict[str, Any], required_fields: list[str]) -> DetectionResult:
        """
        验证输入参数
        """
        try:
            context_path = arg_dict.get("json_path")
            if context_path is None or not os.path.exists(context_path):
                return DetectionResult(False, "缺少上下文文件")

            context_dict = json.loads(Path(context_path).read_text(encoding="utf-8"))

            for field in required_fields:
                if field not in context_dict:
                    return DetectionResult(False, f"缺少必要参数: {field}")

            return DetectionResult(True, "验证通过", context_dict)

        except Exception as e:
            return DetectionResult(False, f"上下文验证失败: {str(e)}")
