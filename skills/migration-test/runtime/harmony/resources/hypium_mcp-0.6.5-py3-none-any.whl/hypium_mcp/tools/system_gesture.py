import time
from typing import Tuple
from hypium import UiDriver, BY
from hypium_mcp.utils import coordinate


def _wait_with_max_delay(delay: float) -> None:
    actual_delay = min(delay, 2.0)
    time.sleep(actual_delay)


def open_control_center(device: UiDriver, delay: float = 1.0, full_screen: bool = False):
    """
    打开系统控制中心

    Args:
        delay: 操作后等待时间，最大不超过 2 秒
        full_screen: 当前界面是否全屏(未显示状态栏)，如最近任务界面为全屏，需要设置为True。
    """
    times = 1
    if full_screen:
        times = 2
    for _ in range(times):
        device.slide((0.8, 0), (0.8, 0.4), slide_time=0.5)
    _wait_with_max_delay(delay)


def open_notification_center(device: UiDriver, delay: float = 1.0, full_screen: bool = False):
    """
    打开系统通知中心

    Args:
        delay: 操作后等待时间，最大不超过 2 秒
        full_screen: 当前界面是否全屏(未显示状态栏)，如最近任务界面为全屏，需要设置为True。
    """
    times = 1
    if full_screen:
        times = 2
    for _ in range(times):
        device.slide((0.3, 0), (0.3, 0.4), slide_time=0.5)
    _wait_with_max_delay(delay)


def drag_to_xiaoyi(device: UiDriver, pos: Tuple[int, int], delay: float = 1.0):
    """
    将元素拖拽给小艺

    Args:
        pos: 需要拖拽的元素坐标
        delay: 操作后等待时间，最大不超过 2 秒
    """
    device.drag(coordinate.normalize_coordinate(pos), (0.5, 0.99), drag_time=0.5)
    _wait_with_max_delay(delay)


def enter_recent_task(driver: UiDriver, delay: int = 1):
    """
    进入系统最近任务页面 
    使用场景:
    当步骤要求查看和操作最近应用列表时调用该接口，
    无需关注当前设备页面，直接调用即可。

    Args:
        delay: 等待时间，默认 1 秒
    """
    if driver.find_component(BY.key("RecentClearAllView_Image_deleteFull")):
        driver.wait(delay)
        return
    elif driver.find_component(BY.text("最近无运行应用")):
        bundle_name, _ = driver.current_app()
        if not bundle_name:
            driver.wait(delay)
            return
    driver.press_combination_key(2076, 2049)
    driver.wait(delay)
