from typing import List

import cv2
import numpy as np

from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import Rect


class FlashParams:
    MIN_FLASH_AREA = 200 * 100
    MIN_FLASH_WIDTH = 100
    MIN_FLASH_HEIGHT = 100
    GLOBAL_CHANGE_AREA = 1000 * 1000

    STABLE_RATIO = 0.98
    MAX_STABLE_TIME = 500

    def __init__(self):
        self.action_type = "click"

    @property
    def blurred_image_time_list(self):
        return []

    @property
    def response_time(self):
        return -1

    @property
    def complete_time(self):
        return -1

    @property
    def animator_time(self):
        return -1

    @property
    def video_start_timestamp(self):
        return 0

    @staticmethod
    def filter_contour(contour: List[np.ndarray]) -> bool:
        x, y, w, h = cv2.boundingRect(contour)
        return w < FlashParams.MIN_FLASH_WIDTH or h < FlashParams.MIN_FLASH_HEIGHT \
            or w * h < FlashParams.MIN_FLASH_AREA

    @staticmethod
    def filter_rect(rect: Rect, image_height=-1, image_width=-1) -> bool:
        if image_height == -1:
            image_height = 2000
        if image_width == -1:
            image_width = 1000
        image_area = image_width * image_height
        return rect.width < image_width * 0.1 or rect.height < image_height * 0.05 or rect.area / image_area < 0.01

    @staticmethod
    def filter_rect_app_factory(rect: Rect, image_height=-1, image_width=-1) -> bool:
        if image_height == -1:
            image_height = 2000
        if image_width == -1:
            image_width = 1000
        image_area = image_width * image_height
        return rect.width < image_width * 0.15 or rect.height < image_height * 0.075 or rect.area / image_area < 0.05
