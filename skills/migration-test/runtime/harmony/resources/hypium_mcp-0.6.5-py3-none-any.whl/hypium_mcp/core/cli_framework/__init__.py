"""
CLI Framework Module

Provides a modern, type-safe command-line interface framework with automatic
parameter discovery and registration.
"""

from hypium_mcp.core.cli_framework.app import CLIApp
from hypium_mcp.core.cli_framework.models import CommandInfo, ParamInfo
from hypium_mcp.core.cli_framework.types import ParamKind, TypeHint

__all__ = [
    "CLIApp",
    "CommandInfo",
    "ParamInfo",
    "ParamKind",
    "TypeHint",
]