class ActionType:
    CLICK = 'click'
    DOUBLE_CLICK = 'double_click'
    LONG_CLICK = 'long_click'
    SWIPE = 'swipe'
    DRAG = 'drag'
    PINCH_IN = 'pinch_in'
    PINCH_OUT = 'pinch_out'
    INPUT_TEXT = "input_text"
    PRESS_KEY = "press_key"
    MOUSE_SCROLL = "mouse_scroll"
