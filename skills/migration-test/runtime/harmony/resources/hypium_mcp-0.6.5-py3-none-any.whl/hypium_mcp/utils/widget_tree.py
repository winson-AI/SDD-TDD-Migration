import json
import os
import re
from typing import Any, Dict, List, Optional, Iterator, Callable


class Bounds:
    def __init__(self, left: int, top: int, right: int, bottom: int):
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return self.bottom - self.top

    @property
    def center_x(self) -> int:
        return (self.left + self.right) // 2

    @property
    def center_y(self) -> int:
        return (self.top + self.bottom) // 2

    @property
    def center(self) -> tuple[int, int]:
        return (self.center_x, self.center_y)

    def contains(self, x: int, y: int) -> bool:
        return self.left <= x <= self.right and self.top <= y <= self.bottom

    def to_tuple(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.right, self.bottom)

    def __repr__(self) -> str:
        return f"Bounds(left={self.left}, top={self.top}, right={self.right}, bottom={self.bottom})"

    def __str__(self) -> str:
        return f"[{self.left},{self.top}][{self.right},{self.bottom}]"


class Widget:
    def __init__(self, attributes: Dict[str, Any], parent: Optional["Widget"] = None):
        self._attributes = attributes
        self._parent = parent
        self._children: List["Widget"] = []
        self._bounds: Optional[Bounds] = None

    def _parse_bounds(self, bounds_str: str) -> Optional[Bounds]:
        if not bounds_str:
            return None
        pattern = r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]"
        match = re.match(pattern, bounds_str)
        if match:
            return Bounds(
                int(match.group(1)),
                int(match.group(2)),
                int(match.group(3)),
                int(match.group(4))
            )
        return None

    @property
    def id(self) -> str:
        return self._attributes.get("id", "")

    @property
    def text(self) -> str:
        return self._attributes.get("text", "")

    @property
    def type(self) -> str:
        return self._attributes.get("type", "")

    @property
    def clickable(self) -> bool:
        val = self._attributes.get("clickable", "")
        return val.lower() == "true" if val else False

    @property
    def scrollable(self) -> bool:
        val = self._attributes.get("scrollable", "")
        return val.lower() == "true" if val else False

    @property
    def bounds(self) -> Optional[Bounds]:
        if self._bounds is None:
            bounds_str = self._attributes.get("bounds", "")
            self._bounds = self._parse_bounds(bounds_str)
        return self._bounds

    @property
    def enabled(self) -> bool:
        val = self._attributes.get("enabled", "")
        return val.lower() == "true" if val else False

    @property
    def focused(self) -> bool:
        val = self._attributes.get("focused", "")
        return val.lower() == "true" if val else False

    @property
    def selected(self) -> bool:
        val = self._attributes.get("selected", "")
        return val.lower() == "true" if val else False

    @property
    def checkable(self) -> bool:
        val = self._attributes.get("checkable", "")
        return val.lower() == "true" if val else False

    @property
    def checked(self) -> bool:
        val = self._attributes.get("checked", "")
        return val.lower() == "true" if val else False

    @property
    def long_clickable(self) -> bool:
        val = self._attributes.get("longClickable", "")
        return val.lower() == "true" if val else False

    @property
    def accessibility_id(self) -> str:
        return self._attributes.get("accessibilityId", "")

    @property
    def description(self) -> str:
        return self._attributes.get("description", "")

    @property
    def hint(self) -> str:
        return self._attributes.get("hint", "")

    @property
    def bundle_name(self) -> str:
        return self._attributes.get("bundleName", "")

    @property
    def parent(self) -> Optional["Widget"]:
        return self._parent

    @property
    def children(self) -> List["Widget"]:
        return self._children

    @property
    def root(self) -> "Widget":
        current = self
        while current._parent is not None:
            current = current._parent
        return current

    @property
    def depth(self) -> int:
        depth = 0
        current = self._parent
        while current is not None:
            depth += 1
            current = current._parent
        return depth

    def get(self, attr_name: str, default: Any = None) -> Any:
        return self._attributes.get(attr_name, default)

    def __getitem__(self, attr_name: str) -> Any:
        return self._attributes[attr_name]

    def __contains__(self, attr_name: str) -> bool:
        return attr_name in self._attributes

    def add_child(self, child: "Widget") -> None:
        child._parent = self
        self._children.append(child)

    def find(self, predicate: Callable[["Widget"], bool]) -> Optional["Widget"]:
        if predicate(self):
            return self
        for child in self._children:
            result = child.find(predicate)
            if result is not None:
                return result
        return None

    def find_all(self, predicate: Callable[["Widget"], bool]) -> List["Widget"]:
        results: List["Widget"] = []
        if predicate(self):
            results.append(self)
        for child in self._children:
            results.extend(child.find_all(predicate))
        return results

    def find_by_id(self, id_value: str) -> Optional["Widget"]:
        return self.find(lambda w: w.id == id_value)

    def find_by_text(self, text: str, exact: bool = True) -> List["Widget"]:
        if exact:
            return self.find_all(lambda w: w.text == text)
        return self.find_all(lambda w: text.lower() in w.text.lower())

    def find_by_type(self, type_name: str) -> List["Widget"]:
        return self.find_all(lambda w: w.type == type_name)

    def find_clickable(self) -> List["Widget"]:
        return self.find_all(lambda w: w.clickable)

    def find_scrollable(self) -> List["Widget"]:
        return self.find_all(lambda w: w.scrollable)

    def find_by_position(self, x: int, y: int) -> Optional["Widget"]:
        result: Optional["Widget"] = None
        for widget in self.iter():
            if widget.bounds and widget.bounds.contains(x, y):
                if result is None or widget.depth > result.depth:
                    result = widget
        return result

    def find_by(
        self,
        attr_name: str,
        attr_value: Any,
        mode: str = "equal",
        case_sensitive: bool = False
    ) -> List["Widget"]:
        """
        Find all widgets matching the given attribute criteria.

        Args:
            attr_name: Name of the attribute to match (e.g., 'text', 'id', 'type')
            attr_value: Value to match against
            mode: Matching mode, one of:
                - 'equal': Exact match (default)
                - 'contains': Attribute value contains the target
                - 'starts_with': Attribute value starts with the target
                - 'ends_with': Attribute value ends with the target
                - 'regexp': Attribute value matches the regex pattern
            case_sensitive: Whether matching is case-sensitive (default: False)

        Returns:
            List of matching Widget objects
        """
        def _get_value() -> Any:
            if hasattr(self, attr_name):
                return getattr(self, attr_name)
            return self.get(attr_name, "")

        def _compare() -> bool:
            val = _get_value()
            target = attr_value

            val_str = str(val) if val is not None else ""
            target_str = str(target) if target is not None else ""

            if not case_sensitive:
                val_str = val_str.lower()
                target_str = target_str.lower()

            if mode == "equal":
                return val_str == target_str
            elif mode == "contains":
                return target_str in val_str
            elif mode == "starts_with":
                return val_str.startswith(target_str)
            elif mode == "ends_with":
                return val_str.endswith(target_str)
            elif mode == "regexp":
                return bool(re.search(target, val_str))
            else:
                return val_str == target_str

        results: List["Widget"] = []
        if _compare():
            results.append(self)
        for child in self._children:
            results.extend(child.find_by(attr_name, attr_value, mode, case_sensitive))
        return results

    def iter(self) -> Iterator["Widget"]:
        yield self
        for child in self._children:
            yield from child.iter()

    def iter_children(self) -> Iterator["Widget"]:
        for child in self._children:
            yield from child.iter()

    def ancestors(self) -> Iterator["Widget"]:
        current = self._parent
        while current is not None:
            yield current
            current = current._parent

    def siblings(self) -> List["Widget"]:
        if self._parent is None:
            return []
        return [w for w in self._parent.children if w is not self]

    def to_dict(self, include_children: bool = False) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        if self.id:
            result["id"] = self.id
        if self.text:
            result["text"] = self.text
        if self.type:
            result["type"] = self.type
        if self.clickable:
            result["clickable"] = self.clickable
        if self.scrollable:
            result["scrollable"] = self.scrollable
        if self.bounds:
            result["bounds"] = [
                self.bounds.left,
                self.bounds.top,
                self.bounds.right,
                self.bounds.bottom,
            ]
            result["center"] = [self.bounds.center_x, self.bounds.center_y]
        if include_children:
            result["children"] = [child.to_dict(include_children=True) for child in self._children]
        return result

    def __len__(self) -> int:
        count = 1
        for child in self._children:
            count += len(child)
        return count

    def __repr__(self) -> str:
        parts = []
        if self.type:
            parts.append(f"type={self.type!r}")
        if self.id:
            parts.append(f"id={self.id!r}")
        if self.text:
            parts.append(f"text={self.text[:20]!r}")
        if self.bounds:
            parts.append(f"bounds={self.bounds}")
        return f"Widget({', '.join(parts)})"

    def __str__(self, indent: int = 0) -> str:
        prefix = "  " * indent
        result = f"{prefix}{self!r}"
        for child in self._children:
            result += "\n" + child.__str__(indent + 1)
        return result


class WidgetTree:
    def __init__(
        self,
        json_file_path: Optional[str] = None,
        layout_coordinate_mode: str = "relative"
    ):
        self._root: Optional[Widget] = None
        self._layout_coordinate_mode = layout_coordinate_mode
        self._scale_w: float = 1.0
        self._scale_h: float = 1.0
        if json_file_path:
            self.load(json_file_path)

    def _calculate_scale(self) -> None:
        if self._root is None or self._root.bounds is None:
            return
        if self._layout_coordinate_mode == "relative":
            root_w = self._root.bounds.width
            root_h = self._root.bounds.height
            self._scale_w = 1000.0 / root_w if root_w > 0 else 1.0
            self._scale_h = 1000.0 / root_h if root_h > 0 else 1.0

    def _normalize_bounds(self, bounds: Bounds) -> tuple[list[int], list[int]]:
        if self._layout_coordinate_mode != "relative":
            norm_bounds = [bounds.left, bounds.top, bounds.right, bounds.bottom]
            norm_center = [bounds.center_x, bounds.center_y]
        else:
            norm_bounds = [
                int(bounds.left * self._scale_w),
                int(bounds.top * self._scale_h),
                int(bounds.right * self._scale_w),
                int(bounds.bottom * self._scale_h),
            ]
            norm_center = [
                int(bounds.center_x * self._scale_w),
                int(bounds.center_y * self._scale_h),
            ]
        return norm_bounds, norm_center

    def load(self, json_file_path: str) -> None:
        with open(json_file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self._root = self._build_tree(data)
        self._calculate_scale()

    def load_from_dict(self, data: Dict[str, Any]) -> None:
        self._root = self._build_tree(data)
        self._calculate_scale()

    def _build_tree(self, node_data: Dict[str, Any], parent: Optional[Widget] = None) -> Widget:
        attributes = node_data.get("attributes", {})
        widget = Widget(attributes, parent)
        for child_data in node_data.get("children", []):
            child = self._build_tree(child_data, widget)
            widget.add_child(child)
        return widget

    @property
    def root(self) -> Optional[Widget]:
        return self._root

    def find(self, predicate: Callable[[Widget], bool]) -> Optional[Widget]:
        if self._root is None:
            return None
        return self._root.find(predicate)

    def find_all(self, predicate: Callable[[Widget], bool]) -> List[Widget]:
        if self._root is None:
            return []
        return self._root.find_all(predicate)

    def find_by_id(self, id_value: str) -> Optional[Widget]:
        return self.find(lambda w: w.id == id_value)

    def find_by_text(self, text: str, exact: bool = True) -> List[Widget]:
        if self._root is None:
            return []
        return self._root.find_by_text(text, exact)

    def find_by_type(self, type_name: str) -> List[Widget]:
        if self._root is None:
            return []
        return self._root.find_by_type(type_name)

    def find_clickable(self) -> List[Widget]:
        if self._root is None:
            return []
        return self._root.find_clickable()

    def find_scrollable(self) -> List[Widget]:
        if self._root is None:
            return []
        return self._root.find_scrollable()

    def find_by_position(self, x: int, y: int) -> Optional[Widget]:
        if self._root is None:
            return None
        return self._root.find_by_position(x, y)

    def find_by(
        self,
        attr_name: str,
        attr_value: Any,
        mode: str = "equal",
        case_sensitive: bool = False
    ) -> List[Widget]:
        """
        Find all widgets matching the given attribute criteria.

        Args:
            attr_name: Name of the attribute to match (e.g., 'text', 'id', 'type')
            attr_value: Value to match against
            mode: Matching mode, one of:
                - 'equal': Exact match (default)
                - 'contains': Attribute value contains the target
                - 'starts_with': Attribute value starts with the target
                - 'ends_with': Attribute value ends with the target
                - 'regexp': Attribute value matches the regex pattern
            case_sensitive: Whether matching is case-sensitive (default: False)

        Returns:
            List of matching Widget objects
        """
        if self._root is None:
            return []
        return self._root.find_by(attr_name, attr_value, mode, case_sensitive)

    def iter(self) -> Iterator[Widget]:
        if self._root is not None:
            yield from self._root.iter()

    def widget_to_dict(self, widget: Widget, include_children: bool = False) -> Dict[str, Any]:
        """
        Convert widget to dict with normalized coordinates based on layout_coordinate_mode.

        Args:
            widget: The Widget object to convert
            include_children: Whether to include children recursively

        Returns:
            Dictionary representation with properly normalized coordinates
        """
        result: Dict[str, Any] = {}
        if widget.id:
            result["id"] = widget.id
        if widget.text:
            result["text"] = widget.text
        if widget.type:
            result["type"] = widget.type
        if widget.clickable:
            result["clickable"] = widget.clickable
        if widget.scrollable:
            result["scrollable"] = widget.scrollable
        if "checked" in widget._attributes:
            result["checked"] = widget.checked
        if widget.bounds:
            norm_bounds, norm_center = self._normalize_bounds(widget.bounds)
            result["bounds"] = norm_bounds
            result["center"] = norm_center
        if include_children:
            result["children"] = [
                self.widget_to_dict(child, include_children=True)
                for child in widget.children
            ]
        return result

    def get_active_elements(self) -> List[Dict[str, Any]]:
        elements = []
        for widget in self.iter():
            has_content = (
                widget.text.strip()
                or widget.id.strip()
                or widget.description.strip()
                or widget.hint.strip()
            )
            if has_content:
                element = {}
                if widget.text.strip():
                    element["text"] = widget.text
                if widget.id.strip():
                    element["id"] = widget.id
                if widget.description.strip():
                    element["description"] = widget.description
                if widget.hint.strip():
                    element["hint"] = widget.hint
                if widget.type:
                    element["type"] = widget.type
                if widget.clickable:
                    element["clickable"] = widget.clickable
                if widget.scrollable:
                    element["scrollable"] = widget.scrollable
                if widget.checked:
                    element["checked"] = widget.checked
                if widget.bounds:
                    norm_bounds, norm_center = self._normalize_bounds(widget.bounds)
                    element["bounds"] = norm_bounds
                    element["center"] = norm_center
                elements.append(element)
        return elements

    def dump_active_elements(self, output_path: str, format_jsonl: bool = True) -> str:
        elements = self.get_active_elements()
        abs_path = os.path.abspath(output_path)
        with open(abs_path, "w", encoding="utf-8") as f:
            if format_jsonl:
                for elem in elements:
                    f.write(json.dumps(elem, ensure_ascii=False) + "\n")
            else:
                json.dump(elements, f, ensure_ascii=False, indent=2)
        return abs_path

    def __len__(self) -> int:
        if self._root is None:
            return 0
        return len(self._root)

    def __repr__(self) -> str:
        return f"WidgetTree(nodes={len(self)})"

    def __str__(self) -> str:
        if self._root is None:
            return "WidgetTree(empty)"
        return str(self._root)
