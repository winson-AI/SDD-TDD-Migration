import sqlite3


class ObjDict:
    def __init__(self, d):
        self.__dict__.update(d)


def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return ObjDict(d)


class TraceHelper:
    def __init__(self, trace_path: str):
        if trace_path.endswith('db'):
            db_path = trace_path
        else:
            db_path = trace_path.replace(trace_path.split('.')[-1], 'db')

        conn = sqlite3.connect(db_path)
        conn.row_factory = dict_factory
        self.sql_executor = conn.cursor()

    def query_one(self, sql):
        return self.sql_executor.execute(sql).fetchone()

    def query_all(self, sql):
        return self.sql_executor.execute(sql).fetchall()

    def get_trace_start_stop_time(self):
        vsync_list = self.query_all(f"select * from callstack where name like 'H:GenerateVsyncCount:%'")
        if len(vsync_list) == 0:
            return 0, 0
        return vsync_list[0].ts // 1000000, vsync_list[-1].ts // 1000000

    def get_touch_start_time(self):
        sql_str = "select * from callstack " \
                  "where name in ('H:PointerEventDispatch', 'H:touchEventDispatch', 'deliverInputEvent')"
        res_list = self.query_all(sql_str)
        if len(res_list) == 0:
            return 0
        return res_list[0].ts

    def get_donghu_surface_multi_time_list(self):
        name_key = 'anco#SurfaceView%'
        multi_time_list, _ = self.get_surface_multi_time_list(name_key)
        return multi_time_list

    def get_surface_multi_time_list(self, name_key='%Surface', sql_start_time=None, sql_end_time=None):
        filter_surface_name_list = \
            ['ChronosSurface', 'Live_ChronosSurface', 'nwebPreloadSurface', 'oh_flutter_',
             'Surface', 'HEncoderSurface', 'nodeId_-1Surface']
        sql_str = f"select * from callstack where name like 'H:ReleaseBuffer name: {name_key} queueId: %'"
        if sql_start_time is not None:
            sql_str += f' and ts > {sql_start_time}'
        if sql_end_time is not None:
            sql_str += f' and ts < {sql_end_time}'
        flush_buffer_list = self.query_all(sql_str)
        surface_dict = {}
        for item in flush_buffer_list:
            name = item.name
            form_name = name[22: name.index(' seq:')]
            should_filter = False
            for filter_name in filter_surface_name_list:
                if form_name.startswith(filter_name) and not form_name.startswith('SurfaceImage'):
                    should_filter = True
                    break
            if should_filter:
                continue

            if form_name not in surface_dict:
                surface_dict[form_name] = []
            if item.dur is not None:
                surface_dict[form_name].append(item.ts // 1000000)
        release_buffer_list = []
        surface_name_list = []
        for key in surface_dict:
            time_list = surface_dict[key]
            if len(time_list) > 2:
                release_buffer_list.append(time_list)
                surface_name_list.append(key[: key.index(' queueId:')])
        return release_buffer_list, surface_name_list