"""
Tool Loader Module

Dynamic tool loader for discovering and registering functions as MCP tools
or CLI commands.
"""

import importlib
import importlib.util
import inspect
import os
from typing import Any, Callable, Dict, List, Optional
from hypium_mcp.config.config import get_config
from hypium_mcp.core.tool_adapter import mcp_user_action

DEFAULT_TOOLS_MODULE = "hypium_mcp.tools"


class ToolLoader:
    """
    Tool loader that dynamically loads modules and discovers non-private functions.

    Supports loading from module names or file paths.
    """

    def __init__(self, module_name: Optional[str] = None, module_path: Optional[str] = None):
        """
        Initialize the tool loader.

        Args:
            module_name: Module name (e.g., 'basic')
            module_path: Module file path (e.g., './basic.py')
        """
        self._module = None
        self._tools: Dict[str, Callable] = {}

        if module_name:
            self.load_module(module_name)
        elif module_path:
            self.load_from_path(module_path)

    def load_module(self, module_name: str) -> None:
        """Load module by name."""
        self._module = importlib.import_module(module_name)
        self._scan_tools()

    def load_from_path(self, module_path: str) -> None:
        """Load module from file path."""
        spec = importlib.util.spec_from_file_location("dynamic_module", module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot import module from {module_path}")

        self._module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self._module)
        self._scan_tools()

    def _scan_tools(self) -> None:
        """Scan module for non-private functions."""
        self._tools = {}
        if self._module is None:
            return

        for name, obj in inspect.getmembers(self._module):
            # Filter: is function, not private, not module or class
            if (
                    inspect.isfunction(obj)
                    and not name.startswith("_")
                    and not inspect.ismodule(obj)
                    and not inspect.isclass(obj)
                    and obj.__module__ == self._module.__name__
            ):
                self._tools[name] = obj

    def get_tools(self) -> Dict[str, Callable]:
        """Get all discovered tool functions."""
        return self._tools

    def get_tool_names(self) -> List[str]:
        """Get all tool function names."""
        return list(self._tools.keys())

    def get_tool(self, name: str) -> Optional[Callable]:
        """Get a specific tool by name."""
        return self._tools.get(name)

    def has_tool(self, name: str) -> bool:
        """Check if a tool exists."""
        return name in self._tools

    def execute(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """Execute a tool by name."""
        tool = self.get_tool(name)
        if tool is None:
            raise ValueError(f"Tool '{name}' not found")
        return tool(*args, **kwargs)

    def get_tool_signature(self, name: str) -> inspect.Signature:
        """Get the signature of a tool."""
        tool = self.get_tool(name)
        if tool is None:
            raise ValueError(f"Tool '{name}' not found")
        return inspect.signature(tool)

    def get_tool_info(self, name: str) -> Dict[str, Any]:
        """Get detailed information about a tool."""
        tool = self.get_tool(name)
        if tool is None:
            raise ValueError(f"Tool '{name}' not found")

        sig = inspect.signature(tool)
        return {
            "name": name,
            "doc": tool.__doc__,
            "signature": str(sig),
            "parameters": list(sig.parameters.keys()),
            "returns": sig.return_annotation if sig.return_annotation != inspect.Signature.empty else None,
        }

    def get_all_tools_info(self) -> List[Dict[str, Any]]:
        """Get information about all tools."""
        return [self.get_tool_info(name) for name in self.get_tool_names()]

    def reload(self) -> None:
        """Reload the module and rediscover tools."""
        if self._module:
            importlib.reload(self._module)
            self._scan_tools()


def in_exclude_module(module_name, mode: Optional[str] = None):
    config = get_config()
    exclude_module = config.exclude_module.split(",")
    if module_name in exclude_module:
        return True

    # Mode filter
    mode_config = config.get_mode_config(mode)
    if mode_config.exclude_module and module_name in mode_config.exclude_module:
        return True

    return False


def in_include_module(module_name, mode: Optional[str] = None):
    config = get_config()

    # Mode filter: if include_module is configured in mode, use it first
    mode_config = config.get_mode_config(mode)
    if mode_config.include_module:
        if module_name not in mode_config.include_module:
            return False

    # Global filter
    include_module = config.include_module
    if not include_module:
        # 没有配置include module, 默认加载所有
        return True
    include_module = include_module.split(",")
    return module_name in include_module


def in_exclude_tools(tool_name, mode: Optional[str] = None):
    config = get_config()
    exclude_tools = config.exclude_tools.split(",")
    if tool_name in exclude_tools:
        return True

    # Mode filter
    mode_config = config.get_mode_config(mode)
    if mode_config.exclude_tools and tool_name in mode_config.exclude_tools:
        return True

    return False


def in_include_tools(tool_name, mode: Optional[str] = None):
    config = get_config()

    # Mode filter: if include_tools is configured in mode, use it first
    mode_config = config.get_mode_config(mode)
    if mode_config.include_tools:
        if tool_name not in mode_config.include_tools:
            return False

    # Global filter
    include_tools = config.include_tools
    if not include_tools:
        # 没有配置include module, 默认加载所有
        return True
    include_tools = include_tools.split(",")
    return tool_name in include_tools


def should_skip_module(module_name: str, mode: Optional[str] = None) -> bool:
    if in_exclude_module(module_name, mode):
        return True
    if not in_include_module(module_name, mode):
        return True
    return False


def should_skip_tool(tool_name: str, mode: Optional[str] = None) -> bool:
    if in_exclude_tools(tool_name, mode):
        return True
    if not in_include_tools(tool_name, mode):
        return True
    return False


def apply_tool_decorator(func: Callable, driver_injector: Optional[Callable[[Callable], Callable]]) -> Callable:
    if driver_injector:
        func = driver_injector(func)
    func = mcp_user_action(func)
    return func


def register_tools(tools_path: str, tools_module_name: str, register_func: Callable,
                   driver_injector: Callable[[Callable], Callable] = None,
                   mode: Optional[str] = None) -> None:
    """
    Load tools from a directory and register them.

    Args:
        tools_path: Path to directory containing tool modules
        tools_module_name: Base module name for tools
        register_func: Function to call for each discovered tool
        driver_injector: Function to call for each discovered tool
        mode: Mode name for filtering, None = use global mode from config
    """
    for item in os.listdir(tools_path):
        if item.startswith("_") or not item.endswith(".py"):
            continue
        module_name = os.path.splitext(os.path.basename(item))[0]
        if should_skip_module(module_name, mode):
            continue
        tool_loader = ToolLoader(module_name=f"{tools_module_name}.{module_name}")

        for name, func in tool_loader.get_tools().items():
            if should_skip_tool(name, mode):
                continue
            register_func(apply_tool_decorator(func, driver_injector))


def register_external_tools(tools_path: str, register_func: Callable,
                            driver_injector: Callable[[Callable], Callable] = None,
                            mode: Optional[str] = None) -> None:
    """
    Load tools from a directory using file paths (for external tools).

    Args:
        tools_path: Path to directory containing tool modules
        register_func: Function to call for each discovered tool
        mode: Mode name for filtering, None = use global mode from config
    """
    for item in os.listdir(tools_path):
        if item.startswith("_") or not item.endswith(".py"):
            continue
        module_name = os.path.basename(tools_path)
        if should_skip_module(module_name, mode):
            continue

        tool_loader = ToolLoader(module_path=os.path.join(tools_path, item))
        for name, func in tool_loader.get_tools().items():
            if should_skip_tool(name, mode):
                continue
            register_func(apply_tool_decorator(func, driver_injector))


def load_builtin_tools(tools_dir: Optional[str] = None,
                       driver_injector: Callable[[Callable], Callable] = None,
                       mode: Optional[str] = None) -> Dict[str, Dict]:
    """
    加载内置的工具集合
    Args:
        tools_dir: 工具目录路径
        driver_injector: 驱动注入函数
        mode: Mode name for filtering, None = use global mode from config

    Returns:
        返回工具函数集合, 格式为
        {
          "模块名称": {
            "工具函数名称": 工具函数对象(callable)
          }
        }
    """
    from hypium_mcp import tools
    tool_collection = {}
    if not tools_dir:
        tools_dir = os.path.dirname(tools.__file__)
    for item in os.listdir(tools_dir):
        if item.startswith("_") or not item.endswith(".py"):
            continue
        module_name = os.path.splitext(os.path.basename(item))[0]
        if should_skip_module(module_name, mode):
            continue
        tool_loader = ToolLoader(module_name="%s.%s" % (DEFAULT_TOOLS_MODULE, module_name))

        for name, func in tool_loader.get_tools().items():
            if should_skip_tool(name, mode):
                continue
            if module_name not in tool_collection:
                tool_collection[module_name] = {}
            tool_collection[module_name][name] = apply_tool_decorator(func, driver_injector)
    return tool_collection
