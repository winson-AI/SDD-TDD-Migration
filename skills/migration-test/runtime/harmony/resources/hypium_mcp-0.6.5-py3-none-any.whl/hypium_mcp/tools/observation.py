"""
观察模块

提供设备观察功能，如屏幕截图、布局分析。
"""
from typing import Any, Dict, List, Optional

from hypium import UiDriver

import os
import time
import tempfile
from hypium_mcp.utils.log import get_logger as _get_logger
from hypium_mcp.utils.widget_tree import WidgetTree
from hypium_mcp.config.config import get_config

logger = _get_logger("Observation")


def _get_auto_path(file_type: str, extension: str) -> str:
    """
    自动生成文件路径

    Args:
        file_type: 文件类型，如 "screenshots", "layouts"
        extension: 文件扩展名，如 "jpg", "json"

    Returns:
        自动生成的绝对路径
    """
    config = get_config()
    timestamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    output_dir = os.path.join(config.output_dir, file_type)
    os.makedirs(output_dir, exist_ok=True)
    filename = f"{timestamp}_{int(time.time() * 1000)}.{extension}"
    return os.path.abspath(os.path.join(output_dir, filename))


def screenshot(device: UiDriver, save_path: Optional[str] = None) -> str:
    """
    获取屏幕截图

    Args:
        save_path: 屏幕截图保存路径，仅支持jpg格式文件。
                   未指定时自动保存到配置的output_dir/screenshots目录下

    Returns:
        截图保存绝对路径
    """
    if save_path is None:
        save_path = _get_auto_path("screenshots", "jpg")
        logger.info("自动生成截图路径: %s", save_path)

    dirname = os.path.dirname(save_path)
    if dirname and not os.path.exists(dirname):
        os.makedirs(dirname)
        logger.info("创建路径: %s", dirname)
    device.screenshot(save_path)
    return os.path.abspath(save_path)


def layout(
    device: UiDriver,
    save_path: Optional[str] = None
) -> str:
    """
    获取设备当前UI布局并提取有效元素。

    使用device.UiTree.dump_to_file获取原始layout文件，然后提取active elements。

    Args:
        device: UiDriver实例
        save_path: 输出文件路径。
                   未指定时自动保存到配置的output_dir/layouts目录下
    Returns:
        输出文件的绝对路径
    """
    format_jsonl: bool = True
    layout_coordinate_mode: str = "relative"

    if save_path is None:
        save_path = _get_auto_path("layouts", "jsonl")
        logger.info("自动生成layout路径: %s", save_path)

    dirname = os.path.dirname(save_path)
    if dirname and not os.path.exists(dirname):
        os.makedirs(dirname)
        logger.info("创建路径: %s", dirname)

    raw_layout_path = save_path + ".raw.json"
    device.UiTree.dump_to_file(raw_layout_path)
    logger.info("原始layout已保存: %s", raw_layout_path)

    tree = WidgetTree(raw_layout_path, layout_coordinate_mode=layout_coordinate_mode)
    output_path = tree.dump_active_elements(save_path, format_jsonl=format_jsonl)
    logger.info("Active elements已导出: %s", output_path)

    return output_path


def find_elements(
    device: UiDriver,
    attr_name: str,
    attr_value: Any,
    mode: str = "equal",
    case_sensitive: bool = False
) -> List[Dict[str, Any]]:
    """
    在当前UI布局中查找符合条件的元素。

    Args:
        device: UiDriver实例
        attr_name: 属性名称（如'text', 'id', 'type'等）
        attr_value: 要匹配的属性值
        mode: 匹配模式, 如果不需要模糊匹配可以不传:
            - 'equal': 精确匹配（默认）
            - 'contains': 包含
            - 'starts_with': 前缀匹配
            - 'ends_with': 后缀匹配
            - 'regexp': 正则匹配
        case_sensitive: 是否区分大小写，默认为False

    Returns:
        匹配的元素列表，每个元素已用widget_to_dict()序列化（最多返回10个）
    """
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        temp_path = f.name

    try:
        device.UiTree.dump_to_file(temp_path)
        tree = WidgetTree(temp_path)
        widgets = tree.find_by(attr_name, attr_value, mode, case_sensitive)
        return [tree.widget_to_dict(w) for w in widgets[:10]]
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)