"""
屏幕操作

提供高级屏幕相关功能，包括设备屏幕控制。
"""
from typing import Optional

from hypium import UiDriver
from hypium.model import DisplayRotation


def unlock_screen(device: UiDriver, delay: int = 1) -> Optional[str]:
    """
    解锁设备屏幕, 接口无需参数。

    Returns:
        解锁结果
    """
    device.unlock()
    device.wait(delay)


def screen_on(device: UiDriver, delay: int = 1):
    """
    打开设备屏幕, 接口无需参数。
    """
    device.wake_up_display()
    device.wait(delay)


def screen_off(device: UiDriver, delay: int = 1):
    """
    关闭设备屏幕，接口无需参数。
    """
    device.close_display()
    device.wait(delay)

def rotate_screen(device: UiDriver, direction: str):
    """
    旋转设备屏幕方向，支持横屏和竖屏模式。
    Args:
        direction: 旋转方向，支持 
                   "landscape": 横屏模式
                   "portrait": 竖屏模式
    Returns:

    """
    if direction == "portrait":
        device.set_display_rotation(DisplayRotation.ROTATION_0)
    else:
        device.set_display_rotation(DisplayRotation.ROTATION_270)