from abc import abstractmethod, ABC
from typing import Generic, List, TypeVar

from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import BaseFlashImageInfo, \
    ScreenFlashImageInfo


class MotionalImageInfo(BaseFlashImageInfo, ABC):
    pass


BaseMotionalInfo = TypeVar('BaseMotionalInfo', MotionalImageInfo, None)


class BaseMotionalAnalyzer(Generic[BaseMotionalInfo]):

    def __init__(self, flash_params: FlashParams):
        self.flash_params = flash_params

    @abstractmethod
    def compare_image_info(self, prev_image_info: ScreenFlashImageInfo,
                           curr_image_info: ScreenFlashImageInfo) -> BaseMotionalInfo:
        pass

    @abstractmethod
    def analyze_image_info_list(self, image_info_list: List[BaseMotionalInfo]):
        pass
