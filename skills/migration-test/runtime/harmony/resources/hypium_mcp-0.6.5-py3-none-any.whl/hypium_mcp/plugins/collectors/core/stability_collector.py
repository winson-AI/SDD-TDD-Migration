import json
import os
import time
from pathlib import Path

from hypium_mcp.plugins.collectors.core.base_collector import BaseCollector
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Collector)


class StabilityCollector(BaseCollector):

    def __init__(self):
        super().__init__()
        self.start_time = None
        self.stop_time = None
        self.stability_hisys_data = os.path.join(self.data_dir, "stability.hisys")
        self.stability_data = os.path.join(self.data_dir, "stability.json")
        self.stability_log_dir = os.path.join(self.data_dir, "StabilityLogs")
        self.pid_list = [None]

    def case_start(self):
        logger.info("稳定性数据采集开始")
        self.start_time = time.time()

    def case_stop(self):
        logger.info("稳定性数据采集结束")
        self.pid_list.remove(None)
        self.stop_time = time.time()
        if self.start_time is None or self.stop_time is None:
            logger.error(f"稳定性检测失败, {self.start_time = }, {self.stop_time = }")
            return
        res = self.driver.shell(f"hisysevent -l -o RELIABILITY -s {self.start_time} -e {self.stop_time}")
        # 落盘 hisys 文件
        self.write_data(res, Path(self.stability_data))

        # 筛选hisysevent到json文件
        fault_type_dict_list = self.build_hisysevent_json(res)
        self.write_data(json.dumps(fault_type_dict_list, indent=4, ensure_ascii=False), self.stability_data)

        # 抓取维测日志
        if fault_type_dict_list[0].get("ADDR_SANITIZER") != 0:
            self.catch_fault_log(fault_type_dict_list[0], self.stability_log_dir)

        if fault_type_dict_list[1].get("JS_ERROR") != 0:
            self.catch_fault_log(fault_type_dict_list[1], self.stability_log_dir)

        if fault_type_dict_list[2].get("CPP_CRASH") != 0:
            self.catch_fault_log(fault_type_dict_list[2], self.stability_log_dir)

        if fault_type_dict_list[3].get("FD_LEAK") != 0:
            self.catch_fault_log(fault_type_dict_list[3], self.stability_log_dir)
            self.catch_leak_log("FD_LEAK", self.pid_list, self.stability_log_dir)

        if fault_type_dict_list[4].get("APP_FREEZE") != 0:
            self.catch_fault_log(fault_type_dict_list[4], self.stability_log_dir)

        if fault_type_dict_list[5].get("MEMORY_LEAK") != 0:
            self.catch_fault_log(fault_type_dict_list[5], self.stability_log_dir)
            self.catch_leak_log("MEMORY_LEAK", self.pid_list, self.stability_log_dir)

        if fault_type_dict_list[6].get("THREAD_LEAK") != 0:
            self.catch_fault_log(fault_type_dict_list[6], self.stability_log_dir)
            self.catch_leak_log("THREAD_LEAK", self.pid_list, self.stability_log_dir)

        # 抓取稳定性文件
        logger.info(f"稳定性结果保存路径 {self.stability_data}")

    def action_start(self, action_id: str):
        package_name, page_name = self.driver.current_app()
        pid = self.find_pid(package_name, self.pid_list[-1])
        if pid not in self.pid_list:
            logger.info(f"应用 {package_name} pid 刷新: {pid}")
            self.pid_list.append(pid)

    def action_stop(self, action_id: str):
        pass

    def name(self):
        return "稳定性"

    def find_pid(self, package_name: str, cache_pid: str | None = None, timeout=10) -> str | None:
        res = self.driver.shell(f"pidof {package_name}", timeout)
        if res:
            pid_line = res.splitlines()[0]
            if cache_pid and cache_pid in pid_line:
                return cache_pid
            return pid_line.split(" ")[0].strip()
        return None

    def build_hisysevent_json(self, hisysevent_json_path: str):
        """
            # @Func: 构造6大稳定性故障类型的hisysevent信息json文件
        """
        fault_type_dict_list = []
        json_str_list = hisysevent_json_path.strip().split('}\n')
        json_dic_list = []
        # 6大稳定性故障，7个故障类型（crash分为两个）
        stability_fault_type = ["ADDR_SANITIZER", "JS_ERROR", "CPP_CRASH", "FD_LEAK",
                               "APP_FREEZE", "MEMORY_LEAK", "THREAD_LEAK"]
        key_report_list = ["name_", "time", "LOG_PATH", "time_"]
        if json_str_list != [""]:
            for item in json_str_list:
                item = item.replace("\n", "\\n")
                if item[-1] != "}":
                    item = item + "}"
                item_dic = json.loads(item)
                item_dic_cut = {k: v for k, v in item_dic.items() if k in key_report_list}
                if item_dic_cut.get("name_") in stability_fault_type:
                    json_dic_list.append(item_dic_cut)

        for item in stability_fault_type:
            fault_type_dict_list.append(self.build_fault_type_dict(item, json_dic_list))
        return fault_type_dict_list

    @staticmethod
    def build_fault_type_dict(fault_type: str, json_dic_list: list):
        log_list = []
        fault_type_dict = {fault_type: 0, "LOGs": log_list}
        frequency = 0
        for item in json_dic_list:
            if item.get("name_") == fault_type:
                frequency += 1
                log_list.append({key: value for key, value in item.items() if key != "name_"})
        fault_type_dict[fault_type] = frequency
        return fault_type_dict

    def catch_leak_log(self, leak_type: str, pid_list: list, fault_log_path: str):
        if leak_type == "FD_LEAK":
            ls = self.driver.execute_shell("ls /data/log/reliability/resource_leak/fd_leak")
            txt_list = ls.strip().split("\n")
            for txt in txt_list:
                for pid in pid_list:
                    if pid in txt:
                        self.driver.pull_file(f"/data/log/reliability/resource_leak/fd_leak/{txt}",
                                              os.path.join(fault_log_path, txt))
        elif leak_type == "MEMORY_LEAK":
            ls = self.driver.execute_shell("ls /data/log/reliability/resource_leak/memory_leak")
            txt_list = ls.strip().split("\n")
            for txt in txt_list:
                for pid in pid_list:
                    if pid in txt:
                        self.driver.pull_file(f"/data/log/reliability/resource_leak/memory_leak/{txt}",
                                              os.path.join(fault_log_path, txt))
        elif leak_type == "THREAD_LEAK":
            ls = self.driver.execute_shell("ls /data/log/reliability/resource_leak/thread_leak")
            txt_list = ls.strip().split("\n")
            for txt in txt_list:
                for pid in pid_list:
                    if pid in txt:
                        self.driver.pull_file(f"/data/log/reliability/resource_leak/thread_leak/{txt}",
                                              os.path.join(fault_log_path, txt))

    def catch_fault_log(self, fault_type_dict: dict, fault_log_path: str):
        if fault_type_dict.get("LOGs") != []:
            for log_item in fault_type_dict.get("LOGs"):
                log_path = log_item.get("LOG_PATH")
                if log_path is not None:
                    self.driver.pull_file(log_path, os.path.join(fault_log_path, log_path.split('/')[-1]))
