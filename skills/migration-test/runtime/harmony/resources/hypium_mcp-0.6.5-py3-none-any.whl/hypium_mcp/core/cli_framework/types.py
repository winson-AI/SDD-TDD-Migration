"""
Type definitions for the CLI framework.
"""

from enum import Enum
from inspect import Parameter
from typing import Union, Type, Any


class ParamKind(str, Enum):
    """Parameter kind classification."""

    POSITIONAL = "positional"
    POSITIONAL_ONLY = "positional_only"
    KEYWORD_ONLY = "keyword_only"
    VAR_POSITIONAL = "var_positional"
    VAR_KEYWORD = "var_keyword"

    @classmethod
    def from_inspect(cls, param: Parameter) -> "ParamKind":
        """Create ParamKind from inspect.Parameter."""
        if param.kind == Parameter.VAR_POSITIONAL:
            return cls.VAR_POSITIONAL
        elif param.kind == Parameter.VAR_KEYWORD:
            return cls.VAR_KEYWORD
        elif param.kind == Parameter.POSITIONAL_ONLY:
            return cls.POSITIONAL_ONLY
        elif param.kind == Parameter.KEYWORD_ONLY:
            return cls.KEYWORD_ONLY
        else:
            return cls.POSITIONAL

    @property
    def is_var(self) -> bool:
        """Whether this is a variable (*args or **kwargs) parameter."""
        return self in (self.VAR_POSITIONAL, self.VAR_KEYWORD, self.POSITIONAL_ONLY)


TypeHint = Union[Type[Any], str, None]