import functools
import os
import time
from typing import Callable

from hypium_mcp.plugins.collectors.collector_manager import CollectorManager
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.MCP)

def mcp_collector_enabled(func):
    """MCP操作采集装饰器"""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if os.getenv("HYPIUM_MCP_COLLECT_ENABLE") != "True":
            return func(*args, **kwargs)
        logger.info(f"执行方法 {func.__qualname__}, 执行参数 {kwargs}")
        # 检查是否启用采集
        CollectorManager.action_start()
        try:
            result = func(*args, **kwargs)
            time.sleep(2)
            return result
        finally:
            CollectorManager.dump_context(parse_func(func, kwargs))
            CollectorManager.action_stop()

    return wrapper

def parse_func(func: Callable, kwargs) -> dict:
    json_dict = {"func_name": func.__qualname__}
    if func.__qualname__ == "swipe":
        x1, y1 = kwargs.get("start")
        x2, y2 = kwargs.get("end")
        if x1 == x2:
            json_dict["swipe_direction"] = "vertical"
        else:
            json_dict["swipe_direction"] = "horizontal"
    return json_dict
