"""
设备管理模块

提供设备列表查询、设备切换、释放功能。
"""
from typing import Dict, List

from hypium_mcp.device.device_manager import DeviceManager


def list_devices() -> List[Dict[str, str]]:
    """
    获取所有可用设备列表，包含设备SN和设备类型

    Returns:
        设备列表，每个元素包含:
        - sn: 设备序列号
        - type: 设备类型
    """
    dm = DeviceManager.get_instance()
    return dm.list_devices_with_type()


def connect_device(sn: str) -> Dict[str, str]:
    """
    切换默认连接的设备

    Args:
        sn: 要切换的设备序列号

    Returns:
        切换结果信息
    """
    dm = DeviceManager.get_instance()
    return dm.switch_device(sn)


def get_current_device() -> Dict[str, str]:
    """
    获取当前设备信息

    Returns:
        当前设备信息，包含:
        - sn: 设备序列号
        - type: 设备类型
        - status: 连接状态
    """
    dm = DeviceManager.get_instance()
    return dm.get_current_device_info()


def release_device(device_id: str) -> Dict[str, str]:
    """
    释放指定设备ID的连接

    Args:
        device_id: 要释放的设备序列号

    Returns:
        释放结果信息，包含:
        - status: 操作状态 (success/not_found)
        - device_id: 被释放的设备ID
    """
    dm = DeviceManager.get_instance()
    return dm.release_device(device_id)