"""
Logger Module

Structured logging with rich formatting and colored output.
"""
import logging
import os
import time
from pathlib import Path
from typing import Dict, Any

from hypium_mcp.config.config import get_config


class LoggerName:
    Detector = "detector"
    Collector = "collector"
    MCP = "MCP"
    HypiumMCP = "HypiumMCP"


class LabelLogAdapter(logging.LoggerAdapter):
    """
    带有标签的日志适配器
    """
    def process(self, msg: str, kwargs: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
        """
        处理日志消息，添加标签信息
        """
        if hasattr(self, 'label'):
            return f"[{self.label}] {msg}", kwargs
        return msg, kwargs


# 全局logger实例
_global_logger = None
# 全局log adapters
_global_log_adapters = None


def _init_global_logger():
    """
    初始化全局logger
    """
    global _global_logger, _global_log_adapters
    
    if _global_logger is None:
        # 创建基础logger
        logger = logging.getLogger("HypiumMCP")
        
        # 添加控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(thread)d] %(levelname)s: %(message)s"))
        logger.addHandler(console_handler)
        
        # 添加文件处理器
        config = get_config()
        output_dir = config.output_dir
        
        # 确保输出目录存在
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # 生成可读的时间戳
        readable_timestamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
        log_file = os.path.join(output_dir, f"hypium_mcp_{readable_timestamp}.log")
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(thread)d] %(levelname)s: %(message)s"))
        logger.addHandler(file_handler)
        
        # 设置日志级别
        log_level = getattr(logging, config.log_level.upper(), logging.INFO)
        logger.setLevel(log_level)
        
        _global_logger = logger
    
    if _global_log_adapters is None:
        # 创建多个标签的LogAdapter
        adapters = {}
        for label_name in dir(LoggerName):
            if not label_name.startswith('_'):
                label = getattr(LoggerName, label_name)
                adapter = LabelLogAdapter(_global_logger, {})
                adapter.label = label
                adapters[label] = adapter
        
        _global_log_adapters = adapters


def get_logger(name: str = LoggerName.HypiumMCP) -> LabelLogAdapter:
    """
    Get the global logger instance with the specified name.

    Args:
        name: Optional logger name. Defaults to LoggerName.HypiumMCP.

    Returns:
        LabelLogAdapter for the specified name
    """
    # 确保全局logger已初始化
    _init_global_logger()
    
    # 如果名称不存在，创建一个新的
    if name not in _global_log_adapters:
        adapter = LabelLogAdapter(_global_logger, {})
        adapter.label = name
        _global_log_adapters[name] = adapter
    return _global_log_adapters[name]


# 初始化全局logger
_init_global_logger()
