import os
import socket
import time
from pathlib import Path

import requests

from hypium_mcp.plugins.collectors.core.base_collector import BaseCollector
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Collector)


def find_unused_local_port():
    """获取一个未使用的本地端口号"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("", 0))
        _, port = sock.getsockname()
    return port


TMP_PATH = "/data/local/tmp"
SO_NAME = "perfmonitor.so"


class VideoCollector(BaseCollector):
    """基础视频采集器"""
    PROCESS_NAME = "perfmonitor"
    PERF_FACT_PATH = "/data/local/tmp/perf_fact"
    VIDEO_PATH = "/data/local/tmp/perf_fact/video"
    OPEN_URL = 'http://127.0.0.1:{port}/StartRecord'
    CLOSE_URL = 'http://127.0.0.1:{port}/StopRecord'
    MONO_URL = 'http://127.0.0.1:{port}/GetMonotonicTime'
    CHECK_URL = 'http://127.0.0.1:{port}/GetRecordStatus'

    COMMAND_TIMEOUT = 10
    MAX_RETRY_TIME = 5

    def __init__(self):
        super().__init__()

        self.video_ratio = 100
        self.queue_size = 4
        self._comm_port = find_unused_local_port()
        self.so_path = os.path.join(TMP_PATH, SO_NAME)
        self.so_cmd = None
        logger.info(f"使用本地端口号: {self._comm_port}")

        # 预置操作
        so_resources = Path(__file__).parent.parent.joinpath("resources")
        logger.info(f"清理资源结果: {self._clean_so_resource(so_resources)}")
        logger.info(f"初始化资源结果: {self._init_so_resource(so_resources)}")
        logger.info(f"虚拟屏状态检查链接: {self.CHECK_URL.format(port=self._comm_port)}")

    def case_start(self):
        super().case_start()
        self.driver.shell(f"mkdir -p {self.VIDEO_PATH}")

    def case_stop(self):
        super().case_stop()
        self.driver.shell(f"rm -rf {self.VIDEO_PATH}")

    def action_start(self, action_id: str):
        logger.info("视频采集开始")
        video_name = self.get_video_name(action_id)
        self.start_video(video_name)

    def action_stop(self, action_id: str):
        logger.info("视频采集结束")
        video_name = self.get_video_name(action_id)
        save_path = os.path.join(self.get_action_path(action_id), video_name)
        self.stop_video(video_name, save_path)

    def start_video(self, video_name: str):
        open_res = self.communicate_with_device(self.OPEN_URL, {"scale": self.video_ratio,
                                                                "video_name": video_name,
                                                                "queueSize": self.queue_size})
        logger.info(f"虚拟屏采集开始响应: {open_res}")

    def stop_video(self, video_name: str, save_path: str):
        close_res = self.communicate_with_device(self.CLOSE_URL)
        logger.info(f"虚拟屏采集关闭响应: {close_res}")
        self.driver.pull_file(f"{TMP_PATH}/perf_fact/video/{video_name}", save_path)
        logger.info(f"视频文件存储在: {save_path}")
        self.driver.shell(f"rm -rf {TMP_PATH}/perf_fact/video/*" + video_name)

    @staticmethod
    def get_video_name(action_id: str):
        return f"{action_id}.mp4"

    def _init_so_resource(self, so_resources: Path) -> bool:
        """初始化SO资源"""
        self.driver.hdc(f"fport tcp:{self._comm_port} tcp:9999")
        for so_file in so_resources.iterdir():
            so_name = so_file.name
            device_so_path = TMP_PATH + "/" + so_name
            self.driver.push_file(str(so_file), device_so_path)
            so_cmd = "uitest start-daemon singleness --extension-name " + so_name
            self.driver.shell(so_cmd)
            time.sleep(5)
            res = self.driver.shell("ps -ef | grep uitest")
            logger.info(f"uitest 进程: " + res)
            if so_name in res:
                self.so_cmd = so_cmd
                return True
        return False

    def _clean_so_resource(self, so_resources: Path):
        """清理SO资源"""
        self.driver.shell("killall " + self.PROCESS_NAME)
        self.clean_fport()
        for so_file in so_resources.iterdir():
            so_name = so_file.name
            device_so_path = TMP_PATH + "/" + so_name
            self.driver.shell(f"rm {device_so_path}")
        return True

    def clean_fport(self):
        fport_str = self.driver.hdc("fport ls")
        fport_list = fport_str.splitlines()
        for fport_single in fport_list:
            try:
                if not fport_single.startswith(self.driver.device_sn):
                    continue
                fport_unit = fport_single.split()
                if len(fport_unit) < 4 or fport_unit[2] != 'tcp:9999':
                    continue
                logger.info(f"清理端口 {fport_unit}")
                self.driver.hdc(f"fport rm {fport_unit[1]} {fport_unit[2]}")
            except Exception as e:
                logger.error(f'删除 fport 规则失败: {fport_single}', exc_info=e)

    def communicate_with_device(self, url_template: str, payload: dict = None, timeout=COMMAND_TIMEOUT,
                                raise_ex: bool = False):
        request_url = url_template.format(port=self._comm_port)
        try:
            return requests.get(request_url, params=payload, timeout=timeout)
        except Exception as e:
            if raise_ex:
                raise e
            logger.error(f"虚拟屏HTTP请求失败: {request_url}", exc_info=e)
            return None

    def name(self):
        return "视频"
