import bisect
import os.path
from typing import Any

import cv2
from hypium_mcp.plugins.detectors.core.base_detector import BaseDetector
from hypium_mcp.plugins.detectors.core.detection_result import DetectionResult
from hypium_mcp.plugins.detectors.core.helper.trace_helper import TraceHelper
from hypium_mcp.plugins.detectors.core.video_jank.video_common_method import VideoCommonMethod
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)

IMAGE_FORMAT = '.png'


class TaskParams:
    def __init__(self, trace_start_time, trace_stop_time, touch_start_time, start_time,
                 sql_instance, image_path, image_list, is_seek):
        self.trace_start_time = trace_start_time
        self.trace_stop_time = trace_stop_time
        self.touch_start_time = touch_start_time
        self.start_time = start_time
        self.sql_instance = sql_instance
        self.image_path = image_path
        self.image_list = image_list
        self.is_seek = is_seek


def get_sorted_file_time_list(dir_path, start_time):
    file_num_list = []
    for file_name in os.listdir(dir_path):
        if file_name.endswith(IMAGE_FORMAT):
            num = int(file_name.replace(IMAGE_FORMAT, ''))
            file_num_list.append(num)
    file_num_list.sort()
    image_len = len(file_num_list)
    start_index = 0
    for index in range(image_len):
        if file_num_list[index] <= start_time < file_num_list[index + 1]:
            start_index = index
            break
    return file_num_list[start_index:]


def get_pixel_diff(compare_image, finish_image, threshold=20):
    return VideoCommonMethod.get_pixel_diff(compare_image, finish_image, threshold)


def get_multi_time_list_by_codec(sql_instance, touch_start_time, is_seek):
    codec_multi_time_list = VideoCommonMethod.get_codec_multi_time_list(touch_start_time, sql_instance, is_seek=is_seek)
    logger.debug(f'codec_multi_time_list: {codec_multi_time_list}')
    result_multi_time_list = []
    if codec_multi_time_list:
        for codec_time_list in codec_multi_time_list:
            has_match, result_time_list = VideoCommonMethod.match_codec_surface_time_list(codec_time_list, sql_instance)
            if result_time_list:
                result_multi_time_list.append(result_time_list)

    else:
        # 没有codec,看看有无surface
        surface_multi_time_list, surface_name_list = VideoCommonMethod.get_surface_multi_time_list(sql_instance)
        for time_list in surface_multi_time_list:
            if time_list and (time_list[0] - touch_start_time > -20 or is_seek):
                result_multi_time_list.append(time_list)
    logger.debug(f'surface_multi_time_list: {result_multi_time_list}')
    return result_multi_time_list


def get_head_big_interval(image_list, interval_list, trace_start_time):
    min_interval_start = None
    for item in interval_list:
        interval_start = item[0]
        if min_interval_start is None:
            min_interval_start = interval_start
            continue
        min_interval_start = min(min_interval_start, interval_start)
    max_cal_start_time = max(trace_start_time, image_list[0])
    if min_interval_start is not None and min_interval_start - max_cal_start_time > 100:
        return [max_cal_start_time, min_interval_start]
    return []


def get_image_interval_list_by_multi_time_list(multi_time_list, task_params: TaskParams):
    touch_start_time = task_params.touch_start_time
    start_time = task_params.start_time
    trace_start_time = task_params.trace_start_time
    trace_stop_time = task_params.trace_stop_time
    sql_instance = task_params.sql_instance
    image_path = task_params.image_path
    image_list = task_params.image_list
    is_seek = task_params.is_seek

    # 把不在区间内的list去掉
    satisfy_multi_time_list = []
    for time_list in multi_time_list:
        if time_list[0] - touch_start_time > -20 or is_seek:
            satisfy_multi_time_list.append(time_list)
    if len(satisfy_multi_time_list) == 0:
        return None

    if start_time > 0:
        # 需要把第一个去掉，部分第一个是缓存
        for index in range(len(satisfy_multi_time_list)):
            satisfy_multi_time_list[index] = satisfy_multi_time_list[index][1:]

    big_interval_list = get_big_interval_by_multi_time_list(satisfy_multi_time_list, image_path, image_list,
                                                            sql_instance, trace_stop_time)
    if start_time == 0:
        head_big_interval = get_head_big_interval(image_list, multi_time_list, trace_start_time)
        if len(head_big_interval) > 0:
            big_interval_list.append(head_big_interval)

    logger.debug(f'big_interval: {big_interval_list}')
    image_interval_list = []
    for big_interval in big_interval_list:
        if big_interval[1] <= start_time or big_interval[0] >= image_list[-1]:
            continue
        image_interval = \
            get_big_interval_by_image(image_path, image_list, big_interval[0], big_interval[1])
        for item in image_interval:
            if len(item) > 0:
                image_interval_list.append(item)
    image_interval_list = remove_sub_intervals(image_interval_list)
    return image_interval_list


def get_big_interval_by_image(dir_path, image_list, start_time, end_time):
    jank_start_time = get_jank_start_time(dir_path, image_list, start_time, end_time)
    jank_end_time = get_jank_end_time(dir_path, image_list, end_time)

    big_interval_list = []
    if jank_end_time - jank_start_time >= 100 and jank_start_time < image_list[-1]:
        big_interval_list.append([jank_start_time, jank_end_time])
    else:
        # 看中间有无帧间差大于100的
        for idx, image_time in enumerate(image_list):
            if image_time < start_time or idx == 0:
                continue
            if image_time - image_list[idx - 1] >= 100:
                big_interval_list.append([image_list[idx - 1], image_time])
            if image_time > end_time:
                break
    return big_interval_list


def get_gray_image_by_file_time(dir_path, file_time, device_type='full'):
    image_path = f"{dir_path}/{file_time}{IMAGE_FORMAT}"
    img = ImageHelper.read_image(image_path)
    height = img.shape[0]
    if device_type == 'phone':
        cut_ratio = 0.044
    elif device_type == 'pc':
        cut_ratio = 0.0
    else:
        cut_ratio = 0.0
    cut_height = int(height * cut_ratio)
    ori_image = img[cut_height:, :]
    return cv2.cvtColor(ori_image, cv2.COLOR_BGR2GRAY)


def get_jank_start_time(dir_path, image_list, start_time, end_time):
    # 先找开始时间
    before_time_max_delay = 150
    cal_break_time = min(end_time, start_time + before_time_max_delay)
    max_diff_ratio = 0.0005
    pre_image = None
    pre_time = None
    jank_start_time = start_time
    for image_time in image_list:
        if image_time <= start_time:
            pre_time = image_time
            continue
        image = get_gray_image_by_file_time(dir_path, image_time)
        if pre_image is None:
            jank_start_time = image_time
            if image_time > cal_break_time:
                if pre_time is not None and pre_time > start_time:
                    jank_start_time = pre_time
                break
            pre_image = image
            pre_time = image_time
            continue
        if image_time > cal_break_time:
            break
        diff_ratio = get_pixel_diff(pre_image, image)
        logger.debug(f'before diff, time:{image_time}, diff:{diff_ratio:07f}')
        if diff_ratio > max_diff_ratio:
            jank_start_time = image_time
        pre_image = image
        pre_time = image_time
    return jank_start_time


def get_jank_end_time(dir_path, image_list, ori_end_time):
    # 找结束时间
    end_time = ori_end_time - 5
    after_time_max_delay = 100
    max_diff_ratio = 0.0002
    pre_image = None
    pre_time = None
    first_cal_time = None
    jank_end_time = end_time
    not_break = True
    for image_time in image_list:
        if image_time < end_time:
            first_cal_time = image_time
            continue
        image = get_gray_image_by_file_time(dir_path, image_time)
        if pre_image is None:
            jank_end_time = image_time
            pre_image = get_gray_image_by_file_time(dir_path, first_cal_time)
            pre_time = first_cal_time
        diff_ratio = get_pixel_diff(pre_image, image, 10)
        logger.debug(f'after diff, time:{image_time}, diff:{diff_ratio:07f}')
        if diff_ratio > max_diff_ratio:
            jank_end_time = image_time
            not_break = False
            break
        if image_time >= end_time + after_time_max_delay:
            jank_end_time = pre_time
            not_break = False
            break
        pre_image = image
        pre_time = image_time
    if jank_end_time > image_list[-1] or not_break:
        jank_end_time = image_list[-1]
    return jank_end_time


def remove_sub_intervals(intervals):
    # 排序：按照区间的起点排序，若起点相同，则按终点降序排序
    intervals.sort(key=lambda x: (x[0], -x[1]))

    result = []
    for current in intervals:
        if not result or result[-1][1] < current[1]:
            result.append(current)
    return result


def get_tail_big_interval(image_list, sql_instance, trace_stop_time, max_buffer_time, image_path):
    end_interval = min(image_list[-1], trace_stop_time) - max_buffer_time
    if end_interval > 300:
        # 看max_buffer_time后面有没有H:stop
        stop_list = sql_instance \
            .query_all(f"select * from callstack where name = 'H:Stop'")
        if len(stop_list) > 0:
            end_stop_time = stop_list[-1].ts // 1000000
            if end_stop_time - max_buffer_time > -100:
                return []

        # 看两帧的差异
        start_file_time = None
        for file_time in image_list:
            if file_time - max_buffer_time >= 70:
                start_file_time = file_time
                break
        start_image_gray = get_gray_image_by_file_time(image_path, start_file_time)
        end_image_gray = get_gray_image_by_file_time(image_path, image_list[-1])
        diff_ratio = get_pixel_diff(start_image_gray, end_image_gray)
        logger.debug(f'tail diff ratio:{diff_ratio}')
        if diff_ratio < 0.1:
            return [max_buffer_time, image_list[-1]]
    return []


def get_big_interval_by_multi_time_list(multi_time_list, image_path, image_list, sql_instance, trace_stop_time):
    max_buffer_time = 0
    big_interval = []
    for time_list in multi_time_list:
        if len(time_list) < 2:
            continue
        max_buffer_time = max(max_buffer_time, time_list[-1])
        pre_buffer_time = time_list[0]
        for buffer_time in time_list[1:]:
            if buffer_time - pre_buffer_time >= 90:
                big_interval.append([pre_buffer_time, buffer_time])
            pre_buffer_time = buffer_time

    tail_big_interval = \
        get_tail_big_interval(image_list, sql_instance, trace_stop_time, max_buffer_time, image_path)
    if len(tail_big_interval) > 0:
        big_interval.append(tail_big_interval)
    return big_interval


def filter_jank_by_audio(jank_list, sql_instance):
    audio_multi_time_list = VideoCommonMethod.get_audio_multi_time_list(sql_instance)
    merged_time_list = []
    for arr in audio_multi_time_list:
        merged_time_list.extend(arr)
    merged_time_list = sorted(merged_time_list)
    filter_jank_list = []
    for jank in jank_list:
        low, high = jank
        if high - low < 300:
            filter_jank_list.append(jank)
            continue
        left = bisect.bisect_left(merged_time_list, low)
        right = bisect.bisect_right(merged_time_list, high)
        sub_arr = merged_time_list[left:right]
        sub_arr.insert(0, low)
        sub_arr.append(high)
        diffs = [sub_arr[i + 1] - sub_arr[i] for i in range(len(sub_arr) - 1)]
        no_audio_time = sum(d for d in diffs if d > 50)
        if no_audio_time / (high - low) > 0.3:
            filter_jank_list.append(jank)
    return filter_jank_list


def merge_intervals(intervals):
    if not intervals:
        return []
    # 先按起点排序
    intervals.sort(key=lambda x: x[0])
    merged = [intervals[0]]
    for current in intervals[1:]:
        last = merged[-1]
        if current[0] < last[1]:
            last[1] = max(last[1], current[1])
        else:
            merged.append(current)
    return merged


class VideoJankDetector(BaseDetector):

    @classmethod
    def detect(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        context_validation = cls._validate_context(arg_dict, ["image_folder", "db_path"])
        if not context_validation.success:
            return context_validation
        context_dict = context_validation.data
        return cls.inner_detect(context_dict.get("image_folder"), context_dict.get("db_path"))

    @classmethod
    def inner_detect(cls, image_path: str, db_path: str):
        task_env, is_seek = '', False

        image_list = get_sorted_file_time_list(image_path, 0)

        try:
            trace_helper = TraceHelper(db_path)
        except Exception as e:
            logger.error("Trace解析失败", exc_info=e)
            return DetectionResult(False, "Trace解析失败")
        trace_start_time, trace_stop_time = trace_helper.get_trace_start_stop_time()
        touch_start_time = trace_helper.get_touch_start_time() // 1000000

        task_params = TaskParams(trace_start_time, trace_stop_time, touch_start_time,
                                 0, trace_helper, image_path, image_list, is_seek)

        donghu_surface_multi_time_list = trace_helper.get_donghu_surface_multi_time_list()
        is_donghu = len(donghu_surface_multi_time_list) > 0
        if is_donghu:
            image_interval_list = \
                cls.get_image_interval_list_by_multi_time_list(donghu_surface_multi_time_list, task_params)
        else:
            # 先查codec
            multi_time_list = get_multi_time_list_by_codec(trace_helper, touch_start_time, is_seek)
            image_interval_list = get_image_interval_list_by_multi_time_list(multi_time_list, task_params)
        if image_interval_list is None:
            logger.debug('not hit any scene')
            image_interval_list = []

        # 通过声音过滤掉卡顿
        image_interval_list = filter_jank_by_audio(image_interval_list, trace_helper)

        result_interval_list = []
        result_interval_list.extend(image_interval_list)
        video_jank_list = merge_intervals(result_interval_list)
        if len(result_interval_list) == 0:
            return DetectionResult.success("没有检测到视频卡顿", [])
        result_json_list = []
        for video_jank in video_jank_list:
            result_json_list.append(
                {
                    "start_time": video_jank[0],
                    "end_time": video_jank[1]
                }
            )
        return DetectionResult.success("检测到视频卡顿", result_json_list)

    @classmethod
    def get_image_interval_list_by_multi_time_list(cls, multi_time_list, task_params: TaskParams):
        touch_start_time = task_params.touch_start_time
        start_time = task_params.start_time
        trace_start_time = task_params.trace_start_time
        trace_stop_time = task_params.trace_stop_time
        sql_instance = task_params.sql_instance
        image_path = task_params.image_path
        image_list = task_params.image_list
        is_seek = task_params.is_seek

        # 把不在区间内的list去掉
        satisfy_multi_time_list = []
        for time_list in multi_time_list:
            if time_list[0] - touch_start_time > -20 or is_seek:
                satisfy_multi_time_list.append(time_list)
        if len(satisfy_multi_time_list) == 0:
            return None

        if start_time > 0:
            # 需要把第一个去掉，部分第一个是缓存
            for index in range(len(satisfy_multi_time_list)):
                satisfy_multi_time_list[index] = satisfy_multi_time_list[index][1:]

        big_interval_list = get_big_interval_by_multi_time_list(satisfy_multi_time_list, image_path, image_list,
                                                                sql_instance, trace_stop_time)
        if start_time == 0:
            head_big_interval = get_head_big_interval(image_list, multi_time_list, trace_start_time)
            if len(head_big_interval) > 0:
                big_interval_list.append(head_big_interval)

        logger.debug(f'big_interval: {big_interval_list}')
        image_interval_list = []
        for big_interval in big_interval_list:
            if big_interval[1] <= start_time or big_interval[0] >= image_list[-1]:
                continue
            image_interval = \
                get_big_interval_by_image(image_path, image_list, big_interval[0], big_interval[1])
            for item in image_interval:
                if len(item) > 0:
                    image_interval_list.append(item)
        image_interval_list = remove_sub_intervals(image_interval_list)
        return image_interval_list
