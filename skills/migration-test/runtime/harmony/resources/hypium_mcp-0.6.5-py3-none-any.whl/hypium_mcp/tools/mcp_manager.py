"""
MCP管理模块

提供MCP相关的管理功能。
"""
from typing import Dict

from hypium_mcp.device.device_manager import DeviceManager


def mcp_clean_up() -> Dict[str, str]:
    """
    释放所有缓存的设备连接

    Returns:
        释放结果信息，包含:
        - status: 操作状态
        - released_count: 释放的设备数量
    """
    dm = DeviceManager.get_instance()
    return dm.release_all_devices()