import json
import os.path
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any

import numpy as np

from hypium_mcp.plugins.detectors.core.base_detector import BaseDetector
from hypium_mcp.plugins.detectors.core.detection_result import DetectionResult
from hypium_mcp.plugins.detectors.core.swipe_jank.image_distance import ImageDistance
from hypium_mcp.plugins.detectors.core.swipe_jank.swipe_jank_checker import SwipeJankChecker
from hypium_mcp.plugins.detectors.core.swipe_jank.swipe_jank_config import ClipBias, SwipeAnimatorImageInfo, \
    SwipeDirection
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)
INVALID_POS = -10000

SMOOTH_ANGLE_THRESHOLD = 0.3 / 2720


class CurveType:
    SMOOTH = "平滑",
    WAVE = "波动",
    STRAIGHT = "近似直线"


def sort_image_infos(image_infos: list[SwipeAnimatorImageInfo]) -> list[SwipeAnimatorImageInfo]:
    image_infos.sort(key=lambda image_info: image_info.image_time)
    return image_infos


class SwipeJankDetector(BaseDetector):

    @classmethod
    def detect(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        """
        检测滑动卡顿问题
        
        Args:
            arg_dict: {
                image_folder: 采集到的录屏图片存放位置
                start_time: 检测起始的时间点
                swipe_direction: 滑动方向，默认竖直
            }
        
        Returns:
            DetectionResult: 检测结果，包含成功状态和相关信息
        """
        # 验证和解析上下文
        context_validation = cls._validate_context(arg_dict)
        if not context_validation.success:
            return context_validation

        context_dict = context_validation.data

        # 和处理图片数据
        image_handling = cls._handle_image_data(context_dict)
        if not image_handling.success:
            return image_handling

        image_infos, image_height, image_width, swipe_direction = image_handling.data

        # 计算图像位移
        displacement_result = cls._calculate_displacements(image_infos, image_height, image_width, swipe_direction)
        if not displacement_result.success:
            return displacement_result

        # 处理滑动区间
        swipe_processing = cls._process_swipe_interval(image_infos)
        if not swipe_processing.success:
            return swipe_processing

        image_infos = swipe_processing.data
        uid = context_dict.get("id", uuid.uuid4())
        logger.info(f"{uid} 动效检测区间 {image_infos[0].image_time} - {image_infos[-1].image_time}")

        # 执行卡顿检测
        res = cls._perform_jank_detection(uid, image_infos)
        return res

    @classmethod
    def _validate_context(cls, arg_dict: dict[str, Any]) -> DetectionResult:
        """
        验证输入参数
        """
        try:
            context_path = arg_dict.get("json_path")
            if context_path is None or not os.path.exists(context_path):
                return DetectionResult(False, "缺少上下文文件")

            context_dict = json.loads(Path(context_path).read_text(encoding="utf-8"))

            if context_dict.get("func_name") != "swipe":
                return DetectionResult(False, "非滑动场景跳过")

            required_fields = ["image_folder", "start_time"]
            for field in required_fields:
                if field not in context_dict:
                    return DetectionResult(False, f"缺少必要参数: {field}")

            if not context_dict["image_folder"] or not os.path.exists(context_dict["image_folder"]):
                return DetectionResult(False, f"图片文件夹不存在: {context_dict['image_folder']}")

            swipe_direction = SwipeDirection.get_direction(context_dict)
            if swipe_direction is None:
                return DetectionResult(False, "无效的滑动方向参数")

            return DetectionResult(True, "验证通过", context_dict)

        except Exception as e:
            return DetectionResult(False, f"上下文验证失败: {str(e)}")

    @classmethod
    def _handle_image_data(cls, context_dict: dict) -> DetectionResult:
        """处理图片数据"""
        try:
            image_folder = Path(context_dict["image_folder"])
            image_infos: list[SwipeAnimatorImageInfo] = []

            for image_file_path in image_folder.iterdir():
                image_infos.append(SwipeAnimatorImageInfo(image_file_path))

            if len(image_infos) == 0:
                return DetectionResult.error("没有找到图片文件")

            sort_image_infos(image_infos)
            image_height, image_width = image_infos[0].image_size()

            for image_info in image_infos:
                image_info.image_width = image_width
                image_info.image_height = image_height

            swipe_direction = SwipeDirection.get_direction(context_dict)

            return DetectionResult.success("图片数据处理成功", (image_infos, image_height, image_width, swipe_direction))

        except Exception as e:
            return DetectionResult.error(f"图片数据处理失败: {str(e)}")

    @classmethod
    def _calculate_displacements(cls, image_infos: list[SwipeAnimatorImageInfo],
                                 image_height: int, image_width: int,
                                 swipe_direction: SwipeDirection) -> DetectionResult:
        """计算图像位移"""
        try:
            clip_bias = ClipBias.get_clip_bias(image_height, image_width, "", swipe_direction)
            future_list: list[Future] = []

            with ThreadPoolExecutor() as executor:
                for i in range(len(image_infos) - 1):
                    future = executor.submit(cls.cal_image_shift,
                                             image_infos[i], image_infos[i + 1], clip_bias, swipe_direction)
                    future_list.append(future)

            for future in future_list:
                try:
                    future.result()
                except Exception as e:
                    logger.error(f"计算位移出现异常: {e}", exc_info=e)

            return DetectionResult(True, "位移计算成功")

        except Exception as e:
            return DetectionResult(False, f"图像位移计算失败: {str(e)}")

    @classmethod
    def _process_swipe_interval(cls, image_infos: list[SwipeAnimatorImageInfo]) -> DetectionResult:
        """处理滑动区间"""
        try:
            image_infos = cls.trim_zero_edge(image_infos)

            prev_image_info = None
            for curr_image_info in image_infos:
                if prev_image_info is None:
                    prev_image_info = curr_image_info
                    continue
                curr_image_info.pos = prev_image_info.pos + curr_image_info.shift
                prev_image_info = curr_image_info

            smooth_ratio = SMOOTH_ANGLE_THRESHOLD * image_infos[0].image_height
            stop_idx = cls.check_swipe_end(image_infos, smooth_ratio)
            image_infos = image_infos[:stop_idx]

            if len(image_infos) == 0:
                return DetectionResult(False, "没有检测到有效滑动区间")

            return DetectionResult(True, "滑动区间处理成功", image_infos)

        except Exception as e:
            return DetectionResult(False, f"滑动区间处理失败: {str(e)}")

    @classmethod
    def _perform_jank_detection(cls, uid: str, image_infos: list[SwipeAnimatorImageInfo]) -> DetectionResult:
        """执行卡顿检测"""
        jank_image_infos = SwipeJankChecker.check(image_infos)

        if len(jank_image_infos) == 0:
            return DetectionResult.success("没有检测到卡顿问题", [])
        message = f"{uid} 检测到卡顿问题区间: "
        jank_msg_list = []
        res_list = []
        for jank_image_info in jank_image_infos:
            logger.info(f"{jank_image_info[0].image_time}-{jank_image_info[1].image_time}出现卡顿")
            jank_msg_list.append(f"{jank_image_info[0].image_time}ms-{jank_image_info[1].image_time}ms")
            res_list.append({
                "start_time": jank_image_info[0].image_time,
                "end_time": jank_image_info[1].image_time
            })
        message += ",".join(jank_msg_list)
        return DetectionResult.success(message, res_list)

    @classmethod
    def cal_image_shift(cls, prev_image_info: SwipeAnimatorImageInfo, curr_image_info: SwipeAnimatorImageInfo,
                        clip_bias: ClipBias, swipe_direction: SwipeDirection):
        animator_pos = ImageDistance.compute_distance_twice(prev_image_info, curr_image_info,
                                                            clip_bias, swipe_direction)
        if swipe_direction == SwipeDirection.Horizontal:
            curr_image_info.shift = animator_pos.x
        else:
            curr_image_info.shift = animator_pos.y

    @classmethod
    def trim_zero_edge(cls, image_infos: list[SwipeAnimatorImageInfo]) -> list[SwipeAnimatorImageInfo]:
        """修剪零位移边缘，保留实际有位移的滑动区间"""
        if not image_infos:
            return image_infos
        left = 0
        while left < len(image_infos) and image_infos[left].shift == 0:
            left += 1
        right = len(image_infos) - 1
        while right >= left and image_infos[right].shift == 0:
            right -= 1
        return image_infos[left:right + 1]

    @classmethod
    def check_swipe_end(cls, image_infos: list[SwipeAnimatorImageInfo], smooth_ratio: float,
                        start_pos: float = 0) -> int:
        """
        判断滑动在给定区间的第几帧结束
        :param image_infos: 带位移的图像信息列表
        :param smooth_ratio: 平滑的比例
        :param start_pos: 上次滑动的结束点是多少
        :return: 滑动结束帧的索引
        """
        image_infos[0].pos = start_pos + image_infos[0].shift
        prev_image_info = None
        for curr_image_info in image_infos:
            if prev_image_info is not None:
                if curr_image_info.shift == INVALID_POS:
                    prev_pos = prev_image_info.pos
                    curr_image_info.pos = prev_pos + 10
                else:
                    curr_image_info.pos = prev_image_info.pos + curr_image_info.shift
            prev_image_info = curr_image_info
        x_values = [image_info.image_time for image_info in image_infos]
        y_values = [image_info.value for image_info in image_infos]
        dy_dx: list[float] = [0] + list(np.diff(y_values) / np.diff(x_values))
        index = 1
        while index < len(dy_dx):
            ratio = dy_dx[index]
            if np.abs(ratio) < smooth_ratio:
                curve_type = cls.check_not_smooth(index, dy_dx, ratio, smooth_ratio)
                if curve_type == CurveType.WAVE:
                    return index
                if curve_type == CurveType.STRAIGHT:
                    return index
            index += 1
        return -1

    @classmethod
    def check_not_smooth(cls, index: int, dy_dx: list[float], prev_ratio: float, smooth_ratio: float):
        """检查曲线是否不平滑（波动或趋近平直）"""
        wave_count, straight_count = 0, 0
        total_count = 0
        end_index = min(len(dy_dx), index + 15)

        for cur_index in range(index, end_index):
            curr_ratio = dy_dx[cur_index]
            if np.abs(curr_ratio) <= smooth_ratio:
                straight_count += 1
            # 斜率变化超过阈值也视为波动
            if prev_ratio * curr_ratio < 0.0 or (
                    curr_ratio != 0 and prev_ratio != 0 and abs(curr_ratio - prev_ratio) > 10):
                wave_count += 1
            total_count += 1
            prev_ratio = curr_ratio

        # 判断曲线类型
        wave_ratio = wave_count / total_count if total_count > 0 else 0
        straight_ratio = straight_count / total_count if total_count > 0 else 0

        # 波动判定
        if wave_ratio > 0.3:
            return CurveType.WAVE
        # 平直判定
        if straight_ratio > 0.5:
            return CurveType.STRAIGHT
        # 波动和平直共同判定
        if wave_ratio > 0.1 and straight_ratio > 0.5:
            return CurveType.WAVE
        return CurveType.SMOOTH
