import json


class DetectionResult:
    """统一的检测结果类"""

    def __init__(self, success: bool, message: str = "", data=None):
        self.success = success
        self.message = message
        self.data = data

    def __bool__(self):
        return self.success

    def __repr__(self):
        return json.dumps({"success": self.success, "message": self.message, "data": self.data}, ensure_ascii=False)

    @staticmethod
    def error(message: str):
        return DetectionResult(False, message)

    @staticmethod
    def success(message: str, data=None):
        return DetectionResult(True, message, data)
