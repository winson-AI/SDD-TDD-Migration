from hypium_mcp.core import mcp


if __name__ == "__main__":
    mcp.main()