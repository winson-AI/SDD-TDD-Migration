from .collectors.mcp_collector_enable import mcp_collector_enabled

