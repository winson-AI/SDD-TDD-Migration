import json
import os.path
from concurrent.futures.thread import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from hypium_mcp.config.config import get_config
from hypium_mcp.plugins.detectors.core.flash.image_flash_detector import ImageFlashDetector
from hypium_mcp.plugins.detectors.core.stability.stability_detector import StabilityDetector
from hypium_mcp.plugins.detectors.core.swipe_jank.swipe_jank_detector import SwipeJankDetector
from hypium_mcp.plugins.detectors.core.video_jank.video_jank_detector import VideoJankDetector
from hypium_mcp.plugins.detectors.resource_converter import ResourceConverter
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Detector)


class DetectorManager:

    @classmethod
    def generate_report(cls, stability_enable: bool = True, swipe_jank_enable: bool = True,
                        video_jank_enable: bool = True, image_flash_enable: bool = True) -> str:
        if os.getenv("HYPIUM_MCP_COLLECT_ENABLE") != "True":
            return "未打开数据采集开关，无法分析数据，跳过检测"
        output_dir = get_config().output_dir
        future_list = []
        output_dir = Path(output_dir)
        with ThreadPoolExecutor(max_workers=3) as executor:
            for action_path in Path(output_dir).iterdir():
                if action_path.is_file() or not os.path.exists(os.path.join(action_path, "context.json")):
                    continue
                future_list.append(executor.submit(cls.action_task, action_path,
                                                   swipe_jank_enable, image_flash_enable, video_jank_enable))
            future_list.append(executor.submit(cls.case_task, output_dir, stability_enable))
        all_res = []
        for future in future_list:
            all_res.append(future.result())
        output_dir.joinpath("detect_result.json").write_text(json.dumps(all_res), encoding="utf-8")
        return "检测完毕"

    @classmethod
    def action_task(cls, action_path: str | Path, swipe_jank_enable: bool, image_flash_enable: bool, video_jank_enable: bool):
        res_dict = {"detect_folder": str(action_path), "detect_result": {}}
        try:
            ResourceConverter.convert_action_data(action_path)
        except Exception as e:
            logger.error(f"数据转换失败: {action_path}", exc_info=e)
        if swipe_jank_enable:
            try:
                ans = SwipeJankDetector.detect({"json_path": os.path.join(action_path, "context.json")})
                res_dict["detect_result"]["swipe_jank"] = ans.data
                logger.info(f"滑动卡顿检测结果: {ans.message}, {action_path}")
            except Exception as e:
                logger.error(f"滑动卡顿检测异常: {action_path}", exc_info=e)
                res_dict["detect_result"]["swipe_jank"] = None
        if image_flash_enable:
            try:
                ans = ImageFlashDetector.detect({"json_path": os.path.join(action_path, "context.json")})
                res_dict["detect_result"]["image_flash"] = ans.data
                logger.info(f"黑白花闪检测结果: {ans}, {action_path}")
            except Exception as e:
                logger.error(f"黑白花闪检测异常: {action_path}", exc_info=e)
                res_dict["detect_result"]["image_flash"] = None
        if video_jank_enable:
            try:
                ans = VideoJankDetector.detect({"json_path": os.path.join(action_path, "context.json")})
                res_dict["detect_result"]["video_jank"] = ans.data
                logger.info(f"视频卡顿检测结果: {ans}, {action_path}")
            except Exception as e:
                logger.error(f"视频卡顿检测异常: {action_path}", exc_info=e)
                res_dict["detect_result"]["video_jank"] = None
        return res_dict

    @classmethod
    def case_task(cls, case_path: str | Path, stability_enable: bool):
        res_dict = {"detect_folder": str(case_path), "detect_result": {}}
        if stability_enable:
            try:
                ans = StabilityDetector.detect({"json_path": os.path.join(case_path, "stability.json")})
                logger.info(f"稳定性检测结果: {ans.message}, {case_path}")
                res_dict["detect_result"]["stability"] = ans.data
            except Exception as e:
                logger.error(f"稳定性检测异常: {case_path}", exc_info=e)
                res_dict["detect_result"]["stability"] = None
        return res_dict
