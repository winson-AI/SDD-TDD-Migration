#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CLI Application Framework

A modern, type-safe CLI framework with automatic parameter discovery
and registration.
"""

import inspect
import sys
from typing import Any, Callable, Dict, List, Optional, Tuple

from hypium_mcp.core.cli_framework.models import CommandInfo, ParamInfo


class CLIApp:
    """
    CLI Application Framework.

    Supports automatic command registration with parameter discovery,
    type conversion, and help generation.
    """

    def __init__(self, name: str = "cli", description: str = ""):
        """
        Initialize the CLI application.

        Args:
            name: Application name
            description: Application description
        """
        self.name = name
        self.description = description
        self._commands: Dict[str, CommandInfo] = {}
        self._aliases: Dict[str, str] = {}

    @property
    def commands(self) -> Dict[str, CommandInfo]:
        """Get all registered commands."""
        return self._commands

    @property
    def aliases(self) -> Dict[str, str]:
        """Get all command aliases."""
        return self._aliases

    def command(self, name: Optional[str] = None, description: str = "",
                aliases: Optional[List[str]] = None) -> Callable:
        """
        Decorator to register a command.

        Args:
            name: Command name (defaults to function name)
            description: Command description
            aliases: List of command aliases

        Returns:
            Decorator function
        """
        def decorator(func: Callable) -> Callable:
            cmd_name = name or func.__name__
            cmd_info = CommandInfo(cmd_name, func, description)
            self._commands[cmd_name] = cmd_info

            if aliases:
                for alias in aliases:
                    self._aliases[alias] = cmd_name

            return func
        return decorator

    def resolve_command(self, cmd_name: str) -> Optional[CommandInfo]:
        """
        Resolve command name (supports aliases).

        Args:
            cmd_name: Command name to resolve

        Returns:
            CommandInfo if found, None otherwise
        """
        if cmd_name in self._commands:
            return self._commands[cmd_name]
        return self._commands.get(self._aliases.get(cmd_name, ""))

    def _parse_args(self, cmd_info: CommandInfo, args: List[str]) -> Tuple[Dict[str, Any], List[str]]:
        """
        Parse command-line arguments.

        Args:
            cmd_info: Command info
            args: Argument list

        Returns:
            Tuple of (kwarg dict, positional args list)
        """
        kwargs = {}
        positional_args = []
        i = 0

        while i < len(args):
            arg = args[i]

            # Handle --key value format
            if arg.startswith("--"):
                key = arg[2:]
                if i + 1 < len(args) and not args[i + 1].startswith("-"):
                    value = args[i + 1]
                    i += 2
                else:
                    value = "true"
                    i += 1

                if cmd_info.has_param(key):
                    try:
                        kwargs[key] = cmd_info.get_param(key).convert(value)
                    except (ValueError, TypeError) as e:
                        raise ValueError(f"Failed to convert value for --{key}: {e}")
                else:
                    kwargs[key] = value

            # Handle -k format
            elif arg.startswith("-") and len(arg) > 1 and not arg[1].isdigit():
                key = arg[1:]
                if len(arg) > 2:
                    value = arg[2:]
                    i += 1
                elif i + 1 < len(args) and not args[i + 1].startswith("-"):
                    value = args[i + 1]
                    i += 2
                else:
                    value = "true"
                    i += 1

                # Try to match parameter name
                matched_param = None
                for param_name in cmd_info.params:
                    if param_name.startswith(key) or param_name[0] == key:
                        matched_param = param_name
                        break

                if matched_param:
                    try:
                        kwargs[matched_param] = cmd_info.get_param(matched_param).convert(value)
                    except (ValueError, TypeError) as e:
                        raise ValueError(f"Failed to convert value for -{key}: {e}")
                else:
                    kwargs[key] = value

            # Positional argument
            else:
                positional_args.append(arg)
                i += 1

        return kwargs, positional_args

    def _execute_command(self, cmd_name: str, args: List[str]) -> int:
        """
        Execute a command.

        Args:
            cmd_name: Command name
            args: Command arguments

        Returns:
            Exit code
        """
        cmd = self.resolve_command(cmd_name)
        if not cmd:
            print(f"Error: Unknown command '{cmd_name}'")
            print(f"\nUse '{self.name} -h' to see all available commands")
            return 1

        # Parse arguments
        try:
            kwargs, _ = self._parse_args(cmd, args)
        except ValueError as e:
            print(f"Argument parsing error: {e}")
            return 1

        # Check required parameters
        missing = [p.name for p in cmd.required_params if p.name not in kwargs]
        if missing:
            print(f"Error: Missing required parameters: {', '.join(missing)}")
            print(f"\nRun '{self.name} {cmd_name} -h' for help")
            return 1

        # Execute function
        try:
            sig = inspect.signature(cmd.func)
            bound_args = sig.bind_partial(**kwargs)
            result = cmd.func(*bound_args.args, **bound_args.kwargs)
            if result is not None:
                print(result)
            return 0
        except Exception as e:
            print(f"Error executing command '{cmd_name}': {e}")
            import traceback
            traceback.print_exc()
            return 1

    def _format_help(self, cmd_name: Optional[str] = None) -> str:
        """
        Format help text.

        Args:
            cmd_name: Command name for specific help, None for general help

        Returns:
            Formatted help string
        """
        if cmd_name:
            return self._format_command_help(cmd_name)
        return self._format_general_help()

    def _format_command_help(self, cmd_name: str) -> str:
        """Format help for a specific command."""
        cmd = self.resolve_command(cmd_name)
        if not cmd:
            return f"Error: Command '{cmd_name}' not found\n\nUse -h to see all commands"

        lines = [
            f"\n{'=' * 60}",
            f"Command: {cmd.name}",
            f"Description: {cmd.description or 'No description'}",
            f"{'=' * 60}",
            "",
        ]

        if cmd.required_params:
            lines.append("Required parameters:")
            for param in cmd.required_params:
                lines.append(f"  --{param.name:<20} Type: {param.type_name:<15} {param.name}")
            lines.append("")

        if cmd.optional_params:
            lines.append("Optional parameters:")
            for param in cmd.optional_params:
                default = f" (default: {param.default})" if param.default != inspect.Parameter.empty else ""
                lines.append(f"  --{param.name:<20} Type: {param.type_name:<15} {param.name}{default}")
            lines.append("")

        lines.extend([
            "Usage:",
            f"  {self.name} {cmd.name} --<param1> <value1> --<param2> <value2>",
            "",
        ])

        return "\n".join(lines)

    def _format_general_help(self) -> str:
        """Format general help for all commands."""
        lines = [
            f"\n{'=' * 60}",
            self.description or "CLI Application",
            f"{'=' * 60}",
            "",
            "Usage:",
            f"  {self.name} <command> [args...]",
            f"  {self.name} -h              # Show all commands",
            f"  {self.name} <command> -h    # Show command help",
            "",
            "=" * 60,
            "Available commands:",
            "=" * 60,
            "",
        ]

        if not self._commands:
            lines.append("  (No commands registered)")
        else:
            for cmd_name, cmd in self._commands.items():
                req = cmd.required_params
                opt = cmd.optional_params

                param_str = ""
                if req:
                    param_str += " ".join(f"<{p.name}>" for p in req)
                if opt:
                    if param_str:
                        param_str += " "
                    param_str += " ".join(f"[--{p.name}]" for p in opt)

                lines.append(f"  {cmd_name:<20} {param_str}")
                if cmd.description:
                    lines.append(f"    {cmd.description}")
                lines.append("")

        lines.extend([
            "=" * 60,
            "",
        ])

        return "\n".join(lines)

    def run(self, argv: Optional[List[str]] = None) -> int:
        """
        Run the CLI application.

        Args:
            argv: Command-line arguments (default: sys.argv[1:])

        Returns:
            Exit code
        """
        if argv is None:
            argv = sys.argv[1:]

        if not argv:
            print(self._format_help())
            return 0

        # Handle help
        if argv[0] in ("-h", "--help", "help"):
            if len(argv) > 1:
                print(self._format_help(argv[1]))
            else:
                print(self._format_help())
            return 0

        cmd_name = argv[0]
        args = argv[1:]

        if "-h" in args or "--help" in args:
            print(self._format_help(cmd_name))
            return 0

        return self._execute_command(cmd_name, args)