from typing import List

import numpy as np
from hypium_mcp.plugins.detectors.core.action_type import ActionType
from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import EnumerateWithPrev, FlashHelper
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.motional.base_motional_analyzer import BaseMotionalAnalyzer, \
    BaseMotionalInfo, MotionalImageInfo
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper
from hypium_mcp.utils.log.logger import LoggerName, get_logger

logger = get_logger(LoggerName.Detector)


class SwipeMotionalImageInfo(MotionalImageInfo):

    def __init__(self, image_info: ScreenFlashImageInfo):
        super().__init__(image_info)
        self.correlate_pos = (0, 0)
        self.correlate_ratio = 0.0
        self.correlate_angle = 0.0

    @property
    def value(self) -> float:
        return self.correlate_ratio


class SwipeSharpChangeImageInfo:
    def __init__(self, prev_image_info: SwipeMotionalImageInfo, curr_image_info: SwipeMotionalImageInfo):
        self.prev_image_info = prev_image_info
        self.curr_image_info = curr_image_info

    @property
    def image_time(self):
        return self.curr_image_info.image_time

    @property
    def start_time(self):
        return self.prev_image_info.image_time


class SwipeMotionalAnalyzer(BaseMotionalAnalyzer):

    def compare_image_info(self, prev_image_info: ScreenFlashImageInfo,
                           curr_image_info: ScreenFlashImageInfo) -> BaseMotionalInfo:
        motional_image_info = SwipeMotionalImageInfo(curr_image_info)
        return motional_image_info

    def analyze_image_info_list(self, image_info_list: List[SwipeMotionalImageInfo]) -> List[KpiFlashInfo]:
        flash_info_list: List[KpiFlashInfo] = []
        sharp_change_info_list: List[SwipeSharpChangeImageInfo] = []
        prev_image_info = image_info_list[0]
        for index, curr_image_info in enumerate(image_info_list[1:]):
            if curr_image_info.template_similarity > 0.95:
                continue
            if (abs(curr_image_info.template_similarity - prev_image_info.template_similarity) > 0.5 or
                curr_image_info.template_similarity < 0) \
                    and prev_image_info.template_similarity > 0:
                sharp_change_info_list.append(SwipeSharpChangeImageInfo(prev_image_info, curr_image_info))
            prev_image_info = curr_image_info
        for index, prev_image_info, next_image_info in EnumerateWithPrev(sharp_change_info_list, start=1):
            flash_info = self.check_sharp_change(prev_image_info, next_image_info)
            if flash_info and self.flash_params.action_type == ActionType.SWIPE and \
                    abs(flash_info.start_time - image_info_list[0].image_time) < 50:
                flash_info = None
            if flash_info:
                flash_info_list.append(flash_info)
        for sharp_change_info in sharp_change_info_list:
            sharp_change_info.prev_image_info = None
            sharp_change_info.curr_image_info = None
        return flash_info_list

    def check_sharp_change(self, prev_sharp_change_image_info: SwipeSharpChangeImageInfo,
                           curr_sharp_change_image_info: SwipeSharpChangeImageInfo) -> KpiFlashInfo | None:
        if curr_sharp_change_image_info.image_time - prev_sharp_change_image_info.image_time > 200:
            return None
        # 中间帧存在纯色区域
        mid_image_info = curr_sharp_change_image_info.prev_image_info.image_info
        mid_image = ImageHelper.read_gray_image(mid_image_info.image_file_path)
        pure_ratio, pure_pixel = FlashHelper.most_common_color_ratio(mid_image)
        logger.debug(f"{mid_image_info.image_time} 纯色比例 {pure_ratio}, 色值: {pure_pixel}")
        if pure_ratio < 0.2:
            return None
        start_image_info, end_image_info = prev_sharp_change_image_info.prev_image_info.image_info, \
            curr_sharp_change_image_info.curr_image_info.image_info
        pure_ratio_list = []
        curr_image_info = start_image_info
        while curr_image_info is not None:
            if curr_image_info.template_similarity < 0.98:
                pure_ratio_list.append(
                    np.sum(ImageHelper.read_gray_image(curr_image_info.image_file_path) == pure_pixel) / mid_image.size)
            curr_image_info = curr_image_info.next_image_info
            if curr_image_info.image_time > end_image_info.image_time:
                break
        if np.max(np.abs(np.diff(pure_ratio_list))) < 0.1:
            return None
        flash_info = KpiFlashInfo.build(start_image_info, end_image_info, self.flash_params.video_start_timestamp)
        return flash_info
