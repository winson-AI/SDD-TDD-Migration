"""
Configuration Module

Provides configuration settings management with environment variable support.
"""

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ModeConfig:
    """Mode configuration for filtering tools and modules."""
    include_module: List[str] = field(default_factory=list)
    exclude_module: List[str] = field(default_factory=list)
    include_tools: List[str] = field(default_factory=list)
    exclude_tools: List[str] = field(default_factory=list)


@dataclass
class Config:
    """Application configuration with defaults and environment variable support."""

    # Server settings
    server_name: str = "HypiumMCP"
    service_mode: str = "streamable-http"
    host: str = "localhost"
    port: Optional[int] = 8000

    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None

    # Device settings
    device_id: str = "default"
    device_connection_timeout: int = 30
    # 配置hdc服务地址和ip，支持远程设备
    hdc_host: str = "127.0.0.1"
    hdc_port: int = 8710
    hdc_path: str = ""
    working_dir: str = ""
    output_dir: str = f"./reports/hypium_mcp_{time.strftime('%Y%m%d%H%M%S', time.localtime())}"
    exclude_module: str = ""
    include_module: str = ""
    exclude_tools: str = ""
    include_tools: str = ""

    # Mode configuration
    mode: Optional[str] = "phone_operation"
    tools_mode: Dict[str, Dict[str, List[str]]] = field(default_factory=dict)

    # Coordinate configuration
    coordinate_value_mode: str = "relative_1000"  # relative_1, relative_1000, absolute

    def get_mode_config(self, mode_name: Optional[str] = None) -> ModeConfig:
        """
        Get mode configuration by name.

        Args:
            mode_name: Mode name, if None use config.mode

        Returns:
            ModeConfig object, empty config if mode not found
        """
        name = mode_name or self.mode
        if not name or name not in self.tools_mode:
            return ModeConfig()

        mode_data = self.tools_mode[name]
        return ModeConfig(
            include_module=mode_data.get("include_module", []),
            exclude_module=mode_data.get("exclude_module", []),
            include_tools=mode_data.get("include_tools", []),
            exclude_tools=mode_data.get("exclude_tools", []),
        )

    @classmethod
    def from_env(cls) -> "Config":
        """Create config from environment variables."""
        mode = os.getenv("HYPIUM_MCP_MODE", cls().mode)
        tools_mode = cls._load_tools_mode_config()

        return cls(
            server_name=os.getenv("HYPIUM_MCP_SERVER_NAME", cls().server_name),
            service_mode=os.getenv("HYPIUM_MCP_SERVICE_MODE", cls().service_mode),
            host=os.getenv("HYPIUM_MCP_HOST", cls().host),
            port=int(os.getenv("HYPIUM_MCP_PORT", "")) if os.getenv("HYPIUM_MCP_PORT") else None,
            log_level=os.getenv("HYPIUM_MCP_LOG_LEVEL", cls().log_level),
            log_file=os.getenv("HYPIUM_MCP_LOG_FILE"),
            device_id=os.getenv("HYPIUM_MCP_DEVICE_ID", cls().device_id),
            device_connection_timeout=int(os.getenv("HYPIUM_MCP_TIMEOUT", str(cls().device_connection_timeout))),
            output_dir=os.getenv("HYPIUM_MCP_OUTPUT_DIR", cls().output_dir),
            exclude_module=os.getenv("HYPIUM_MCP_EXCLUDE_MODULE", cls().exclude_module),
            include_module=os.getenv("HYPIUM_MCP_INCLUDE_MODULE", cls().include_module),
            exclude_tools=os.getenv("HYPIUM_MCP_EXCLUDE_TOOLS", cls().exclude_tools),
            include_tools=os.getenv("HYPIUM_MCP_INCLUDE_TOOLS", cls().include_tools),
            hdc_host=os.getenv("HYPIUM_MCP_HDC_HOST", cls().hdc_host),
            hdc_port=int(os.getenv("HYPIUM_MCP_HDC_PORT", cls().hdc_port)),
            hdc_path=os.getenv("HYPIUM_MCP_HDC_PATH", cls().hdc_path),
            working_dir=os.getenv("HYPIUM_MCP_WORKING_DIR", cls().working_dir),
            mode=mode,
            tools_mode=tools_mode,
            coordinate_value_mode=os.getenv("HYPIUM_MCP_COORDINATE_VALUE_MODE", "relative_1000"),
        )

    @classmethod
    def _load_tools_mode_config(cls) -> Dict[str, Dict[str, List[str]]]:
        """
        Load tools mode configuration from JSON file.

        Supports:
        - HYPIUM_MCP_TOOLS_MODE_JSON: JSON string directly
        - HYPIUM_MCP_TOOLS_MODE_FILE: Path to JSON file
        - Default: look for tools_mode.json in current directory or config directory

        Returns:
            Dictionary of mode configurations
        """
        # 1. Try environment variable JSON string
        json_str = os.getenv("HYPIUM_MCP_TOOLS_MODE_JSON")
        if json_str:
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                pass

        # 2. Try environment variable JSON file
        json_file = os.getenv("HYPIUM_MCP_TOOLS_MODE_FILE")
        if json_file and os.path.exists(json_file):
            try:
                with open(json_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass

        # 3. Try default locations
        default_paths = [
            "hypium_mcp_tools_config.json",
            os.path.join(os.path.dirname(__file__), "hypium_mcp_tools_config.json"),
        ]

        for path in default_paths:
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        return json.load(f)
                except (json.JSONDecodeError, IOError):
                    pass

        return {}

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "Config":
        """Create config from a dictionary."""
        return cls(**{k: v for k, v in config_dict.items() if k in cls.__annotations__})

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to a dictionary."""
        return {
            "server_name": self.server_name,
            "service_mode": self.service_mode,
            "host": self.host,
            "port": self.port,
            "log_level": self.log_level,
            "log_file": self.log_file,
            "device_id": self.device_id,
            "device_connection_timeout": self.device_connection_timeout,
            "output_dir": self.output_dir,
        }

    def ensure_dirs(self) -> None:
        """Ensure that output directories exist."""
        for dir_path in [self.output_dir]:
            Path(dir_path).mkdir(parents=True, exist_ok=True)

    def get_port(self) -> int:
        """Get the port to use, with default based on service mode."""
        if self.port is not None:
            return self.port

        port_map = {
            "http": 8000,
            "streamable-http": 8001,
            "socket": 8002,
        }
        return port_map.get(self.service_mode, 8001)


# Default configuration
DEFAULT_CONFIG = Config(
    server_name="HypiumMCP",
    service_mode="streamable-http",
    host="localhost",
    port=8001,
    log_level="INFO",
    log_file=None,
    device_id="default",
    device_connection_timeout=30,
    output_dir="./dumps",
)

# Global config instance
_config: Optional[Config] = None


def load_config(use_env: bool = True) -> Config:
    """
    Load config from environment variables.

    Args:
        use_env: Whether to load from environment variables, otherwise use defaults

    Returns:
        Loaded config
    """
    global _config

    if use_env:
        _config = Config.from_env()
    else:
        _config = Config()

    return _config


def _apply_config(config: Config):
    from hypium_mcp.utils import EnvVarManager
    if config.hdc_path:
        if not isinstance(config.hdc_path, str):
            raise TypeError(f"HDC_PATH must be str, not {type(config.hdc_path)}")
        hdc_dir = os.path.dirname(config.hdc_path)
        EnvVarManager.add_to_path(hdc_dir)
    if config.working_dir:
        if not os.path.isdir(config.working_dir):
            raise ValueError("Working dir not exist.")
        os.chdir(config.working_dir)


def get_config() -> Config:
    """
    Get the current config, loading from environment if not yet loaded.

    Returns:
        Current config
    """
    global _config
    if _config is None:
        _config = Config.from_env()
    _apply_config(_config)
    return _config


def reset_config() -> None:
    """Reset the global config instance."""
    global _config
    _config = None


def update_config(config_dict: dict) -> Config:
    current_config = get_config()
    current_config.__dict__.update(config_dict)
    return get_config()


def set_config(config: Config) -> None:
    """
    Set the global config instance.

    Args:
        config: Config to use
    """
    global _config
    _config = config
