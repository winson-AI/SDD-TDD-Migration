import os

from hypium_mcp.plugins.collectors.core.base_collector import BaseCollector
from hypium_mcp.utils.log import get_logger
from hypium_mcp.utils.log.logger import LoggerName

logger = get_logger(LoggerName.Collector)

_TRACE_TIMEOUT = 8 * 1000

_SMALL_BUFFER_SIZE = 32 * 1024
_BIG_BUFFER_SIZE = 200 * 1024
_WATCH_BUFFER_SIZE = 56 * 1024

_TRACE_CATEGORIES = 'ability ace app ark binder freq graphic memreclaim mmc multimodalinput rpc sched sync ' \
                    'window workq zaudio zcamera zimage zmedia'
_SYSTRACE_BEGIN_CMD = f'hitrace -b {{}} --trace_clock mono --trace_begin --file_size 512000 --record {_TRACE_CATEGORIES}'
_SYSTRACE_END_CMD = 'hitrace --trace_finish --record'
_SYSTRACE_CLOSE_CMD = 'hitrace --trace_finish_nodump'

_SYSTRACE_PATH = f'/data/log/hitrace/*.sys'


class TraceCollector(BaseCollector):
    """基础 Trace 采集器"""

    def __init__(self):
        super().__init__()

        self.buffer_size = _BIG_BUFFER_SIZE
        self.trace_begin_cmd = _SYSTRACE_BEGIN_CMD.format(self.buffer_size)
        self.trace_end_cmd = _SYSTRACE_END_CMD

    def case_start(self):
        super().case_start()

    def case_stop(self):
        super().case_stop()

    def action_start(self, action_id: str):
        logger.info(f'Trace 操作采集开始')
        self.start_trace()

    def action_stop(self, action_id: str):
        logger.info(f'Trace 操作采集结束')
        trace_name = self.get_trace_name(action_id)
        save_path = os.path.join(self.get_action_path(action_id), trace_name)
        self.stop_trace(save_path)

    def start_trace(self):
        res = self.driver.shell(_SYSTRACE_CLOSE_CMD, timeout=_TRACE_TIMEOUT)
        logger.info(f'Trace关闭响应结果: {res}')
        res = self.driver.shell(self.trace_begin_cmd, timeout=_TRACE_TIMEOUT)
        logger.info(f'Trace启动响应结果: {res}')

    def stop_trace(self, save_path: str):
        res = self.driver.shell(self.trace_end_cmd, timeout=_TRACE_TIMEOUT)
        logger.info(f'Trace停止响应结果: {res}')
        for split_line in res.splitlines():
            if ".sys" not in split_line:
                continue
            sys_trace_path = split_line.strip()
            self.driver.pull_file(sys_trace_path, save_path)
            logger.info(f'Trace文件保存路径: {save_path}')
            self.driver.shell(f"rm {sys_trace_path}")
            return
        raise Exception("Trace文件拉取失败")

    @staticmethod
    def get_trace_name(action_id: str):
        return f"{action_id}.sys"

    def name(self):
        return "Trace"
