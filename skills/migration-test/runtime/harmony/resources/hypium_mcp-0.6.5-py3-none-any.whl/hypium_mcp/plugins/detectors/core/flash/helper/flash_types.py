import json
from enum import Enum

from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo


class VideoSceneType(Enum):
    STABLE = "稳定"
    ANIMATOR = "动效"
    SPECIAL = "特殊"


class VideoSceneInfo:

    def __init__(self, start_index: int, end_index: int, video_scene_type: VideoSceneType):
        self.start_index = start_index
        self.end_index = end_index
        self.video_scene_type = video_scene_type

    def update_end_index(self, index):
        self.end_index = index

    def __repr__(self):
        return json.dumps(self)


class ImageStatus(Enum):
    FREEZE = 0
    REFRESH = 1
    SCENE_TRANS = 2


class KpiFlashInfo:
    def __init__(self):
        self.start_time = 0
        self.end_time = 0
        self.during_time = 0
        self.video_start_time = 0
        self.video_end_time = 0

    def __repr__(self):
        return json.dumps(self)

    def update_end_time(self, flash_info: 'KpiFlashInfo'):
        self.end_time = max(flash_info.end_time, self.end_time)
        self.video_end_time = max(flash_info.video_end_time, self.video_end_time)

    def update_timestamp(self, video_start_timestamp: int):
        self.video_start_time = self.start_time - video_start_timestamp
        self.video_end_time = self.end_time - video_start_timestamp

    def to_dict(self) -> dict[str, int]:
        return {
            "start_time": self.start_time,
            "end_time": self.end_time,
            "during_time": self.during_time,
            "video_start_time": self.video_start_time,
            "video_end_time": self.video_end_time,
        }

    @staticmethod
    def build(prev_image_info: ScreenFlashImageInfo, curr_image_info: ScreenFlashImageInfo,
              video_start_timestamp: int = 0):
        flash_info = KpiFlashInfo()
        flash_info.start_time = prev_image_info.image_time
        flash_info.end_time = curr_image_info.image_time
        flash_info.during_time = flash_info.end_time - flash_info.start_time
        flash_info.video_start_time = prev_image_info.image_time - video_start_timestamp
        flash_info.video_end_time = curr_image_info.image_time - video_start_timestamp
        return flash_info
