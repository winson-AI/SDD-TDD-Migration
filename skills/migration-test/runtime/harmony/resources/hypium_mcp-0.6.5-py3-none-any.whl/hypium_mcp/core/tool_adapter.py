"""
工具适配器模块

提供装饰器用于适配基于驱动器的函数，实现自动驱动器注入。
"""

import functools
import inspect
from typing import Any, Callable, TypeVar, get_type_hints
from hypium import UiDriver


F = TypeVar("F", bound=Callable[..., Any])


def inject_driver(func: F, driver_creator: Callable[[], UiDriver]) -> F:
    """
    自动从 DeviceManager 注入 UiDriver 的装饰器。

    如果被装饰函数的第一个参数类型注解为 UiDriver，此装饰器将：
    1. 从函数的签名中移除第一个参数（用于内省检查）
    2. 调用时自动从 DeviceManager 获取默认驱动器并注入

    这允许编写接收驱动器参数的工具函数，而无需在 MCP 工具模式中暴露它。

    示例：
        @inject_driver
        def my_function(driver: UiDriver, arg1: str) -> str:
            return driver.some_method(arg1)

        # 使用时无需传递 driver：
        my_function("some_value")  # driver 自动注入

    Args:
        func: 要装饰的函数

    Returns:
        修改了签名的包装函数
    """
    # 获取原函数的签名
    sig = inspect.signature(func)
    params = list(sig.parameters.values())

    # 检查函数是否有参数
    if not params:
        return func

    # 检查第一个参数是否注解为 UiDriver
    first_param = params[0]
    first_annotation = first_param.annotation

    is_ui_driver = False
    if first_annotation is UiDriver:
        is_ui_driver = True
    elif first_annotation is not inspect.Parameter.empty:
        # 检查是否是匹配 "UiDriver" 的字符串注解
        if isinstance(first_annotation, str) and first_annotation == "UiDriver":
            is_ui_driver = True
        elif hasattr(first_annotation, "__name__") and first_annotation.__name__ == "UiDriver":
            is_ui_driver = True

    # 如果第一个参数不是 UiDriver，返回原函数不做改动
    if not is_ui_driver:
        return func

    # 创建不包含第一个参数的新签名
    new_params = params[1:]
    log_param = inspect.Parameter(
        name="log",
        kind=inspect.Parameter.KEYWORD_ONLY,
        default=None,
        annotation="str | None"
    )
    new_params.append(log_param)
    new_sig = sig.replace(parameters=new_params)

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        """
        从 DeviceManager 注入驱动器的包装函数。

        如果驱动器没有作为关键字参数显式传递，
        将从 DeviceManager 自动获取。
        """
        kwargs.pop("log", None)
        driver = driver_creator()
        return func(driver, *args, **kwargs)

    # 更新包装器的签名
    wrapper.__signature__ = new_sig  # type: ignore[attr-defined]

    # 更新类型注解，移除第一个参数
    wrapper.__annotations__ = {"log": log_param.annotation}
    if hasattr(func, "__annotations__"):
        type_hints = get_type_hints(func)
        hint_keys = list(type_hints.keys())

        # 保留第一个参数之后的参数和返回值的类型注解
        if hint_keys:
            # 从注解中移除第一个参数
            param_names = [p.name for p in params]
            if param_names and param_names[0] in type_hints:
                del type_hints[param_names[0]]

            # 重置注解（保留返回类型）
            wrapper.__annotations__ = {}
            for key, value in type_hints.items():
                if key != "return" or key in [p.name for p in new_params]:
                    wrapper.__annotations__[key] = value
            wrapper.__annotations__["log"] = log_param.annotation

    return wrapper  # type: ignore[return-value]


def is_with_driver_decorated(func: Callable[..., Any]) -> bool:
    """
    检查函数是否被 @with_driver 装饰。

    Args:
        func: 要检查的函数

    Returns:
        如果函数被 @with_driver 装饰返回 True，否则返回 False
    """
    return hasattr(func, "__wrapped__") and hasattr(func, "__signature__")


def get_original_function(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    如果函数被 @with_driver 装饰器包装，获取原函数。

    Args:
        func: 被包装的函数

    Returns:
        原函数，如果未被包装则返回输入函数
    """
    while hasattr(func, "__wrapped__"):
        func = func.__wrapped__  # type: ignore[attr-defined]
    return func


def create_driver_injector(driver_creator: Callable[[], UiDriver]) -> Callable[[Callable], Callable]:
    def driver_injector(func) -> Callable[[Callable], Callable]:
        return inject_driver(func, driver_creator)

    return driver_injector


def mcp_user_action(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    装饰器，将函数标记为 MCP 用户操作。

    Args:
        func: 要装饰的函数

    Returns:
        装饰后的函数
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        """
        调用函数并记录日志。

        如果函数有 log 参数，将日志记录到日志记录器中。
        """
        result = func(*args, **kwargs)
        if result is None:
            return f"{func.__name__} successfully"
        return result
    # Python314中, function.__annotations__ 为空 None，需要手动赋值
    if not wrapper.__annotations__:
        wrapper.__annotations__ = func.__annotations__
    return wrapper
