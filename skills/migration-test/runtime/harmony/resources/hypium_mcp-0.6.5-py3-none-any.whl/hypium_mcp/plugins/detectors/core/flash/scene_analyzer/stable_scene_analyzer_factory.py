import logging
from concurrent.futures import Future
from concurrent.futures.thread import ThreadPoolExecutor
from typing import List

import numpy as np

from hypium_mcp.plugins.detectors.core.flash.helper.flash_helper import EnumerateWithPrev, FlashHelper
from hypium_mcp.plugins.detectors.core.flash.helper.flash_params import FlashParams
from hypium_mcp.plugins.detectors.core.flash.helper.flash_types import KpiFlashInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.base.base_flash_image_info import ScreenFlashImageInfo
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.stable.base_stable_analyzer import BaseStableAnalyzer
from hypium_mcp.plugins.detectors.core.flash.scene_analyzer.stable.pure_stable_analyzer import PureStableAnalyzer
from hypium_mcp.plugins.detectors.helper.image_helper import ImageHelper


class StableSceneAnalyzer:
    THRESHOLD_RATIO = {
        (200, 0.8),
        (100, 0.7),
        (30, 0.5)
    }

    """
    静态场景分析
    """

    def __init__(self, flash_params: FlashParams):
        self.executor = ThreadPoolExecutor(max_workers=8)
        self.flash_params = flash_params
        self.sub_analyzer_list: List[BaseStableAnalyzer] = []
        sub_analyzer_class_list = [PureStableAnalyzer]
        for sub_analyzer_class in sub_analyzer_class_list:
            self.sub_analyzer_list.append(sub_analyzer_class(flash_params))

    def analyzer_images(self, image_info_list: List[ScreenFlashImageInfo],
                        check_video_scene: bool = True) -> List[KpiFlashInfo]:
        if len(image_info_list) < 2:
            return []
        if check_video_scene and self.is_video_scene(image_info_list):
            return self.analyzer_video_scene_images(image_info_list)
        logging.debug(f"静态黑花闪分析区间 {image_info_list[0].image_time}-{image_info_list[-1].image_time}, "
                      f"图片数 {len(image_info_list)}")
        flash_info_list: List[KpiFlashInfo] = []
        for analyzer in self.sub_analyzer_list:
            future_list: List[Future] = []
            for index, prev_image_info, curr_image_info in EnumerateWithPrev(image_info_list):
                future_list.append(self.executor.submit(analyzer.compare_image_info, prev_image_info, curr_image_info))
            sub_analyzer_image_info_list = []
            for future in future_list:
                sub_analyzer_image_info_list.append(future.result())
            flash_info_list.extend(analyzer.analyze_image_info_list(sub_analyzer_image_info_list))
        return flash_info_list

    def is_video_scene(self, image_info_list: List[ScreenFlashImageInfo]):
        template_similarity_array = np.asarray([image_info.template_similarity for image_info in image_info_list])
        template_similarity_count = np.sum(template_similarity_array > 0.99)
        start_time, end_time = image_info_list[1].image_time, image_info_list[-1].image_time
        frame_rate = round((len(image_info_list) - template_similarity_count) / ((end_time - start_time) / 1000), 2)
        same_ratio = round(template_similarity_count / len(image_info_list), 3)
        logging.info(f"{start_time}-{end_time} 平均帧率 {frame_rate}, 相似比例 {same_ratio}")
        if same_ratio < 0.3:
            return True
        if frame_rate < 20 or frame_rate > 60:
            return False
        image_count = len(image_info_list)
        for len_limit, ratio in StableSceneAnalyzer.THRESHOLD_RATIO:
            if image_count > len_limit:
                return same_ratio < ratio
        return False

    def analyzer_video_scene_images(self, image_info_list: List[ScreenFlashImageInfo]):
        logging.debug(f"视频黑花闪分析区间 {image_info_list[0].image_time}-{image_info_list[-1].image_time}, "
                      f"图片数 {len(image_info_list)}")
        sharp_change_info_list: List[ScreenFlashImageInfo] = []
        for curr_image_info in image_info_list[1:]:
            if curr_image_info.template_similarity < 0.5:
                sharp_change_info_list.append(curr_image_info)
        if len(sharp_change_info_list) < 2:
            return []

        flash_info_list = []
        for index, prev_image_info, next_image_info in EnumerateWithPrev(sharp_change_info_list, start=1):
            if next_image_info.image_time - prev_image_info.image_time > 300:
                continue
            prev_image = ImageHelper.read_gray_image(prev_image_info.prev_image_info.image_file_path)
            curr_image = ImageHelper.read_gray_image(prev_image_info.image_file_path)
            next_image = ImageHelper.read_gray_image(next_image_info.image_file_path)
            # 中间帧纯色
            if FlashHelper.most_common_color_ratio(curr_image, bias=2)[0] > 0.7:
                flash_info = KpiFlashInfo.build(prev_image_info, next_image_info,
                                                self.flash_params.video_start_timestamp)
                flash_info_list.append(flash_info)
                continue
            # 前后帧一致
            if FlashHelper.match_template_ccoeff(prev_image, next_image) > 0.9:
                flash_info = KpiFlashInfo.build(prev_image_info, next_image_info,
                                                self.flash_params.video_start_timestamp)
                flash_info_list.append(flash_info)
                continue
            if FlashHelper.match_template_ccoeff(prev_image, curr_image) < 0.5 and \
                    FlashHelper.match_template_ccoeff(next_image, curr_image) < 0.5:
                flash_info = KpiFlashInfo.build(prev_image_info, next_image_info,
                                                self.flash_params.video_start_timestamp)
                flash_info_list.append(flash_info)
                continue
        return flash_info_list
