"""
Environment variable configuration module.

Provides utilities for managing environment variables with cross-platform support.
"""

import os
import sys
from typing import Optional, List, Literal
from pathlib import Path

# 延迟导入以避免循环依赖
logger = None

def _get_logger():
    global logger
    if logger is None:
        from hypium_mcp.utils.log import get_logger
        logger = get_logger("EnvConfig")
    return logger


class EnvVarManager:
    """Environment variable manager with cross-platform support."""

    # Platform-specific PATH separator
    PATH_SEPARATOR = ";" if sys.platform == "win32" else ":"

    @classmethod
    def _normalize_path(cls, path_str: str) -> Path:
        """
        Normalize a path string to a platform-specific Path object.

        Args:
            path_str: The path string to normalize

        Returns:
            Normalized Path object
        """
        path = Path(path_str.strip('"').strip("'"))
        return path.resolve()

    @classmethod
    def _is_path_valid(cls, path: Path) -> bool:
        """
        Check if a path is valid and exists.

        Args:
            path: Path object to check

        Returns:
            True if path exists, False otherwise
        """
        return path.exists()

    @classmethod
    def _is_path_in_env(cls, path: Path, env_name: str) -> bool:
        """
        Check if a path already exists in an environment variable.

        Args:
            path: Path object to check
            env_name: Name of the environment variable

        Returns:
            True if path is already in the variable, False otherwise
        """
        env_value = os.environ.get(env_name, "")
        if not env_value:
            return False

        existing_paths = [cls._normalize_path(p) for p in env_value.split(cls.PATH_SEPARATOR)]
        path_normalized = path.resolve()

        return any(existing.resolve() == path_normalized for existing in existing_paths if existing)

    @classmethod
    def add_to_path(
        cls,
        path_str: str,
        env_name: str = "PATH",
        required: bool = True,
        priority: Literal["first", "last"] = "first"
    ) -> bool:
        """
        Add a path to an environment variable.

        Args:
            path_str: The path string to add
            env_name: Name of the environment variable (default: "PATH")
            required: If True, raises an exception when path is invalid. If False, returns False.
            priority: Where to add the path in the search order:
                - "first": Add to the front (highest search priority)
                - "last": Add to the end (lowest search priority)

        Returns:
            True if path was added successfully, False if path already exists or is invalid

        Raises:
            ValueError: If path is invalid and required=True
        """
        path = cls._normalize_path(path_str)

        # Check if path exists
        if not cls._is_path_valid(path):
            msg = f"Path does not exist: {path}"
            if required:
                raise ValueError(msg)
            _get_logger().warning(msg)
            return False

        # Check if path is already in the environment variable
        if cls._is_path_in_env(path, env_name):
            _get_logger().info(f"Path already in {env_name}: {path}")
            return False

        # Add the path
        current_value = os.environ.get(env_name, "")
        str_path = str(path)

        if current_value:
            if priority == "first":
                # Add to the beginning (highest priority)
                os.environ[env_name] = str_path + cls.PATH_SEPARATOR + current_value
            else:  # priority == "last"
                # Add to the end (lowest priority)
                os.environ[env_name] = current_value + cls.PATH_SEPARATOR + str_path
        else:
            os.environ[env_name] = str_path

        _get_logger().info(f"Added to {env_name} (priority={priority}): {path}")
        return True

    @classmethod
    def add_multiple_to_path(
        cls,
        paths: List[str],
        env_name: str = "PATH",
        required: bool = True,
        ignore_invalid: bool = False,
        priority: Literal["first", "last"] = "first"
    ) -> int:
        """
        Add multiple paths to an environment variable.

        When priority="first": paths are added in order, first in list gets highest priority.
        When priority="last": paths are added in order, first in list gets lowest priority.

        Args:
            paths: List of path strings to add
            env_name: Name of the environment variable
            required: If True, raises an exception when any path is invalid
            ignore_invalid: If True, continues adding valid paths even if some are invalid
            priority: Where to add paths in the search order:
                - "first": Add to the front (first path in list has highest priority)
                - "last": Add to the end (first path in list has lowest priority)

        Returns:
            Number of paths successfully added

        Raises:
            ValueError: If any path is invalid and required=True
        """
        added_count = 0
        failed_paths = []

        if priority == "first":
            # Process paths in reverse order so first in list gets highest priority
            for path_str in reversed(paths):
                try:
                    if cls.add_to_path(path_str, env_name, required=required, priority="first"):
                        added_count += 1
                except ValueError as e:
                    failed_paths.append(path_str)
                    if not ignore_invalid:
                        raise
        else:  # priority == "last"
            # Process paths in normal order so first in list gets lowest priority
            for path_str in paths:
                try:
                    if cls.add_to_path(path_str, env_name, required=required, priority="last"):
                        added_count += 1
                except ValueError as e:
                    failed_paths.append(path_str)
                    if not ignore_invalid:
                        raise

        if failed_paths:
            _get_logger().warning(f"Failed to add {len(failed_paths)} paths to {env_name}: {failed_paths}")

        return added_count

    @classmethod
    def get_env_paths(cls, env_name: str = "PATH") -> List[Path]:
        """
        Get all paths from an environment variable as a list of Path objects.

        Args:
            env_name: Name of the environment variable

        Returns:
            List of Path objects
        """
        env_value = os.environ.get(env_name, "")
        if not env_value:
            return []

        return [cls._normalize_path(p) for p in env_value.split(cls.PATH_SEPARATOR) if p]

    @classmethod
    def remove_from_path(cls, path_str: str, env_name: str = "PATH") -> bool:
        """
        Remove a path from an environment variable.

        Args:
            path_str: The path string to remove
            env_name: Name of the environment variable

        Returns:
            True if path was removed, False if path was not found
        """
        path = cls._normalize_path(path_str)
        env_value = os.environ.get(env_name, "")

        if not env_value:
            return False

        paths = env_value.split(cls.PATH_SEPARATOR)
        target_str = str(path.resolve())

        # Filter out the target path
        new_paths = [p for p in paths if p and cls._normalize_path(p).resolve() != target_str]

        if len(new_paths) == len(paths):
            return False

        if new_paths:
            os.environ[env_name] = cls.PATH_SEPARATOR.join(new_paths)
        else:
            os.environ.pop(env_name, None)

        _get_logger().info(f"Removed from {env_name}: {path}")
        return True

    @classmethod
    def clear_duplicates_from_path(cls, env_name: str = "PATH") -> int:
        """
        Remove duplicate paths from an environment variable.

        Later occurrences are kept (higher priority).

        Args:
            env_name: Name of the environment variable

        Returns:
            Number of duplicates removed
        """
        env_value = os.environ.get(env_name, "")
        if not env_value:
            return 0

        paths = env_value.split(cls.PATH_SEPARATOR)
        seen = set()
        new_paths = []
        duplicates_removed = 0

        # Process in reverse to keep last occurrence of each path
        for p in reversed(paths):
            if not p:
                continue
            normalized = str(cls._normalize_path(p).resolve())
            if normalized in seen:
                duplicates_removed += 1
            else:
                seen.add(normalized)
                new_paths.append(p)

        if duplicates_removed == 0:
            return 0

        os.environ[env_name] = cls.PATH_SEPARATOR.join(reversed(new_paths))
        _get_logger().info(f"Removed {duplicates_removed} duplicates from {env_name}")
        return duplicates_removed