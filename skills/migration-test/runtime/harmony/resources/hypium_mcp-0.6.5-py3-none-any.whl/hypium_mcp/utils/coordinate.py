from typing import Tuple, Optional
from hypium_mcp.config.config import get_config


CoordinateMode = Optional[str]


def normalize_coordinate(pos: Tuple[float, float], mode: CoordinateMode = None) -> Tuple[float, float]:
    """
    归一化坐标到 0~1 范围

    Args:
        pos: 坐标元组 (x, y)
        mode: 坐标模式，None 表示使用全局配置
            - relative_1: 0~1 相对坐标，直接钳位到 0~0.99
            - relative_1000: 0~1000 相对坐标，除以 1000 后钳位 (默认)
            - absolute: 绝对坐标像素值，需要结合屏幕分辨率转换

    Returns:
        归一化后的坐标 (x, y)，范围 0~1
    """
    x, y = pos
    config = get_config()
    actual_mode = mode or config.coordinate_value_mode

    if actual_mode == "relative_1":
        x = max(min(x, 0.99), 0)
        y = max(min(y, 0.99), 0)

    elif actual_mode == "absolute":
        x = max(min(x, 0.99), 0)
        y = max(min(y, 0.99), 0)

    else:  # relative_1000 (default)
        x = max(min(x / 1000, 0.99), 0)
        y = max(min(y / 1000, 0.99), 0)

    return x, y
